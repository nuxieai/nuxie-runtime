# Writer lane: luau-fork rung 4 (official 0.727 -> 0.728)

Production writer porting one upstream Luau release delta into Nuxie's
vendored luaur fork. Read `docs/luau-fork.md`, then
`.luau-fork-work/prompts/preamble.md`, then the binding ledger
`.luau-fork-work/inventory/job4.md`. C-side diff:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff f1f121dc..ddcea05e -- VM Compiler Ast Common Config Require Bytecode Inliner`

Rungs 1-3 (0.725-0.727) are landed on this tree; the ledger's dependency
notes (getAttributeStartLocation existence, parseLocal_DEPRECATED removal,
CallInliner 0.726 shape, fresh-immediate appending, GETIMPORT decomposition)
are satisfied — verify each dependent twin before porting; mismatches go to
the blocked file.

## Protocol (identical to rungs 1-3)

1. STRUCTURE-PRESERVING; ROW-BY-ROW COMMITS with message prefix
   `luau-fork rung4: <symbol> (<c-file>) [f1f121dc..ddcea05e]`; plain
   commits, no trailers. Focused gate per row/group:
   `cargo check -p nuxie --features scripting` +
   `cargo test -p nuxie-scripting --lib` (fully green baseline now).
2. FFLAG POLICY: removed flags `LuauConstJustReportErrorForUnderfill`,
   `LuauCstExprGroup`, `LuauErrorTolerantPrettyPrinting` hardwire their
   former ON paths, grep-complete across vendor/ (registry, set_all_flags,
   sites). Any flag the ledger marks Added registers + pins `.set(false)`.
   The `DebugLuauUserDefinedClasses`-guarded `LOP_NEWCLASSMEMBER` parser
   change ports with both flag sides preserved.
3. Same-rung ordering the ledger mandates: `BcInst.uses`, `BcPhi.uses`,
   `BcBlock.phis`, `BcFunction::{recordUse,addUse}` land BEFORE the graph
   parser and inliner deltas that consume them.
4. Rows in untranslated subsystems (Require/, Inliner/) defer with
   rationale to `.luau-fork-work/rung4-blocked.md`; no-ops verified into
   `.luau-fork-work/rung4-noop.md`.
5. End: rung-level `NUXIE_PATCH.md` entries ("Ported official Luau 0.728
   delta (upstream f1f121dc..ddcea05e)"), committed as
   `luau-fork rung4: NUXIE_PATCH.md rung entries`; then one full
   `cargo test -p nuxie --features scripting`; fix forward only your own
   rows. Final message: dispositions, commits, gates, surprises.

Do not touch: workspace `Cargo.toml`, `Cargo.lock`, `docs/`, `corpus.toml`,
crates outside `vendor/luaur-*`, `NUXIE_PROVENANCE.md`, or
`.luau-fork-work/` beyond the two report files.
