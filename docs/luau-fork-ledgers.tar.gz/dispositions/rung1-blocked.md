# Luau fork rung 1 skipped/blocked rows

## Require subsystem (intentionally skipped)

The pinned rive C++ runtime registers its own `lua_require` in `src/lua/rive_lua_libs.cpp`, does not compile Luau's `Require/` library, and luaur has no Require translation. Per the rung-1 lane directive, all `Require/` rows are skipped:

- `luarequire_Configuration::load` callback contract (`Require/include/Luau/Require.h`).
- `FFlag::LuauCyclicRequireShortCircuit` (`Require/src/RequireImpl.cpp`).
- `modulePlaceholdersKey` (`Require/src/RequireImpl.cpp`).
- `CyclicDependencyIndexError` (`Require/src/RequireImpl.cpp`).
- `CyclicDependencyNewIndexError` (`Require/src/RequireImpl.cpp`).
- `invalidateModulePlaceholder` (`Require/src/RequireImpl.cpp`).
- `kRequireStackValues` (`Require/src/RequireImpl.cpp`).
- `kRequireStackValues_DEPRECATED` (`Require/src/RequireImpl.cpp`).
- `lua_requirecont` (`Require/src/RequireImpl.cpp`).
- `lua_requireinternal` (`Require/src/RequireImpl.cpp`).

## Pre-existing focused-gate failure

`cargo test -p nuxie-scripting --lib` is red at the exact branch baseline (`9e29db02`) before rung-1 source changes. An archived baseline checkout reproduces `vm::context_init_tests::missing_or_non_function_init_latches_complete_without_blocking_dispatch` failing with `error converting Lua nil to Function`; the full suite also reports the same failure family in three adjacent optional-callback tests. `cargo check -p nuxie --features scripting` remains green. Row gates continue to run as required, but this baseline failure prevents a fully green test result.

## Orchestrator follow-up

`docs/luau-fork.md` requires every engine change to add a row to that central
fork record, but the rung-1 writer lane explicitly prohibits changes under
`docs/`. The orchestrator must add the Luau 0.725 rung row outside this lane.
