# Writer lane: luau-fork rung 6 (official 0.729 -> 0.730)

Production writer porting one upstream Luau release delta into Nuxie's
vendored luaur fork. Read `docs/luau-fork.md`, then
`.luau-fork-work/prompts/preamble.md`, then the binding ledger
`.luau-fork-work/inventory/job6.md`. C-side diff:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff 6e9b580e..e8ae48c4 -- VM Compiler Ast Common Config Require Bytecode Inliner`

Rungs 1-5 (0.725-0.729) are landed. Ledger dependency notes were written
against the 0.724 baseline — the following are NOW SATISFIED: `AstStatLocalFunction`
constKeywordBegin shape (rung 3/4), `LBC_VERSION_TARGET=7` + `LBC_VERSION_MAX=12`
(rungs 2/5), SCCP + `DenseHash2` foundation (rung 5). Verify each dependent
twin's current state before porting; mismatches -> blocked file.

## Protocol (identical to rungs 1-5)

1. STRUCTURE-PRESERVING; ROW-BY-ROW COMMITS with prefix
   `luau-fork rung6: <symbol> (<c-file>) [6e9b580e..e8ae48c4]`; plain
   commits, no trailers. Focused gate: `cargo check -p nuxie --features
   scripting` + `cargo test -p nuxie-scripting --lib`; after SCCP-touching
   groups also run `cargo test -p luaur-bytecode`.
2. FFLAG POLICY: removed flags `LuauCompileUdataDirect` (bytecode target 9
   unconditional), `LuauCompileInlineTableFunctions`,
   `LuauCompileNewTableMutationTracker` (delete
   `TableMutationTracker_DEPRECATED` entirely) hardwire upstream's kept
   sides, grep-complete. New flag `LuauMathRoundNegZero` (and any others
   marked Added) registers + pins `.set(false)` — its OFF scalar path must
   stay byte-identical to current behavior.
3. Atomic groups:
   a. Unsigned-class cluster (ONE group): `LuauClass`, `LuauObject`,
      `luaR_newclass`, lookup macros, GC/debug loops, `luaV_gettable`/
      `luaV_settable`, and the `GETTABLEKS`/`NAMECALL` interpreter arms —
      signed/unsigned must flip together; mirror C bounds semantics
      exactly.
   b. Bytecode-target-9 unit: flag removal + version-selection ladder
      update in getVersion, consistent with the landed v7 floor and v12
      cost-model gate.
   c. SCCP evaluator/driver additions on the rung-5 foundation.
   d. Mutation-tracker unification: keep the escape-based tracker, delete
      the deprecated one and its selection plumbing.
4. Rows in untranslated subsystems (Inliner/, Require/) defer with
   rationale -> `.luau-fork-work/rung6-blocked.md`; verified no-ops ->
   `.luau-fork-work/rung6-noop.md`.
5. End: rung-level `NUXIE_PATCH.md` entries ("Ported official Luau 0.730
   delta (upstream 6e9b580e..e8ae48c4)"), committed as
   `luau-fork rung6: NUXIE_PATCH.md rung entries`; one full
   `cargo test -p nuxie --features scripting`; fix forward only your own
   rows. Final message: dispositions, commits, gates, surprises.

Do not touch: workspace `Cargo.toml`, `Cargo.lock`, `docs/`, `corpus.toml`,
crates outside `vendor/luaur-*`, `NUXIE_PROVENANCE.md`, or
`.luau-fork-work/` beyond the two report files.
