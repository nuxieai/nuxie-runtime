# Luau 0.726 → 0.727 delta ledger

- Diff range: `86d2a9dc..f1f121dc`
- Scoped hunks: **186**
- Files changed: **28**
- Diff size: 867 insertions, 626 deletions
- Exact command used:

```sh
git -C /Users/levi/dev/oss/luigi-rosso-luau diff 86d2a9dc..f1f121dc -- VM Compiler Ast Common Config Require Bytecode Inliner
```

Default notation below distinguishes:

- **Raw default:** `LUAU_FASTFLAGVARIABLE(name)` initializes to OFF; `LuauGcTableStepFix` explicitly initializes OFF.
- **Luau release CLI default:** `setLuauFlagsDefault()` turns nonexperimental `Luau*` boolean flags ON.
- **Current luaur-rt default:** calls `luaur_common::set_all_flags(true)` during VM construction, subject to its explicit exceptions. Thus removed flags that are hardwired ON generally match current luaur-rt behavior; removing `LuauClosureUsageCounter` hardwires the opposite behavior.

No scoped `Bytecode/` or `Config/` file changed.

## Flag symbols

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| Ast/src/Parser.cpp; Ast/src/PrettyPrinter.cpp; Compiler/src/Compiler.cpp | G01 `LuauConst2` | Removes the flag and deprecated local-declaration parser. Const declarations, const lvalue rejection, export/const parsing, function binding constness, and pretty-printing become unconditional. | Removed; **flag-ON path hardwired**. Old raw default OFF; CLI/luaur-rt default ON. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | High parser/compiler surface. Remove both the flag definition and `set_all_flags` entry after all guarded twins are promoted. |
| Ast/src/Cst.cpp; Ast/src/Parser.cpp; Ast/src/PrettyPrinter.cpp | G02 `LuauCstTypeGroup` | Removes the guard/assert. Parenthesized type AST/CST group creation and CST-aware pretty-printing become unconditional. | Removed; **flag-ON path hardwired**. Old raw default OFF; CLI/luaur-rt default ON. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | CST fidelity and source-preserving output change. |
| Ast/src/Parser.cpp | G03 `LuauDisallowExternClassInTypeDefinitions` | Adds a flag that, when ON, stops accepting legacy `declare class` through this branch and treats `declare extern type ... with ...` as the supported form. | New; raw default OFF, release CLI ON if default flags are installed. | NONE-new | ENGINE | Parser compatibility flag; ON/OFF paths accept different declaration grammars. |
| Ast/src/Parser.cpp | G04 `LuauStoreConstKeywordBegin` | Adds a flag controlling whether `AstStatLocalFunction` stores the `const` keyword position. | New; raw default OFF stores `Position::missing()`; release CLI ON stores the real position. | NONE-new | ENGINE | New AST field must exist regardless of flag value. |
| Compiler/src/Compiler.cpp | G05 `LuauCompileNoOptNext` | Removes the flag and always refuses the `for ... in next, t` optimization when `getfenv` or `setfenv` is used. | Removed; **flag-ON path hardwired**. Old raw default OFF; CLI/luaur-rt default ON. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Raw-default compilation becomes more conservative; release-default behavior is unchanged. |
| Compiler/src/Compiler.cpp; Compiler/src/ConstantFolding.cpp; Compiler/src/CostModel.cpp | G06 `LuauCompilePropagateTableProps2` | Removes the flag and unconditionally enables table-constant/property propagation behavior. | Removed; **flag-ON path hardwired**. Old raw default OFF; CLI/luaur-rt default ON. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Broad optimization-state change; tightly coupled to G07. |
| Compiler/src/Compiler.cpp; Compiler/src/ConstantFolding.cpp; Compiler/src/CostModel.cpp | G07 `LuauCompileFoldOptimize` | Removes the flag and always uses change logs/undo, the primary table-constant map, and optimized cost-model semantics. | Removed; **flag-ON path hardwired**. Old raw default OFF; CLI/luaur-rt default ON. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Broad compiler behavior; must land atomically with all K01–K14 edits. |
| Compiler/src/CostModel.cpp | G08 `LuauCompileFastcall3CostModel` | Removes the flag and always treats builtins with up to three arguments as short FASTCALLs. | Removed; **flag-ON path hardwired**. Old raw default OFF; CLI/luaur-rt default ON. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Can change inlining/unrolling profitability and emitted bytecode. |
| VM/src/ldo.cpp; VM/src/lfunc.cpp; VM/src/lstate.cpp; VM/src/lvmexecute.cpp; VM/src/lvmutils.cpp | G09 `LuauClosureUsageCounter` | Deletes the flag, `Closure::usage`, initialization, and all call-entry/return/error-path increments and decrements. | Removed; **flag-OFF path hardwired**. Old raw default OFF; CLI/luaur-rt default ON. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | High layout risk: removes an eight-byte closure field. Release-default bookkeeping disappears. |
| VM/src/lvmexecute.cpp; VM/src/lbuiltins.cpp; VM/src/ldebug.cpp; VM/src/lfunc.cpp; VM/src/lgcdebug.cpp | G10 `LuauCIProto` | Adds CallInfo-owned active-proto plumbing. ON makes execution/debugging read `ci->p`; OFF continues reading the closure’s `l.p`. | New; raw default OFF uses closure proto; release CLI ON uses `CallInfo::p`. | NONE-new | ENGINE | High-risk cross-cutting VM flag; every frame creation path must initialize `p`. |
| VM/src/lvmexecute.cpp; VM/src/lfunc.h | G11 `LuauPromoteProto` | Adds lazy promotion through `Proto::optimized`; `getproto` mutates a closure to the newest optimized proto when ON. | New; raw default OFF returns `cl->l.p`; release CLI ON promotes. | NONE-new | ENGINE | Promotion is useful primarily with G10 ON; changes closure proto and stack size in place. |
| VM/src/lgc.cpp | G12 `LuauGcTableStepFix` | Adds corrected GC work accounting for tables using `luaH_dummynode`, excluding dummy-node storage. | New dynamic flag, explicit raw default OFF; release CLI flag setup would turn it ON. | NONE-new | ENGINE | GC pacing only; wrong accounting can alter collection cadence. |

## Ast

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| Ast/include/Luau/Ast.h | A01 `AstStatLocalFunction` | Adds `Position constKeywordBegin`; it is missing for non-const nodes or when storage is disabled. | G04: raw OFF stores missing; release CLI ON stores location. | `vendor/luaur-ast-0.1.8/src/records/ast_stat_local_function.rs` | ENGINE | AST layout/API change; all construction sites must supply the field. |
| Ast/include/Luau/Ast.h; Ast/src/Ast.cpp | A02 `AstStatLocalFunction::AstStatLocalFunction` | Removes constructor defaults, adds required `isConst` and `constKeywordBegin` arguments, and initializes the new field. | G04 indirectly controls the supplied position. | `vendor/luaur-ast-0.1.8/src/methods/ast_stat_local_function_ast_stat_local_function.rs` | ENGINE | Compile-time API break for constructors. |
| Ast/src/Cst.cpp | A03 `CstTypeGroup::CstTypeGroup` | Removes the assertion that `LuauCstTypeGroup` is enabled. | G02 removed; ON path assumed. | `vendor/luaur-ast-0.1.8/src/methods/cst_type_group_cst_type_group.rs` | ENGINE | Low runtime risk; required once grouped CST nodes are unconditional. |
| Ast/src/Parser.cpp | A04 `Parser::parseStat` | Always uses `parseLocal`, recognizes `const`, and removes `LuauConst2` from export parsing. | G01 removed/ON. `LuauExportValueSyntax`: raw OFF, CLI ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_stat.rs` | ENGINE | Syntax acceptance changes under raw defaults. |
| Ast/src/Parser.cpp | A05 `isExprLValue` | A const local is now always rejected as an lvalue. | G01 removed/ON. | `vendor/luaur-ast-0.1.8/src/functions/is_expr_l_value.rs` | ENGINE | Direct assignment-semantics change. |
| Ast/src/Parser.cpp | A06 `Parser::parseFunctionStat` | Always validates the parsed function name as an lvalue; diagnostic selection now depends only on export syntax. | G01 removed/ON; export flag raw OFF/CLI ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_function_stat.rs` | ENGINE | Const reassignment now rejected unconditionally. |
| Ast/src/Parser.cpp | A07 `Parser::parseAttributeStat` | Always routes local/const declarations through `parseLocal`; removes legacy diagnostics and all Const2 conjunctions. | G01 removed/ON; `LuauCstAttr` and export syntax raw OFF/CLI ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_attribute_stat.rs` | ENGINE | Depends on 0.726 attribute/CST signatures. |
| Ast/include/Luau/Parser.h; Ast/src/Parser.cpp | A08 `Parser::parseLocal_DEPRECATED` | Deletes the declaration and full legacy implementation. | G01 removed; legacy OFF path deleted. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_local_deprecated.rs` | ENGINE | Large deletion; callers must all use A09. |
| Ast/src/Parser.cpp | A09 `Parser::parseLocal` | Supplies the new local-function constructor argument: real const-keyword position only when G04 is ON. | G04 raw OFF/CLI ON; `LuauCstAttr` unchanged. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_local.rs` | ENGINE | Constructor and AST-field change must land together. |
| Ast/src/Parser.cpp | A10 `Parser::parseReturn` | Top-level export/return conflict checking no longer also requires Const2. | G01 removed/ON; export flag raw OFF/CLI ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_return.rs` | ENGINE | Diagnostic behavior changes only when export syntax is enabled. |
| Ast/src/Parser.cpp | A11 `Parser::parseDeclaration` | Adds G03 grammar split: ON disallows legacy `declare class` here and requires extern declarations to follow the `with` body path. | G03 raw OFF/CLI ON; `LuauAllowGlobalDeclarationToBeCalledClass` raw OFF/CLI ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_declaration.rs` | ENGINE | High compatibility risk for declaration syntax. |
| Ast/src/Parser.cpp | A12 `Parser::reportLValueError` | Const-local-specific error is now unconditional. | G01 removed/ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_report_l_value_error.rs` | ENGINE | Diagnostic-only after lvalue classification. |
| Ast/src/Parser.cpp | A13 `Parser::parseAssignment` | Both initial and comma-following assignment targets use `reportLValueError` based only on export syntax. | G01 removed/ON; export flag raw OFF/CLI ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_assignment.rs` | ENGINE | Const assignment errors change. |
| Ast/src/Parser.cpp | A14 `Parser::parseCompoundAssignment` | Same lvalue diagnostic promotion for compound assignments. | G01 removed/ON; export flag raw OFF/CLI ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_compound_assignment.rs` | ENGINE | Const compound assignments are always invalid. |
| Ast/src/Parser.cpp | A15 `Parser::parseFunctionBody` | Always constructs the local function binding with its `isConst` value; removes legacy two-argument binding path. | G01 removed/ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_function_body.rs` | ENGINE | Binding metadata affects later lvalue checks/compiler behavior. |
| Ast/src/Parser.cpp | A16 `Parser::parseReturnType` | Always materializes `AstTypeGroup` and its CST close position where applicable. | G02 removed/ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_return_type.rs` | ENGINE | AST shape changes even when CST storage is disabled. |
| Ast/src/Parser.cpp | A17 `Parser::parseFunctionType` | Always records `CstTypeGroup` when CST storage is enabled. | G02 removed/ON; CST storage remains an option. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_function_type.rs` | ENGINE | Source-preserving CST behavior. |
| Ast/src/Parser.cpp | A18 `Parser::parseAttributedFunction` | Formatting-only consolidation of the error-return call. | None. | NONE-untranslated | ENGINE | Function was added in the 0.726 rung; no current Rust twin exists. No behavioral port is needed for this hunk itself. |
| Ast/src/Parser.cpp | A19 `Parser::parseTypeParams` | Always wraps a single explicit-pack type as `AstTypeGroup`, copies its CST close position, and applies suffix parsing to the group. | G02 removed/ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_type_params.rs` | ENGINE | AST/CST shape affects pretty-printing and downstream visitors. |
| Ast/src/PrettyPrinter.cpp | A20 `Printer::visualize(AstStat&)` | Local and local-function printing always honors `isConst`; export printing no longer also depends on Const2. | G01 removed/ON; export flag raw OFF/CLI ON. | `vendor/luaur-ast-0.1.8/src/methods/printer_visualize_pretty_printer_alt_c.rs` | ENGINE | Four hunks; source text changes under raw defaults. |
| Ast/src/PrettyPrinter.cpp | A21 `Printer::visualizeTypeAnnotation` | Parenthesized types always consult `CstTypeGroup`, falling back to location-based closing-parenthesis output. | G02 removed/ON. | `vendor/luaur-ast-0.1.8/src/methods/printer_visualize_type_annotation.rs` | ENGINE | Source-position fidelity risk. |

## Common

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| Common/include/Luau/DenseHash.h | C01 `DenseHashSet::DenseHashSet` pointer-key overload | Adds a pointer-only constructor whose empty key defaults to `nullptr`. | None. | NONE-new | ENGINE | C++ default-argument convenience has no direct Rust equivalent; decide whether Rust needs a zero-argument pointer constructor. |
| Common/include/Luau/DenseHash.h | C02 `DenseHashSet::DenseHashSet` non-pointer overload | Constrains the existing explicit-empty-key constructor to non-pointer keys via SFINAE. | None. | `vendor/luaur-common-0.1.8/src/methods/dense_hash_set_dense_hash_set.rs` | ENGINE | Rust type system may already make the overload split unnecessary. |
| Common/include/Luau/DenseHash.h | C03 `DenseHashMap::DenseHashMap` pointer-key overload | Adds a pointer-only constructor whose empty key defaults to `nullptr`. | None. | NONE-new | ENGINE | Same language-specific API consideration as C01. |
| Common/include/Luau/DenseHash.h | C04 `DenseHashMap::DenseHashMap` non-pointer overload | Constrains the existing explicit-empty-key constructor to non-pointer keys via SFINAE. | None. | `vendor/luaur-common-0.1.8/src/methods/dense_hash_map_dense_hash_map.rs` | ENGINE | Existing Rust `new(empty_key)` remains the behavioral twin. |

## Compiler

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| Compiler/src/Compiler.cpp | K01 `Compiler::costModelInlinedCall` | Always clears change logs before folding and restores expression/local constant maps via `undoChanges`, instead of refolding to clean up. | G06/G07 removed; both ON assumed. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_cost_model_inlined_call.rs` | ENGINE | State-restoration correctness affects repeated inlining attempts. |
| Compiler/src/Compiler.cpp | K02 `Compiler::compileInlinedCall` | Same unconditional change-log/undo cleanup around compilation of an inlined body. | G06/G07 removed; both ON assumed. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_inlined_call.rs` | ENGINE | High risk of stale constant state if any mutation is omitted from logs. |
| Compiler/src/Compiler.cpp | K03 `Compiler::compileUnrolledFor` | Always records first-iteration fold changes, refolds later iterations, then undoes recorded expression/local changes. | G06/G07 removed; both ON assumed. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_unrolled_for.rs` | ENGINE | Can change unrolled-loop bytecode and compiler state after recompilation. |
| Compiler/src/Compiler.cpp | K04 `Compiler::compileStatForIn` | `next, table` specialization now requires that neither `getfenv` nor `setfenv` was used. | G05 removed; ON path assumed. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_stat_for_in.rs` | ENGINE | Conservative bytecode-generation change. |
| Compiler/src/Compiler.cpp | K05 `compileOrThrow` | Always builds the table-constant map before folding at optimization level ≥1. | G06/G07 removed; both ON assumed. | `vendor/luaur-compiler-0.1.8/src/functions/compile_or_throw_compiler.rs` | ENGINE | Required foundation for promoted table-property folding. |
| Compiler/src/ConstantFolding.cpp | K06 `constantsEqual` | Table constants are always compared by table index; the guarded assertion fallback is removed. | G06 removed; ON assumed. `LuauIntegerType2` remains raw OFF/CLI ON for integer cases. | `vendor/luaur-compiler-0.1.8/src/functions/constants_equal.rs` | ENGINE | Correct only while table indices refer to the same constant-table arena. |
| Compiler/src/ConstantFolding.cpp | K07 `TableMutationTracker_DEPRECATED::TableMutationTracker_DEPRECATED` | Removes the assertion that table-property propagation is enabled. | G06 removed/ON. | `vendor/luaur-compiler-0.1.8/src/methods/table_mutation_tracker_deprecated_table_mutation_tracker_deprecated.rs` | ENGINE | Deprecated tracker remains selected when the newer tracker flag is OFF. |
| Compiler/src/ConstantFolding.cpp | K08 `ConstantVisitor::analyze` | Always reads table locals, rejects table-valued builtin args, folds constant table indexing, and builds table constants for complete literal tables. | G06/G07 removed; ON behavior. | `vendor/luaur-compiler-0.1.8/src/methods/constant_visitor_analyze.rs` | ENGINE | Five hunks; largest constant-folding behavior promotion. |
| Compiler/src/ConstantFolding.cpp | K09 `ConstantVisitor::recordConstant` | Always logs changes, excludes table constants from the normal map, and clears old entries to Unknown when necessary. | G06/G07 removed; ON behavior. | `vendor/luaur-compiler-0.1.8/src/methods/constant_visitor_record_constant.rs` | ENGINE | Undo log completeness is essential. |
| Compiler/src/ConstantFolding.cpp | K10 `ConstantVisitor::recordValue` | Always stores table-valued locals separately and records scalar constants normally. | G06/G07 removed; ON behavior. | `vendor/luaur-compiler-0.1.8/src/methods/constant_visitor_record_value.rs` | ENGINE | Changes `Variable::constant` classification for tables. |
| Compiler/src/ConstantFolding.cpp | K11 `ConstantVisitor::visit(AstStatLocal*)` | Always checks table-valued initializers against the table-constant map before recording them. | G06 removed/ON. | `vendor/luaur-compiler-0.1.8/src/methods/constant_visitor_visit_constant_folding_alt_b.rs` | ENGINE | Mutation-analysis correctness controls whether table reads fold. |
| Compiler/src/ConstantFolding.cpp | K12 `buildTableConstantMap` | Removes the assertion requiring G06/G07. New-vs-deprecated mutation tracker selection remains. | `LuauCompileNewTableMutationTracker`: raw OFF uses deprecated tracker; CLI/luaur-rt ON uses new tracker. | `vendor/luaur-compiler-0.1.8/src/functions/build_table_constant_map.rs` | ENGINE | Both tracker paths must remain valid. |
| Compiler/src/ConstantFolding.cpp | K13 `foldConstants` | Deletes the temporary deprecated table map and post-pass table-constant erasure; always supplies the caller’s table map to `ConstantVisitor`. | G06/G07 removed; optimized ON path assumed. | `vendor/luaur-compiler-0.1.8/src/functions/fold_constants.rs` | ENGINE | Two hunks; must be coordinated with K05/K08–K12. |
| Compiler/src/CostModel.cpp | K14 `CostVisitor::model` | Any expression present in the constant map is treated as a literal, and builtins with ≤3 arguments use the short FASTCALL cost. | G06/G07/G08 removed; ON paths assumed. | `vendor/luaur-compiler-0.1.8/src/records/cost_visitor.rs` | ENGINE | Changes optimization profitability, not language semantics directly. The live implementation is co-located in the record file. |

## Require

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| Require/src/RequireImpl.cpp | Q01 `CyclicDependencyIndexError` | Removes unreachable `return 0` after `luaL_error`. | None. | NONE-untranslated | ENGINE | Function was introduced in 0.726; the Require subsystem is not translated in the vendored crates. |
| Require/src/RequireImpl.cpp | Q02 `CyclicDependencyNewIndexError` | Removes unreachable `return 0` after `luaL_error`. | None. | NONE-untranslated | ENGINE | Same as Q01; no behavioral delta because `luaL_error` does not return. |

## VM core and interpreter

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| VM/src/lstate.h | V01 `CallInfo` | Adds `Proto* p`, the active proto for the frame. | G10 raw OFF leaves most Lua-frame reads on closure proto; CLI ON requires populated `p`. | `vendor/luaur-vm-0.1.8/src/records/call_info.rs` | ENGINE | Critical `repr(C)` layout change; depends on 0.726’s savedpc/errfunc union port. |
| VM/src/lobject.h | V02 `Proto` | Adds `optimized` and `deoptimized` proto links. | Fields unguarded; use/promotion controlled by G11 and JIT-inliner setup. | `vendor/luaur-vm-0.1.8/src/records/proto.rs` | ENGINE | Critical GC object layout and graph change. |
| VM/src/lobject.h | V03 `Closure` | Removes the `uint64_t usage` field. | G09 removed; OFF path hardwired. | `vendor/luaur-vm-0.1.8/src/records/closure.rs` | ENGINE | Critical closure layout change. |
| VM/src/lfunc.h | V04 `getproto` | New macro returns null for C closures; otherwise optionally promotes and returns the Lua proto. | G11 raw OFF returns existing proto; CLI ON promotes. | NONE-new | ENGINE | Must preserve single evaluation and C-closure null behavior. |
| VM/src/lfunc.h | V05 `luaF_promoteproto` | New inline function follows `optimized` links, updates `cl->l.p` and `cl->stacksize`, then returns the latest proto. | Called by V04 when G11 ON. | NONE-new | ENGINE | Mutates closure state and assumes an acyclic optimized chain. |
| VM/src/lfunc.cpp | V06 `luaF_newproto` | Initializes `optimized` and `deoptimized` to null. | None. | `vendor/luaur-vm-0.1.8/src/functions/lua_f_newproto.rs` | ENGINE | Missing initialization would expose garbage GC links. |
| VM/src/lfunc.cpp | V07 `luaF_newLclosure` | Removes initialization of the deleted usage counter. | G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_f_new_lclosure.rs` | ENGINE | Must follow V03 layout removal. |
| VM/src/lfunc.cpp | V08 `luaF_newCclosure` | Removes initialization of the deleted usage counter. | G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_f_new_cclosure.rs` | ENGINE | Must follow V03 layout removal. |
| VM/src/lgc.cpp | V09 `traverseproto` | Marks both optimized and deoptimized proto links. | Unconditional. | `vendor/luaur-vm-0.1.8/src/functions/traverseproto.rs` | ENGINE | Essential to prevent linked protos from being collected. |
| VM/src/lgc.cpp | V10 `propagatemark` | Corrects table GC-work size for dummy-node tables when G12 is ON. | G12 raw OFF uses old `sizenode`; CLI ON excludes dummy node. | `vendor/luaur-vm-0.1.8/src/functions/propagatemark.rs` | ENGINE | GC pacing/accounting only. |
| VM/src/lgc.cpp | V11 `cleartable` | Applies the same dummy-node table-size correction while clearing weak tables. | G12 raw OFF old path; CLI ON fixed path. | `vendor/luaur-vm-0.1.8/src/functions/cleartable.rs` | ENGINE | Must match V10’s accounting formula. |
| VM/src/ldebug.cpp | V12 `currentpc` | Uses `ci->p` instead of the closure proto when G10 is ON. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/currentpc.rs` | ENGINE | Wrong proto makes saved-PC subtraction invalid. |
| VM/src/ldebug.cpp | V13 `currentline` | Resolves line information through `ci->p` when G10 is ON. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/currentline.rs` | ENGINE | Debug line correctness after promotion. |
| VM/src/ldebug.cpp | V14 `getluaproto` | Returns `ci->p` directly under G10; retains Lua-frame check on the OFF path. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/getluaproto.rs` | ENGINE | C-frame `p` must be null. |
| VM/src/ldebug.cpp | V15 `auxgetinfo` | Uses the call-info proto for source, line-defined, vararg, and parameter metadata when a frame is available. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/auxgetinfo.rs` | ENGINE | Two hunks; externally visible debug API data. |
| VM/src/lbuiltins.cpp | V16 `luauF_select` | Reads formal parameter count from `ci->p` under G10. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/luau_f_select.rs` | ENGINE | Affects negative-index `select` in vararg frames. |
| VM/src/ldo.cpp | V17 `luaD_pcall` | Removes unwound-frame usage-counter decrements. | G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_d_pcall.rs` | ENGINE | Error-unwind path must not reference removed closure storage. |
| VM/src/lgcdebug.cpp | V18 `dumpthread` | Tracks the first frame proto separately and uses `ci->p` for thread source, frame source, and local lookup under G10. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/dumpthread.rs` | ENGINE | Three hunks; debug-only but pointer arithmetic must use the active proto. |
| VM/src/lgcdebug.cpp | V19 `enumthread` | Uses the first call-info proto for enumerated thread source metadata under G10. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/enumthread.rs` | ENGINE | Debug enumeration only. |
| VM/src/lstate.cpp | V20 `stack_init` | Initializes the base call frame’s `p` to null. | Unconditional. | `vendor/luaur-vm-0.1.8/src/functions/stack_init.rs` | ENGINE | Required invariant for non-Lua/base frames. |
| VM/src/lstate.cpp | V21 `cleanupcistack` | Deletes the entire closure-usage cleanup helper. | G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/cleanupcistack.rs` | ENGINE | Remove module/export references as well as function body. |
| VM/src/lstate.cpp | V22 `lua_resetthread` | Stops calling usage cleanup and resets the base frame’s `p` to null. | G09 removed/OFF; `p` reset unconditional. | `vendor/luaur-vm-0.1.8/src/functions/lua_resetthread.rs` | ENGINE | Thread reuse must not retain a stale proto. |
| VM/src/lvmutils.cpp | V23 `luaV_callTM` | Initializes C metamethod frame `p` to null and removes usage-counter increment/decrement code. | G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_v_call_tm.rs` | ENGINE | All C-frame constructors need the null invariant. |
| VM/src/lvmexecute.cpp | V24 `VM_ASSERT_PC` | New centralized assertion bounds a PC against `ci->p` under G10 or the closure proto otherwise. | G10 raw OFF/CLI ON. | NONE-new | ENGINE | Debug assertion used by 51 later sites; macro expansion must have `L` and `cl` in scope. |
| VM/src/lvmexecute.cpp | V25 `VM_KV` | Constant-index assertion checks the active call-info proto’s constant count under G10. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/macros/vm_kv.rs` | ENGINE | The `k` pointer must be selected from the same proto. |
| VM/src/lvmexecute.cpp | V26 `luau_callhook` | End-PC comparison and line lookup use the active call-info proto under G10. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/luau_callhook.rs` | ENGINE | Two hunks; wrong proto corrupts hook line reporting. |
| VM/src/lvmexecute.cpp | V27 `luau_setupcci` | Stores `getproto(clvalue(fun))` in a new Lua frame when G10 is ON and removes usage increment. | G10 raw OFF/CLI ON; G11 affects `getproto`; G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/luau_setupcci.rs` | ENGINE | Cross-flag frame initialization. |
| VM/src/lvmexecute.cpp | V28 `luau_execute` entry/reentry state | Native entry reads `ci->p`; reentry asserts non-null and loads constants from it when G10 is ON. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/luau_execute.rs` | ENGINE | Central interpreter invariant. |
| VM/src/lvmexecute.cpp | V29 `luau_execute / LOP_LOADB` | Replaces direct closure-proto PC assertion with V24. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_c.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V30 `luau_execute / LOP_NEWCLOSURE` | Reads child proto and `sizep` from the active call-info proto under G10. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_s.rs` | ENGINE | Child-proto lookup must follow promoted caller bytecode. |
| VM/src/lvmexecute.cpp | V31 `luau_execute / LOP_CALL` | Populates callee `ci->p` through `getproto` and removes usage increment/decrement. | G10 raw OFF/CLI ON; G11 via V04; G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_u.rs` | ENGINE | Three hunks; primary call-frame path. |
| VM/src/lvmexecute.cpp | V32 `luau_execute / LOP_CALLFB` | Same active-proto initialization and usage-counter removal for feedback calls. | G10/G11; G09 removed. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_v.rs` | ENGINE | Three hunks; feedback/inlining call path. |
| VM/src/lvmexecute.cpp | V33 `luau_execute / LOP_RETURN` | Removes usage decrement and resumes the caller using `cip->p` under G10. | G10 raw OFF/CLI ON; G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_w.rs` | ENGINE | Return reentry must select matching code/constants. |
| VM/src/lvmexecute.cpp | V34 `luau_execute / LOP_JUMP` | Uses V24 for post-jump bounds assertion. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_x.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V35 `luau_execute / LOP_JUMPIF` | Uses V24 for selected target/fallthrough PC. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_y.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V36 `luau_execute / LOP_JUMPIFNOT` | Uses V24 for selected target/fallthrough PC. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_z.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V37 `luau_execute / LOP_JUMPIFEQ` | Replaces every type-specific/metamethod/fallback direct assertion with V24. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_aa.rs` | ENGINE | Eight hunks; assertion-only but all comparison exits are covered. |
| VM/src/lvmexecute.cpp | V38 `luau_execute / LOP_JUMPIFNOTEQ` | Replaces every type-specific/metamethod/fallback direct assertion with V24. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_ab.rs` | ENGINE | Eight hunks. |
| VM/src/lvmexecute.cpp | V39 `luau_execute / LOP_JUMPIFLE` | Uses V24 in numeric/string fast paths and metamethod path. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_ac.rs` | ENGINE | Two hunks. |
| VM/src/lvmexecute.cpp | V40 `luau_execute / LOP_JUMPIFNOTLE` | Uses V24 in numeric/string fast paths and metamethod path. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_ad.rs` | ENGINE | Two hunks. |
| VM/src/lvmexecute.cpp | V41 `luau_execute / LOP_JUMPIFLT` | Uses V24 in numeric/string fast paths and metamethod path. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_ae.rs` | ENGINE | Two hunks. |
| VM/src/lvmexecute.cpp | V42 `luau_execute / LOP_JUMPIFNOTLT` | Uses V24 in numeric/string fast paths and metamethod path. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_af.rs` | ENGINE | Two hunks. |
| VM/src/lvmexecute.cpp | V43 `luau_execute / LOP_FORNPREP` | Uses V24 after selecting loop entry/exit. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bf.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V44 `luau_execute / LOP_FORNLOOP` | Uses V24 on the loop-back path. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bg.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V45 `luau_execute / LOP_FORGPREP` | Uses V24 after generic-loop preparation. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bh.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V46 `luau_execute / LOP_FORGLOOP` | Uses V24 for table/general iteration continuation paths. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bi.rs` | ENGINE | Three hunks. |
| VM/src/lvmexecute.cpp | V47 `luau_execute / LOP_FORGPREP_INEXT` | Uses V24 after preparation. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bj.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V48 `luau_execute / LOP_FORGPREP_NEXT` | Uses V24 after preparation. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bk.rs` | ENGINE | Shares one diff hunk with V49. |
| VM/src/lvmexecute.cpp | V49 `luau_execute / LOP_NATIVECALL` | Selects native execution proto from `ci->p` under G10. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bl.rs` | ENGINE | Shares one hunk with V48; must enter native code for the active optimized proto. |
| VM/src/lvmexecute.cpp | V50 `luau_execute / LOP_GETVARARGS` | Reads formal parameter count from `ci->p` under G10. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bm.rs` | ENGINE | Affects vararg count and register range. |
| VM/src/lvmexecute.cpp | V51 `luau_execute / LOP_DUPCLOSURE` | Both eager and lazy clone paths pass `getproto(kcl)` under G10. | G10 raw OFF/CLI ON; G11 controls promotion. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bn.rs` | ENGINE | Two hunks; cloned closures must use promoted stack size/proto. |
| VM/src/lvmexecute.cpp | V52 `luau_execute / LOP_JUMPBACK` | Uses V24 after loop backedge. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bp.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V53 `luau_execute / LOP_JUMPX` | Uses V24 after extended jump. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_br.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V54 `luau_execute / LOP_FASTCALL` | Uses V24 for candidate CALL lookup and for successful skip destination. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bs.rs` | ENGINE | Two hunks. |
| VM/src/lvmexecute.cpp | V55 `luau_execute / LOP_FASTCALL1` | Uses V24 for candidate CALL lookup and successful skip destination. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bx.rs` | ENGINE | Two hunks. |
| VM/src/lvmexecute.cpp | V56 `luau_execute / LOP_FASTCALL2` | Uses V24 for candidate CALL lookup and successful skip destination. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_by.rs` | ENGINE | Two hunks. |
| VM/src/lvmexecute.cpp | V57 `luau_execute / LOP_FASTCALL2K` | Uses V24 for candidate CALL lookup and successful skip destination. | G10 through V24; V25 validates the constant operand. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_bz.rs` | ENGINE | Two hunks. |
| VM/src/lvmexecute.cpp | V58 `luau_execute / LOP_FASTCALL3` | Uses V24 for candidate CALL lookup and successful skip destination. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_ca.rs` | ENGINE | Two hunks. |
| VM/src/lvmexecute.cpp | V59 `luau_execute / LOP_BREAK` | Reads debug instruction data and computes its offset against the active call-info proto under G10. | G10 raw OFF/CLI ON. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_cb.rs` | ENGINE | Breakpoint restoration must use the bytecode actually executing. |
| VM/src/lvmexecute.cpp | V60 `luau_execute / LOP_JUMPXEQKNIL` | Uses V24 after conditional jump. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_cc.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V61 `luau_execute / LOP_JUMPXEQKB` | Uses V24 after conditional jump. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_cd.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V62 `luau_execute / LOP_JUMPXEQKN` | Uses V24 after conditional jump. | G10 through V24; V25 validates constant access. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_ce.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V63 `luau_execute / LOP_JUMPXEQKS` | Uses V24 after conditional jump. | G10 through V24; V25 validates constant access. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_cf.rs` | ENGINE | Assertion-only. |
| VM/src/lvmexecute.cpp | V64 `luau_execute / LOP_GETUDATAKS` | Removes usage-counter decrement from the C metamethod return path. | G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_cg.rs` | ENGINE | Call-frame pop must match V03/G09 removal. |
| VM/src/lvmexecute.cpp | V65 `luau_execute / LOP_SETUDATAKS` | Removes usage-counter decrement from the C metamethod return path. | G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_ch.rs` | ENGINE | Same as V64. |
| VM/src/lvmexecute.cpp | V66 `luau_execute / LOP_NAMECALLUDATA` | Removes usage-counter decrement from the C metamethod return path. | G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_ci.rs` | ENGINE | Same as V64. |
| VM/src/lvmexecute.cpp | V67 `luau_execute / LOP_CMPPROTO` | Uses V24 for non-function and mismatched-proto skip destinations. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_ck.rs` | ENGINE | Two hunks; actual `funid` comparison remains against `ccl->l.p`. |
| VM/src/lvmexecute.cpp | V68 `luau_finishop` | Uses V24 after completing the pending generic-loop operation. | G10 through V24. | `vendor/luaur-vm-0.1.8/src/functions/luau_finishop.rs` | ENGINE | Assertion-only, but macro must use active proto. |
| VM/src/lvmexecute.cpp | V69 `luau_precall` | Initializes `ci->p` through `getproto` for Lua calls and removes usage increment/decrement. | G10/G11; G09 removed. | `vendor/luaur-vm-0.1.8/src/functions/luau_precall.rs` | ENGINE | Two hunks; main non-interpreter call setup path. |
| VM/src/lvmexecute.cpp | V70 `luau_poscall` | Removes usage-counter decrement on return. | G09 removed/OFF. | `vendor/luaur-vm-0.1.8/src/functions/luau_poscall.rs` | ENGINE | Must not retain access to deleted `Closure::usage`. |

## Inliner/JIT-only additions

All symbols below are new in this rung, so their Rust status is `NONE-new`. The vendored project has no `Inliner` crate/module.

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| Inliner/include/Luau/JitInliner.h; Inliner/src/JitInliner.cpp | J01 `Luau::JitInliner::setup` | Installs `onInlineFunction` into `global->ecb.inlinefunction`. | No direct flag; only runs when API is called. | NONE-new | OUT-OF-SCOPE | Runtime JIT-inliner activation. |
| Inliner/include/Luau/JitInliner.h; Inliner/src/JitInliner.cpp | J02 `Luau::JitInliner::disable` | Clears the inline-function callback. | None. | NONE-new | OUT-OF-SCOPE | JIT-only. |
| Inliner/include/luajitinliner.h | J03 `LUAJITINLINER_API` | Adds configurable public API visibility macro, defaulting to `extern`. | None. | NONE-new | OUT-OF-SCOPE | C API/export decoration only. |
| Inliner/include/luajitinliner.h; Inliner/src/luajitinliner.cpp | J04 `luau_enable_jit_inliner` | Public C wrapper for J01. | None. | NONE-new | OUT-OF-SCOPE | Public but specifically JIT-only, so not RT-API for the non-JIT luaur fork. |
| Inliner/include/luajitinliner.h; Inliner/src/luajitinliner.cpp | J05 `luau_disable_jit_inliner` | Public C wrapper for J02. | None. | NONE-new | OUT-OF-SCOPE | JIT-only. |
| Inliner/src/JitInliner.cpp | J06 `buildGraphFromProto` | Converts a runtime `Proto` to a bytecode graph, preserving type info, constants, child-proto indices, lines, and optional call PC. | None. | NONE-new | OUT-OF-SCOPE | Depends on earlier bytecode-graph API rungs. |
| Inliner/src/JitInliner.cpp | J07 `kUnassignedPC` | Adds `~0u` sentinel for feedback slots without emitted PCs. | None. | NONE-new | OUT-OF-SCOPE | JIT metadata constant. |
| Inliner/src/JitInliner.cpp | J08 `emitCode` | Serializes a modified graph, folds/expands jumps, remaps instruction PCs, emits runtime code, and records CALLFB slot PCs. | None. | NONE-new | OUT-OF-SCOPE | Bytecode remapping correctness is critical to JIT feedback. |
| Inliner/src/JitInliner.cpp | J09 `createInlinedProto` | Allocates an optimized proto, copies metadata/constants/children/code/feedback, links caller↔optimized proto, and applies GC barrier. | None. | NONE-new | OUT-OF-SCOPE | High GC/layout risk but JIT-only. |
| Inliner/src/JitInliner.cpp | J10 `sealAllSlots` | Walks bytecode and seals every `LOP_CALLFB` slot with `0xffffffff`. | None. | NONE-new | OUT-OF-SCOPE | Failure fallback for JIT inlining. |
| Inliner/src/JitInliner.cpp | J11 `kMaxFunctionBytecodeSize` | Adds `0xffff` size cutoff for runtime inlining. | None. | NONE-new | OUT-OF-SCOPE | JIT policy constant. |
| Inliner/src/JitInliner.cpp | J12 `onInlineFunction` | Rejects invalid/recursive/already-optimized targets, follows optimized target chains, inlines the selected call, emits code, and links a new proto. | None; callback must be installed explicitly. | NONE-new | OUT-OF-SCOPE | Main runtime-JIT orchestration function. |
| Inliner/src/RuntimeBytecodeBuilder.h | J13 `CodeData` | New result record holding code, packed line info, and feedback-slot PC mapping. | None. | NONE-new | OUT-OF-SCOPE | Owns VM-allocated line-info pointers. |
| Inliner/src/RuntimeBytecodeBuilder.h | J14 `RuntimeBytecodeBuilder` | New `BytecodeBuilder` subclass backed by runtime constants, protos, and `lua_State`. | None. | NONE-new | OUT-OF-SCOPE | JIT-only bridge between bytecode library and VM memory. |
| Inliner/src/RuntimeBytecodeBuilder.h | J15 `RuntimeBytecodeBuilder::RuntimeBytecodeBuilder` | Stores VM state, runtime constants, child protos, and optional encoder. | None. | NONE-new | OUT-OF-SCOPE | Reference lifetime requirements. |
| Inliner/src/RuntimeBytecodeBuilder.h | J16 `RuntimeBytecodeBuilder::validateConst(int32_t)` | Asserts runtime constant index bounds. | None. | NONE-new | OUT-OF-SCOPE | Debug validation. |
| Inliner/src/RuntimeBytecodeBuilder.h | J17 `RuntimeBytecodeBuilder::constTypeToTT` | Maps bytecode constant kinds to VM type tags, including integer, class shape, closure, and table. | None. | NONE-new | OUT-OF-SCOPE | Must remain synchronized with both enum families. |
| Inliner/src/RuntimeBytecodeBuilder.h | J18 `RuntimeBytecodeBuilder::validateConst(int32_t, Constant::Type)` | Validates both constant index and expected runtime tag. | None. | NONE-new | OUT-OF-SCOPE | Debug validation. |
| Inliner/src/RuntimeBytecodeBuilder.h | J19 `RuntimeBytecodeBuilder::validateProto` | Validates child-proto index and returns its upvalue count. | None. | NONE-new | OUT-OF-SCOPE | JIT serializer validation. |
| Inliner/src/RuntimeBytecodeBuilder.h | J20 `RuntimeBytecodeBuilder::validateClosure` | Reads a closure constant and returns its upvalue count. | None. | NONE-new | OUT-OF-SCOPE | Assumes constant is a closure. |
| Inliner/src/RuntimeBytecodeBuilder.h | J21 `RuntimeBytecodeBuilder::printableStringConstant` | Rejects strings containing control characters for diagnostic printing. | None. | NONE-new | OUT-OF-SCOPE | Diagnostic-only. |
| Inliner/src/RuntimeBytecodeBuilder.h | J22 `RuntimeBytecodeBuilder::dumpConstant` | Formats all supported runtime constant tags for bytecode dumps. | None. | NONE-new | OUT-OF-SCOPE | Diagnostic formatting. |
| Inliner/src/RuntimeBytecodeBuilder.h | J23 `RuntimeBytecodeBuilder::finishAndDumpCode` | Finalizes code, optionally encodes it, allocates/packs VM line info, clears builder state, and returns `CodeData`. | None. | NONE-new | OUT-OF-SCOPE | Ownership, alignment, and zero-instruction assumptions need close review if ever ported. |

## FFlag disposition

| flag | rung action | behavior gated | raw engine default | release CLI/default-runner path | 0.727 unguarded/current path |
|---|---|---|---|---|---|
| `LuauConst2` | Removed | Const syntax, const bindings/lvalue errors, related export parsing/printing | OFF | ON | ON |
| `LuauCstTypeGroup` | Removed | Explicit grouped type AST/CST nodes and CST-aware closing parentheses | OFF | ON | ON |
| `LuauDisallowExternClassInTypeDefinitions` | Added | Reject legacy `declare class` branch; require extern type-definition form | OFF | ON | Guard retained |
| `LuauStoreConstKeywordBegin` | Added | Store real `const` keyword position on local-function AST nodes | OFF | ON | Guard retained |
| `LuauCompileNoOptNext` | Removed | Disable unsafe `next,t` specialization when environment mutation is possible | OFF | ON | ON |
| `LuauCompilePropagateTableProps2` | Removed | Table-literal/property constant propagation | OFF | ON | ON |
| `LuauCompileFoldOptimize` | Removed | Change-log/undo folding and primary table-constant-map implementation | OFF | ON | ON |
| `LuauCompileFastcall3CostModel` | Removed | Treat three-argument builtins as short FASTCALLs in the cost model | OFF | ON | ON |
| `LuauClosureUsageCounter` | Removed | Maintain `Closure::usage` across all frame entry/exit/unwind paths | OFF | ON | **OFF** |
| `LuauCIProto` | Added | Use active proto stored in `CallInfo` instead of closure `l.p` | OFF | ON | Guard retained |
| `LuauPromoteProto` | Added | Lazily replace a closure’s proto with the latest optimized proto | OFF | ON | Guard retained |
| `LuauGcTableStepFix` | Added (`DFFlag`) | Exclude dummy hash-node storage from GC work estimates | OFF explicitly | ON if passed through `setLuauFlagsDefault()` | Guard retained |

No FFlag was changed from an explicit true initializer to false or vice versa. No DFInt/FInt was added, removed, or flipped.

Important Rust consequence: `luaur-common/src/lib.rs::set_all_flags` is an explicit generated list. New flags require deliberate registration there if release-CLI semantics are desired; removed flags must be removed from both their definitions and that list.

## Hunk accounting

A hunk shared by multiple symbols is counted once below.

| c file | hunks | attributed symbols |
|---|---:|---|
| Ast/include/Luau/Ast.h | 1 | A01, A02 |
| Ast/include/Luau/Parser.h | 1 | A08 |
| Ast/src/Ast.cpp | 1 | A02 |
| Ast/src/Cst.cpp | 2 | G02, A03 |
| Ast/src/Parser.cpp | 26 | G01–G04, A04–A19 |
| Ast/src/PrettyPrinter.cpp | 5 | G01, G02, A20, A21 |
| Common/include/Luau/DenseHash.h | 3 | C01–C04 |
| Compiler/src/Compiler.cpp | 10 | G01, G05–G07, K01–K05 |
| Compiler/src/ConstantFolding.cpp | 14 | G06, G07, K06–K13 |
| Compiler/src/CostModel.cpp | 3 | G06–G08, K14 |
| Inliner/include/Luau/JitInliner.h | 1 | J01, J02 |
| Inliner/include/luajitinliner.h | 1 | J03–J05 |
| Inliner/src/JitInliner.cpp | 1 | J01, J02, J06–J12 |
| Inliner/src/RuntimeBytecodeBuilder.h | 1 | J13–J23 |
| Inliner/src/luajitinliner.cpp | 1 | J04, J05 |
| Require/src/RequireImpl.cpp | 1 | Q01, Q02 |
| VM/src/lbuiltins.cpp | 2 | G10, V16 |
| VM/src/ldebug.cpp | 3 | G10, V12–V15 |
| VM/src/ldo.cpp | 2 | G09, V17 |
| VM/src/lfunc.cpp | 4 | G09, G10, V06–V08 |
| VM/src/lfunc.h | 2 | G11, V04, V05 |
| VM/src/lgc.cpp | 4 | G12, V09–V11 |
| VM/src/lgcdebug.cpp | 5 | G10, V18, V19 |
| VM/src/lobject.h | 2 | V02, V03 |
| VM/src/lstate.cpp | 4 | G09, V20–V22 |
| VM/src/lstate.h | 1 | V01 |
| VM/src/lvmexecute.cpp | 81 | G09–G11, V24–V70 |
| VM/src/lvmutils.cpp | 4 | G09, V23 |
| **Total** | **186** | **All attributed** |

Completeness:

- Hunks total: **186**
- Hunks attributed: **186**
- Hunks unresolved: **0**
- Rows by class:
  - ENGINE: **123**
  - RT-API: **0**
  - OUT-OF-SCOPE: **23**

## Dependency notes

1. **0.726 parser attribute/CST work must precede parts of this rung.** A06–A09, A15, and A20 sit on the expanded attribute/CST signatures and `CstAttrList` handling changed in `91caa731..86d2a9dc`. A18 (`parseAttributedFunction`) was introduced in 0.726 and has no current Rust twin; its 0.727 hunk is formatting-only.

2. **0.726 CallInfo union layout precedes V01.** The 0.724 Rust `CallInfo` still has a plain `savedpc` field. C++ 0.726 changed that slot to the `savedpc`/`errfunc` union before 0.727 inserted `Proto* p`. Port the union rung first so `repr(C)` field order and all frame code remain aligned.

3. **The Require error helpers are 0.726 symbols.** Q01/Q02 cannot be patched independently until the 0.726 cyclic-module-placeholder Require implementation exists. No Require subsystem is present in the current vendored crates.

4. **The new Inliner module depends on earlier Bytecode rungs.** J06–J23 rely on the 0.725/0.726 `BytecodeGraph`, `BytecodeCallInliner`, `BytecodeOps`, graph parser/serializer, jump-remapping, and runtime-friendly `BytecodeBuilder` changes. They are JIT-only and remain out of scope for the non-JIT Rust engine.

5. **Optimized-proto execution is an atomic 0.727 cluster.** V01–V02, V04–V06, V09, V12–V16, V18–V20, V22–V28, V30–V33, V49–V51, V59, and V69 collectively establish the `CallInfo::p` invariant. Enabling G10 before every Lua/C/base frame constructor is updated risks null or stale proto dereferences.

6. **Promotion additionally requires G11 and proto GC links.** V04/V05 must not land enabled without V02 initialization and V09 marking. Otherwise optimized/deoptimized protos can be uninitialized or collected.

7. **Closure-usage removal is another atomic cluster.** G09, V03, V07–V08, V17, V21–V23, V27, V31–V33, V64–V66, V69, and V70 must land together because the field disappears from `Closure`.

8. No opcode or bytecode enum value is added in this rung. All changed interpreter cases target opcodes already present at the 0.724 baseline.