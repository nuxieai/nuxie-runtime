# Writer lane: luau-fork rung 8 (official 0.731 -> 0.732)

Production writer porting one upstream Luau release delta into Nuxie's
vendored luaur fork. Read `docs/luau-fork.md`, then
`.luau-fork-work/prompts/preamble.md`, then the binding ledger
`.luau-fork-work/inventory/job8.md` (266 hunks). C-side diff:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff f8ca77ac..decb2d05 -- VM Compiler Ast Common Config Require Bytecode Inliner`

Rungs 1-7 (0.725-0.731) are landed. Ledger dependency notes written against
the 0.724 baseline that are NOW SATISFIED: CST attribute split (rung 2),
custom-pcall unit incl. `luaL_pcallyieldable` + HANDLE/resume machinery
(rung 1), class parser/compiler/VM foundation and `vectorPrecision` API
(rung 7), cost-model framing (rung 5), export-value parser (rung 1),
`LuauXpcallFixMessageYieldPath` (rung 7). Verify each dependent twin before
porting; mismatches -> blocked file. Require/ and Config-source rows in
untranslated subsystems defer with the standing rationale (note: helpers the
ledger marks as used unconditionally by the BYTECODE API must be ported if
their consumers live in translated crates — check each consumer's crate
before deferring).

## Protocol (identical to rungs 1-7)

1. STRUCTURE-PRESERVING; ROW-BY-ROW COMMITS with prefix
   `luau-fork rung8: <symbol> (<c-file>) [f8ca77ac..decb2d05]`; plain
   commits, no trailers. Focused gate: `cargo check -p nuxie --features
   scripting` + `cargo test -p nuxie-scripting --lib`; bytecode/SCCP groups
   also `cargo test -p luaur-bytecode`.
2. FFLAG POLICY: removed flags `LuauCstAttr`,
   `LuauTableEntriesDontNeedToMatchIndent`, `LuauCustomYieldablePcalls`
   hardwire their former ON paths grep-complete (for CustomYieldablePcalls
   that includes deleting the legacy `luaD_pcall`-based pcall/xpcall
   branches and the rung-1 assertion helpers that guarded them, exactly as
   upstream does). New flags `LuauCompileEmitVectorDouble`,
   `LuauOptimizeExportTable`, `LuauRbsConfigAliasResolution`,
   `LuauManagedDebugNames` (and any others marked Added) register + pin
   `.set(false)`; their OFF paths stay byte-identical. Version-metadata
   bumps (`LuauExportValueSyntax` v4, `LuauBytecodeCostModel` v2) via the
   flagversion machinery.
3. Atomic groups:
   a. Class-inheritance unit: `LOP_NEWCLASS`, the class-shape/bytecode
      version constants the ledger names, `super` parsing/compilation,
      `luaR_inheritclass`, and the VM/GC representation rows — ONE group
      on the rung-7 class base; verify constant numbering against
      `git show decb2d05:Common/include/Luau/Bytecode.h`.
   b. Custom-pcall retirement: flag removal + legacy-path deletion +
      `resume_handle`/`resume_finish` reconciliation with the retained
      `LuauXpcallFixMessageYieldPath` subpath.
   c. Bytecode v13 double-vector constants (`LuauCompileEmitVectorDouble`,
      dark): compiler emission + any unconditional loader acceptance —
      mirror C's gating exactly on both sides.
   d. Export-table optimization (`LuauOptimizeExportTable`, dark): the
      ledger's elimination rules land together.
   e. Managed debug names (`LuauManagedDebugNames`, dark): both storage
      representations preserved behind the flag.
   f. CstAttr retirement: hardwire ON across parser/CST/printer, deleting
      `parseAttribute_DEPRECATED` exactly as upstream does.
4. Deferred rows -> `.luau-fork-work/rung8-blocked.md`; verified no-ops ->
   `.luau-fork-work/rung8-noop.md`.
5. End: rung-level `NUXIE_PATCH.md` entries ("Ported official Luau 0.732
   delta (upstream f8ca77ac..decb2d05)"), committed as
   `luau-fork rung8: NUXIE_PATCH.md rung entries`; one full
   `cargo test -p nuxie --features scripting`; fix forward only your own
   rows. Final message: dispositions, commits, gates, surprises.

Do not touch: workspace `Cargo.toml`, `Cargo.lock`, `docs/`, `corpus.toml`,
crates outside `vendor/luaur-*`, `NUXIE_PROVENANCE.md`, or
`.luau-fork-work/` beyond the two report files.
