# Job 0: baseline audit — where does luaur 0.1.8 ACTUALLY sit?

luaur 0.1.8's README claims validation against official Luau `8f33df9`
(release 0.724). Prior triage evidence suggests its effective base may LAG
that claim in places ("advertised range lags official Luau" — bytecode
evidence). Before porting rung deltas on top, we must know the true base per
subsystem, or rung ports will silently assume context that isn't there.

Audit the vendored Rust translation against the C sources at commit
`8f33df91` in `/Users/levi/dev/oss/luigi-rosso-luau` (use `git -C ... show
8f33df91:<path>`). High-signal anchors to compare (verify each in BOTH trees,
cite exact lines):

1. Bytecode versioning: `LBC_VERSION_MIN` / `LBC_VERSION_MAX` /
   `LBC_VERSION_TARGET` and type-info version constants in
   `Common/include/Luau/BytecodeUtils.h` / `Bytecode.h` vs the Rust twins in
   `vendor/luaur-bytecode-0.1.8` / `vendor/luaur-common-0.1.8`.
2. The opcode enum: full `LuauOpcode` list + order vs the Rust enum, and the
   set of `vm_case_lvmexecute_alt_*.rs` interpreter cases (count and coverage).
3. The builtin-function enum (`LuauBuiltinFunction`, `LBF_*`): full list +
   order vs the Rust enum, plus the fast-call dispatch table contents.
4. FFlags: enumerate FFlag/DFFlag uses in the C sources at 8f33df91 for VM/
   and Compiler/, then determine how luaur handled each (baked ON, baked OFF,
   made a runtime option, or omitted). A skewed flag baking is an effective
   base divergence.
5. `lua_pushcclosurek` and the `api_check`/stack-assertion discipline in
   `VM/src/lapi.cpp` vs `vendor/luaur-vm-0.1.8/src/functions/
   lua_pushcclosurek.rs` (a known downstream symptom SIGTRAPs on this
   assertion — record exactly what the Rust assertion enforces vs C at base).
6. Userdata/typeinfo surface: `lua_newuserdatatagged`, userdata tag limits,
   `LUA_UTAG_LIMIT`/`LUA_LUTAG_LIMIT` constants, and the udatadirectfields
   area if present at base.
7. Compiler: `CompileOptions` fields, optimization/debug level semantics, and
   the builtin-folding table vs Rust.
8. Version strings or release markers embedded anywhere in the Rust crates.

Output: a markdown report with (a) per-subsystem verdict — "matches 0.724",
"pre-0.724 (matches release N or commit X)", or "diverges: <detail>"; (b) a
table of every concrete discrepancy found (C cite vs Rust cite); (c) a list
of anchors you could NOT resolve. Print the report as your final message; do
not write files.
