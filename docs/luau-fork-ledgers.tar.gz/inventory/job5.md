# Rung inventory: official Luau 0.728 → 0.729

- Diff range: `ddcea05e..6e9b580e`
- Scoped hunk count: **70**
- Repository: `/Users/levi/dev/oss/luigi-rosso-luau`
- Exact source command:

```sh
git -C /Users/levi/dev/oss/luigi-rosso-luau diff ddcea05e..6e9b580e -- VM Compiler Ast Common Config Require Bytecode Inliner
```

Hunk identifiers below are file-local (`H1`, `H2`, etc.), in diff order. Struct rows include changed fields and nested aliases; explicitly declared functions, enums, macros/flags, and named constants receive separate rows. All claimed Rust paths were checked and exist.

## Symbol ledger

### Ast and parser

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Ast/include/Luau/Ast.h` H2 | `AstTypeReference` | Adds nullable `AstLocal* prefixLocal`, preserving the binding behind a qualified type prefix such as `T.X`. | Field unconditional; parser normally supplies null while `LuauTrackPrefixLocal=false`. | [ast_type_reference.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-ast-0.1.8/src/records/ast_type_reference.rs) | ENGINE | AST layout and all constructors must stay synchronized. |
| `Ast/include/Luau/Ast.h` H1; `Ast/src/Ast.cpp` H1-H2 | `AstTypeReference::AstTypeReference` | Adds a defaulted `prefixLocal` parameter and stores it in the new field. | None; unconditional. | [ast_type_reference_ast_type_reference.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-ast-0.1.8/src/methods/ast_type_reference_ast_type_reference.rs) | ENGINE | Every construction path needs the extra argument/default. |
| `Ast/src/Parser.cpp` H1 | `LuauTrackPrefixLocal` | New FFlag controlling lookup of the prefix name in `Parser::localMap`. | New default `false`; OFF leaves `prefixLocal=null`. | NONE-new | ENGINE | Flag registration/set-all-flags surface must be added with the behavior. |
| `Ast/src/Parser.cpp` H1 | `LuauNoDuplicateBinaryPrefix` | New FFlag for rejecting a second `0b`/`0B` after the lexer has stripped the first prefix. | New default `false`; OFF retains libc-dependent parsing. | NONE-new | ENGINE | Rust parsing already tends to reject this input; retain the flag surface faithfully. |
| `Ast/src/Parser.cpp` H2-H4 | `Parser::parseSimpleType` | Tracks a qualified type prefix’s local binding when enabled and passes it into `AstTypeReference`. | `LuauTrackPrefixLocal=false`: default path stores null. | [parser_parse_simple_type.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-ast-0.1.8/src/methods/parser_parse_simple_type.rs) | ENGINE | Requires the new AST field and constructor first. |
| `Ast/src/Parser.cpp` H5 | `parseInteger` | For base 2, rejects remaining leading `0b`/`0B` as malformed before `strtoull`. | `LuauNoDuplicateBinaryPrefix=false`: explicit check skipped. | [parse_integer.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-ast-0.1.8/src/functions/parse_integer.rs) | ENGINE | Preserve malformed-vs-overflow result ordering. |
| `Ast/src/Parser.cpp` H6 | `parseInteger64` | Applies the same duplicate-binary-prefix rejection to binary integer literals with the `i` suffix. | `LuauNoDuplicateBinaryPrefix=false`: explicit check skipped. | [parse_integer_64.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-ast-0.1.8/src/functions/parse_integer_64.rs) | ENGINE | Keep suffix validation and overflow precedence unchanged. |

### Bytecode format, builder, and graph

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Bytecode/include/Luau/BytecodeBuilder.h` H1; `Bytecode/src/BytecodeBuilder.cpp` H2-H3 | `BytecodeBuilder::endFunction` | Adds `uint64_t cost=0` and forwards it to `writeFunction`. | Signature unconditional; serialization remains flag-gated. | [bytecode_builder_end_function.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_end_function.rs) | ENGINE | All compiler call sites and the Rust signature must change together. |
| `Bytecode/include/Luau/BytecodeBuilder.h` H2; `Bytecode/src/BytecodeBuilder.cpp` H6-H7 | `BytecodeBuilder::writeFunction` | Accepts cost; for inlinable functions under v12 writes feedback placeholder if necessary, then a varint64 cost. | `LuauBytecodeCostModel=false`: no cost tail. `LuauEmitCallFeedback=false` while cost flag ON writes zero feedback count first. | [bytecode_builder_write_function.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_write_function.rs) | ENGINE | Field ordering must exactly match both loaders. |
| `Bytecode/src/BytecodeBuilder.cpp` H1 | `LuauBytecodeCostModel` | New compiler-side FFlag selecting bytecode v12 cost serialization. | New default `false`; release-default compiler does not emit v12. | NONE-new | ENGINE | Distinct from VM/graph flag `LuauCostModel`; mismatched settings can misalign graph parsing. |
| `Bytecode/src/BytecodeBuilder.cpp` H4-H5 | `BytecodeBuilder::finalize` | Prefixes every serialized proto blob with its byte length when v12 is enabled. | `LuauBytecodeCostModel=false`: old concatenated layout. | [bytecode_builder_finalize.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_finalize.rs) | ENGINE | Length must describe only `func.data`, not the prefix itself. |
| `Bytecode/src/BytecodeBuilder.cpp` H8 | `BytecodeBuilder::getVersion` | Returns bytecode version 12 before considering existing version-11/10/etc. flags. | `LuauBytecodeCostModel=false`: existing version-selection chain executes. | [bytecode_builder_get_version.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_get_version.rs) | ENGINE | Ordering makes cost model dominate `LuauEmitCallFeedback`. |
| `Bytecode/src/BytecodeGraph.cpp` H1; `VM/src/lvmload.cpp` H1 | `LuauCostModel` | New runtime/graph FFlag definition plus graph-side declaration; gates consumption of serialized cost metadata by `fromFunctionBytecode`. | New default `false`; graph parser does not consume cost. VM `loadsafe` still accepts/parses v12 unconditionally. | NONE-new | ENGINE | Independent compiler/runtime flags are a compatibility hazard. |
| `Bytecode/src/BytecodeGraph.cpp` H1 | `LuauCallFeedback` declaration | Makes the existing VM flag visible so graph deserialization can skip feedback descriptions. | Existing default `false`; OFF does not consume feedback data. | [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs) | ENGINE | Declaration is new here; the flag itself predates this rung. |
| `Bytecode/src/BytecodeGraph.cpp` H2 | `fromFunctionBytecode` | After debug data, consumes call-feedback slot descriptions and then the inlinable-function cost when their flags are enabled. | Both `LuauCallFeedback` and `LuauCostModel` default OFF. | [from_function_bytecode.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-bytecode-0.1.8/src/functions/from_function_bytecode.rs) | ENGINE | Flag mismatch leaves `offset` pointed into metadata instead of the graph payload. |
| `Common/include/Luau/Bytecode.h` H1-H2 | `LuauBytecodeTag::LBC_VERSION_MAX` | Documents version 12 and raises the maximum accepted bytecode version from 11 to 12. | None; unconditional acceptance limit. | [luau_bytecode_tag.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/enums/luau_bytecode_tag.rs) | ENGINE | Must land with v12 loader support, not emission alone. |

### New SCCP subsystem

Both SCCP files are new single-hunk additions. Nothing in this scoped diff invokes the pass yet; these are still ENGINE work because they extend the translated Bytecode module.

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Bytecode/include/Luau/Sccp.h` H1 | `VmConstOps` | Adds the abstract constant-operation interface used by generic SCCP evaluation. | None; subsystem currently unwired. | NONE-new | ENGINE | Natural Rust shape is a trait, but semantics must mirror the C++ interface. |
| same | `VmConstOps::evaluate` | Abstract binary arithmetic evaluator returning an optional constant operand. | None. | NONE-new | ENGINE | Opcode and numeric edge cases are semantic. |
| same | `VmConstOps::falsey` | Abstract Luau-truthiness test for constants. | None. | NONE-new | ENGINE | Only nil and false are falsey. |
| same | `VmConstOps::cmp(BcOp,BcOp)` | Abstract three-way constant comparison. | None. | NONE-new | ENGINE | Requires compatible kinds. |
| same | `VmConstOps::cmp(BcOp,BcImm)` | Abstract comparison between VM constant and immediate. | None. | NONE-new | ENGINE | Mixed numeric conversions matter. |
| same | `VmConstOps::makeNil` | Abstract nil-constant constructor. | None. | NONE-new | ENGINE | Must deduplicate VM constants in implementation. |
| same | `VmConstOps::makeImm(bool)` | Abstract boolean-immediate constructor. | None. | NONE-new | ENGINE | Overload needs a distinct Rust representation. |
| same | `VmConstOps::makeImm(int32_t)` | Abstract integer-immediate constructor. | None. | NONE-new | ENGINE | Preserve signed 32-bit range. |
| same | `VmConstOps::isOrderable` | Abstract predicate for number/integer/string ordering. | None. | NONE-new | ENGINE | Boolean and nil are deliberately excluded. |
| same | `VmConstOps::kindEquals` | Abstract constant-kind equality predicate. | None. | NONE-new | ENGINE | Separate from value equality. |
| same | `VmConstOps::eq(BcOp,BcOp)` | Abstract optional equality across constant operands. | None. | NONE-new | ENGINE | Unsupported comparisons return no result, not false. |
| same | `VmConstOps::eq(BcOp,bool)` | Abstract boolean comparison overload. | None. | NONE-new | ENGINE | Preserve optional result. |
| same | `VmConstOps::eq(BcOp,int32_t)` | Abstract integer comparison overload. | None. | NONE-new | ENGINE | Numbers and integers both participate. |
| same | `VmConstOps::isArithmeticConstant` | Abstract predicate restricted to numeric arithmetic constants. | None. | NONE-new | ENGINE | Integer VM constants intentionally return false. |
| same | `VmConstOps::asImm` | Abstract conversion to an immediate reference. | None. | NONE-new | ENGINE | Reference lifetime follows the graph arena. |
| same | `VmConstOps::VmConstOps()` | Default constructor. | None. | NONE-new | ENGINE | Mechanical interface support. |
| same | `VmConstOps::~VmConstOps` | Virtual default destructor. | None. | NONE-new | ENGINE | Trait-object/vtable equivalent required. |
| same | `VmConstOps::VmConstOps(const VmConstOps&)` | Defaulted copy constructor. | None. | NONE-new | ENGINE | Mechanical ownership semantics. |
| same | `VmConstOps::VmConstOps(VmConstOps&&)` | Deletes move construction. | None. | NONE-new | ENGINE | Rust port should not introduce divergent movable state. |
| same | `VmConstOps::operator=(const VmConstOps&)` | Defaulted copy assignment. | None. | NONE-new | ENGINE | Mechanical ownership semantics. |
| same | `VmConstOps::operator=(VmConstOps&&)` | Deletes move assignment. | None. | NONE-new | ENGINE | Rust ownership model must preserve intended immobility. |
| `Bytecode/include/Luau/Sccp.h` H1 | `BcVmConstImpl` | Concrete `VmConstOps` implementation holding a mutable `BcFunction<BcVmConst>&`. | None. | NONE-new | ENGINE | Lifetime/aliasing of the mutable graph is central. |
| same | `BcVmConstImpl::BcVmConstImpl` | Initializes the constant-operation implementation from a bytecode function. | None. | NONE-new | ENGINE | Must retain graph identity for deduplication. |
| `Sccp.h` H1; `Sccp.cpp` H1 | `BcVmConstImpl::evaluate` | Constant-folds ADD/SUB/MUL/DIV/MOD/POW/IDIV for two numeric VM constants; rejects zero divisors. | None. | NONE-new | ENGINE | Preserve floor-based modulo/idiv and IEEE behavior. |
| same | `BcVmConstImpl::falsey` | Returns true for nil or false across VM-constant/immediate operands. | None. | NONE-new | ENGINE | Other kinds remain truthy. |
| same | `BcVmConstImpl::cmp(BcOp,BcOp)` | Three-way compares equal-kind numbers, integers, booleans, or strings. | None. | NONE-new | ENGINE | Boolean unequal comparison returns `1`, not ordering by value. |
| same | `BcVmConstImpl::cmp(BcOp,BcImm)` | Compares numeric/integer/boolean VM constants to immediates; asserts incompatible types. | None. | NONE-new | ENGINE | Assertion behavior is part of debug parity. |
| same | `BcVmConstImpl::makeNil` | Creates/deduplicates a nil VM constant. | None. | NONE-new | ENGINE | Relies on `findOrAddConst`. |
| same | `BcVmConstImpl::makeImm(bool)` | Constructs boolean `BcImm`. | None. | NONE-new | ENGINE | Set both kind and value. |
| same | `BcVmConstImpl::makeImm(int32_t)` | Constructs integer `BcImm`. | None. | NONE-new | ENGINE | Set both kind and value. |
| same | `BcVmConstImpl::asImm` | Delegates to `BcFunction::imm`. | None. | NONE-new | ENGINE | Reference validity follows graph storage. |
| same | `BcVmConstImpl::isOrderable` | Accepts number, integer, and string VM constants. | None. | NONE-new | ENGINE | Exact kind set matters for branch folding. |
| same | `BcVmConstImpl::kindEquals` | Compares the two VM constant kinds. | None. | NONE-new | ENGINE | Assumes both operands index VM constants. |
| same | `BcVmConstImpl::eq(BcOp,BcOp)` | Handles number/integer cross-equality, strings, boolean VM/imm, and equal-kind immediates. | None. | NONE-new | ENGINE | Unsupported cases return `nullopt`. |
| same | `BcVmConstImpl::eq(BcOp,bool)` | Compares only boolean VM constants. | None. | NONE-new | ENGINE | Non-booleans remain unknown. |
| same | `BcVmConstImpl::eq(BcOp,int32_t)` | Compares immediate integer against numeric or integer VM constants. | None. | NONE-new | ENGINE | Numeric cast parity matters. |
| same | `BcVmConstImpl::isArithmeticConstant` | Returns true only for numeric VM constants. | None. | NONE-new | ENGINE | Integer kind is deliberately excluded. |
| `Bytecode/include/Luau/Sccp.h` H1 | `Constness` | Adds four-state lattice enum: Undetermined, NotAConstant, VmConstant, ImmConstant. | None. | NONE-new | ENGINE | Top/bottom interpretation must not be inverted. |
| same | `ConstnessLattice` | Adds kind plus optional VM/immediate constant payloads. | None. | NONE-new | ENGINE | Payload must agree with `kind`. |
| same | `ConstnessLattice::ConstnessLattice()` | Default-constructs lattice top (`Undetermined`). | None. | NONE-new | ENGINE | Default state drives SCCP convergence. |
| same | `ConstnessLattice::ConstnessLattice(Constness,BcOp)` | Constructs a VM-constant lattice element and asserts matching kind. | None. | NONE-new | ENGINE | Preserve assertion. |
| same | `ConstnessLattice::ConstnessLattice(Constness,BcImm)` | Constructs an immediate-constant lattice element and asserts matching kind. | None. | NONE-new | ENGINE | Clears the VM payload explicitly. |
| same | `ConstnessLattice::ConstnessLattice(Constness)` | Constructs a payload-free lattice state. | None. | NONE-new | ENGINE | Used for top/bottom. |
| same | `ConstnessLattice::merge` | Meets with top yielding the other operand; equal constants survive; disagreement falls to NotAConstant. | None. | NONE-new | ENGINE | Lattice direction is easy to reverse accidentally. |
| same | `ConstnessLattice::operator==` | Compares kind and the relevant optional payload. | None. | NONE-new | ENGINE | Top and bottom compare equal by kind alone. |
| same | `ConstnessLattice::operator!=` | Negates equality. | None. | NONE-new | ENGINE | Mechanical. |
| same | `ConditionState` | Adds AlwaysFalse, AlwaysTrue, and Unknown branch states. | None. | NONE-new | ENGINE | Drives executable-edge decisions. |
| same | `JumpTarget` | Adds dead flag, block operand, and condition state. | None. | NONE-new | ENGINE | Default condition is Unknown. |
| same | `OpConstness` | Adds hash-map alias from `BcOp` to lattice state. | None. | NONE-new | ENGINE | Requires `BcOpHash` equivalence. |
| same | `SccpState` | Adds the operand-constness map container. | None. | NONE-new | ENGINE | Missing entries default through map indexing. |
| same | `SccpState::operandLattice` | Forces projections, VM registers, and upvalues to NotAConstant; otherwise reads/inserts map state. | None. | NONE-new | ENGINE | `operator[]` insertion behavior is intentional. |
| same | `SccpState::unknownConditionConstness` | Returns bottom if any input is bottom, otherwise top. | None. | NONE-new | ENGINE | Does not recognize a constant unless separately evaluated. |
| `Bytecode/src/Sccp.cpp` H1 | `threeWay<T>` | Adds generic `-1/0/1` comparison helper. | None. | NONE-new | ENGINE | Floating NaN produces zero because both comparisons are false. |
| same | `findOrAddConst` | Linearly deduplicates a VM constant before appending it to the graph. | None. | NONE-new | ENGINE | Equality and stable indices must match existing graph storage. |

### Common `DenseHash2` and hash utility

`DenseHash2.h` is one new 911-line hunk. It has no use site in this scoped rung, but every symbol is inventory-listed because it is new Common engine infrastructure.

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Common/include/Luau/DenseHash2.h` H1 | `detail::countTrailingZeroes` | Adds 64-bit trailing-zero helper using compiler intrinsics or a fallback loop. | None. | NONE-new | ENGINE | Fallback refers to undefined `x` instead of `word`; C++ only compiles there on unsupported toolchains. |
| same | `detail::DenseHashTable2` | Adds raw-storage hash table using presence bits, Fibonacci hashing, linear probing, and erase without tombstones. | None. | NONE-new | ENGINE | Core capacity/probe/ownership invariants are high risk. |
| same | `DenseHashTable2::BitSet` | Adds occupancy bitset with raw allocated `uint64_t` words and nested `BitsetT` alias. | None. | NONE-new | ENGINE | Allocation and copy/move lifetime must be exact. |
| same | `BitSet::numElements` | Named constant equal to bits per occupancy word. | None. | NONE-new | ENGINE | Assumed power of two. |
| same | `BitSet::numElementsLog2` | Named constant `6` for 64-bit occupancy words. | None. | NONE-new | ENGINE | Must change with backing word width. |
| same | `BitSet::BitSet(size_t)` | Allocates/zeroes enough occupancy words for a power-of-two capacity. | None. | NONE-new | ENGINE | Capacity zero and sub-64 capacity are special cases. |
| same | `BitSet::~BitSet` | Frees occupancy storage. | None. | NONE-new | ENGINE | Raw ownership. |
| same | `BitSet::BitSet(const BitSet&)` | Deep-copies occupancy storage. | None. | NONE-new | ENGINE | Preserve zero-count behavior. |
| same | `BitSet::BitSet(BitSet&&)` | Transfers storage and clears source metadata. | None. | NONE-new | ENGINE | Prevent double-free. |
| same | `BitSet::operator=(const BitSet&)` | Copy-assigns through copy-then-move. | None. | NONE-new | ENGINE | Self-assignment and exception safety. |
| same | `BitSet::operator=(BitSet&&)` | Frees old storage, transfers source, and clears source. | None. | NONE-new | ENGINE | Prevent leaks/double-free. |
| same | `BitSet::contains` | Tests a bucket’s occupancy bit. | None. | NONE-new | ENGINE | Index arithmetic assumes valid capacity. |
| same | `BitSet::clear` | Zeroes all occupancy words. | None. | NONE-new | ENGINE | Does not alter word count. |
| same | `BitSet::set` | Sets or clears a bucket’s occupancy bit. | None. | NONE-new | ENGINE | Bit numbering is LSB-first. |
| same | `BitSet::wordAt` | Returns a word with bounds assertion. | None. | NONE-new | ENGINE | Used by sparse rehash iteration. |
| same | `BitSet::numWords` | Returns allocated word count. | None. | NONE-new | ENGINE | Not the logical bucket capacity. |
| same | `DenseHashTable2::DenseHashTable2(size_t)` | Allocates item slots, initializes them, and computes Fibonacci hash shift. | None. | NONE-new | ENGINE | Bucket count must be zero or a power of two. |
| same | `DenseHashTable2::~DenseHashTable2` | Destroys initialized elements and storage. | None. | NONE-new | ENGINE | Calls `destroy` only when data is non-null. |
| same | `DenseHashTable2::DenseHashTable2(const DenseHashTable2&)` | Deep-copies items while tracking partially initialized capacity for exception cleanup. | None. | NONE-new | ENGINE | Partial-copy cleanup is subtle. |
| same | `DenseHashTable2::DenseHashTable2(DenseHashTable2&&)` | Transfers data, bitset, capacity, count, and hash shift. | None. | NONE-new | ENGINE | Resets source to empty defaults. |
| same | `DenseHashTable2::operator=(DenseHashTable2&&)` | Destroys current table then transfers source state. | None. | NONE-new | ENGINE | Hash/equality functors are not explicitly moved here. |
| same | `DenseHashTable2::operator=(const DenseHashTable2&)` | Copy-assigns through temporary copy and move. | None. | NONE-new | ENGINE | Depends on move-assignment correctness. |
| same | `DenseHashTable2::clear` | Either destroys large tables or resets slots/bitset in place; count becomes zero. | None. | NONE-new | ENGINE | Default destruction threshold is 32. |
| same | `DenseHashTable2::destroy` | Destroys all slots, releases storage, resets bitset/capacity/hash shift. | None. | NONE-new | ENGINE | Does not explicitly reset `count`; callers do or object is dying. |
| same | `DenseHashTable2::doHash` | Multiplies user hash by Fibonacci constant then right-shifts into bucket range. | None. | NONE-new | ENGINE | Exact unsigned 64-bit wrapping is required. |
| same | `DenseHashTable2::BucketResult` | Adds `{bucket, found}` lookup result struct. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashTable2::erase` | Finds key and invokes backward-shift deletion when present. | None. | NONE-new | ENGINE | Probe-chain preservation depends on `doErase`. |
| same | `DenseHashTable2::insert_unsafe` | Inserts into a resolved bucket, marks occupancy, sets key, and increments count. | None. | NONE-new | ENGINE | Caller must rehash first. |
| same | `DenseHashTable2::find` | Resolves key and returns item pointer or null. | None. | NONE-new | ENGINE | Empty table short-circuit avoids invalid modulo. |
| same | `DenseHashTable2::grow` | Doubles capacity, scans occupied bits, moves entries, and swaps storage. | None. | NONE-new | ENGINE | Moved-from slots remain allocated until old table destruction. |
| same | `DenseHashTable2::rehash_if_full` | Grows at 3/4 load only when key is not already present. | None. | NONE-new | ENGINE | Avoids growth on updates. |
| same | `DenseHashTable2::begin() const` | Finds first occupied bucket and returns const iterator. | None. | NONE-new | ENGINE | Empty table returns end. |
| same | `DenseHashTable2::end() const` | Returns const iterator at capacity. | None. | NONE-new | ENGINE | Capacity is the sentinel index. |
| same | `DenseHashTable2::begin()` | Mutable first-occupied iterator. | None. | NONE-new | ENGINE | Iterator invalidated by insertion/growth. |
| same | `DenseHashTable2::end()` | Mutable iterator at capacity. | None. | NONE-new | ENGINE | Capacity is the sentinel index. |
| same | `DenseHashTable2::size` | Returns live entry count. | None. | NONE-new | ENGINE | Count must remain synchronized with bitset. |
| same | `DenseHashTable2::const_iterator` | Adds forward iterator over occupied item slots plus standard iterator aliases. | None. | NONE-new | ENGINE | Stores table pointer and raw bucket index. |
| same | `const_iterator::const_iterator()` | Creates null/default iterator. | None. | NONE-new | ENGINE | Only safe for comparison/assignment until rebound. |
| same | `const_iterator::const_iterator(table,index)` | Creates iterator at explicit table/index. | None. | NONE-new | ENGINE | No index validation. |
| same | `const_iterator::operator*` | Returns const item reference. | None. | NONE-new | ENGINE | Caller must not dereference end. |
| same | `const_iterator::operator->` | Returns const item pointer. | None. | NONE-new | ENGINE | Caller must not dereference end. |
| same | `const_iterator::operator==` | Compares both table identity and index. | None. | NONE-new | ENGINE | Iterators from different tables are unequal. |
| same | `const_iterator::operator!=` | Negates table/index equality. | None. | NONE-new | ENGINE | Mechanical. |
| same | `const_iterator::operator++()` | Advances to the next occupied bucket. | None. | NONE-new | ENGINE | Must stop exactly at capacity. |
| same | `const_iterator::operator++(int)` | Returns old iterator then advances. | None. | NONE-new | ENGINE | Mechanical postfix semantics. |
| same | `DenseHashTable2::iterator` | Adds mutable forward iterator, exposing `MutableItem` via reinterpret cast. | None. | NONE-new | ENGINE | Const-key map view relies on representation compatibility. |
| same | `iterator::iterator()` | Creates null/default mutable iterator. | None. | NONE-new | ENGINE | Same default-iterator caveat. |
| same | `iterator::iterator(table,index)` | Creates mutable iterator at explicit table/index. | None. | NONE-new | ENGINE | No index validation. |
| same | `iterator::operator*` | Reinterprets stored item as mutable-item reference. | None. | NONE-new | ENGINE | Aliasing/layout-sensitive for map entries. |
| same | `iterator::operator->` | Reinterprets stored item as mutable-item pointer. | None. | NONE-new | ENGINE | Aliasing/layout-sensitive. |
| same | `iterator::operator==` | Compares table identity and index. | None. | NONE-new | ENGINE | Mechanical. |
| same | `iterator::operator!=` | Negates table/index equality. | None. | NONE-new | ENGINE | Mechanical. |
| same | `iterator::operator++()` | Advances to the next occupied bucket. | None. | NONE-new | ENGINE | Must stop at capacity. |
| same | `iterator::operator++(int)` | Returns old iterator then advances. | None. | NONE-new | ENGINE | Mechanical postfix semantics. |
| same | `DenseHashTable2::getBucket` | Performs wrapped linear probing from Fibonacci-hash bucket until match or empty slot. | None. | NONE-new | ENGINE | Requires `count < capacity` to terminate. |
| same | `DenseHashTable2::doErase` | Implements Algorithm R backward-shift deletion to preserve probe reachability. | None. | NONE-new | ENGINE | Highest-risk hash-table invariant. |
| same | `detail::ItemInterfaceSet2` | Adds set-slot key/fill/destroy adapter. | None. | NONE-new | ENGINE | Placement construction/destruction must pair. |
| same | `ItemInterfaceSet2::getKey` | Returns item as key. | None. | NONE-new | ENGINE | Mechanical. |
| same | `ItemInterfaceSet2::setKey` | Assigns key into item slot. | None. | NONE-new | ENGINE | Slot is already constructed. |
| same | `ItemInterfaceSet2::fill` | Placement-default-constructs every key slot. | None. | NONE-new | ENGINE | Raw-storage initialization. |
| same | `ItemInterfaceSet2::destroy` | Explicitly destroys every key slot. | None. | NONE-new | ENGINE | Must cover full constructed capacity. |
| same | `detail::ItemInterfaceMap2` | Adds pair-slot key/fill/destroy adapter. | None. | NONE-new | ENGINE | Key/value subobjects are constructed separately. |
| same | `ItemInterfaceMap2::getKey` | Returns pair’s first element. | None. | NONE-new | ENGINE | Mechanical. |
| same | `ItemInterfaceMap2::setKey` | Assigns key into pair’s first element. | None. | NONE-new | ENGINE | Key is mutable in underlying storage. |
| same | `ItemInterfaceMap2::fill` | Placement-default-constructs key and value subobjects. | None. | NONE-new | ENGINE | Partial construction exceptions are delicate. |
| same | `ItemInterfaceMap2::destroy` | Explicitly destroys key and value subobjects. | None. | NONE-new | ENGINE | Destruction pairing/order must be preserved. |
| same | `DenseHashSet2` | Adds public set wrapper and iterator aliases around `DenseHashTable2`. | None. | NONE-new | ENGINE | No consumer in this rung. |
| same | `DenseHashSet2::DenseHashSet2` | Constructs implementation with optional bucket count. | None. | NONE-new | ENGINE | Bucket count inherits power-of-two requirement. |
| same | `DenseHashSet2::clear` | Clears implementation using default threshold. | None. | NONE-new | ENGINE | Mechanical wrapper. |
| same | `DenseHashSet2::insert` | Rehashes if needed then inserts/returns stored key. | None. | NONE-new | ENGINE | Returned reference invalidated by future growth. |
| same | `DenseHashSet2::find` | Returns stored key pointer or null. | None. | NONE-new | ENGINE | Pointer invalidated by insert/growth. |
| same | `DenseHashSet2::contains` | Tests whether implementation returns non-null. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashSet2::erase` | Delegates deletion. | None. | NONE-new | ENGINE | Inherits backward-shift risk. |
| same | `DenseHashSet2::size` | Returns live element count. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashSet2::empty` | Tests size equals zero. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashSet2::begin() const` | Delegates const begin iterator. | None. | NONE-new | ENGINE | Iterator invalidation applies. |
| same | `DenseHashSet2::end() const` | Delegates const end iterator. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashSet2::begin()` | Delegates mutable begin iterator. | None. | NONE-new | ENGINE | Allows mutation of set keys, matching C++ surface. |
| same | `DenseHashSet2::end()` | Delegates mutable end iterator. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashSet2::operator==` | Compares sizes then checks every key in the other set. | None. | NONE-new | ENGINE | Equality depends on hash/equality semantics. |
| same | `DenseHashSet2::operator!=` | Negates set equality. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashMap2` | Adds public map wrapper and iterator aliases around `DenseHashTable2`. | None. | NONE-new | ENGINE | No consumer in this rung. |
| same | `DenseHashMap2::DenseHashMap2` | Constructs implementation with optional bucket count. | None. | NONE-new | ENGINE | Inherits capacity requirement. |
| same | `DenseHashMap2::clear` | Clears with caller-selectable destruction threshold. | None. | NONE-new | ENGINE | Default threshold 32. |
| same | `DenseHashMap2::operator[]` | Rehashes/inserts key and returns mutable value reference. | None. | NONE-new | ENGINE | Any insertion can invalidate prior references. |
| same | `DenseHashMap2::find const` | Returns const value pointer for key or null. | None. | NONE-new | ENGINE | Pointer invalidated by insertion. |
| same | `DenseHashMap2::find` | Returns mutable value pointer using const-cast of stored pair. | None. | NONE-new | ENGINE | Representation/aliasing-sensitive. |
| same | `DenseHashMap2::contains` | Tests whether implementation finds key. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashMap2::erase` | Delegates deletion. | None. | NONE-new | ENGINE | Inherits probe-chain risk. |
| same | `DenseHashMap2::try_insert(const Value&)` | Inserts copied value only when key is fresh and returns `(reference,fresh)`. | None. | NONE-new | ENGINE | Reference can be invalidated by later insertion. |
| same | `DenseHashMap2::try_insert(Value&&)` | Move-inserts value only for a fresh key. | None. | NONE-new | ENGINE | Existing keys must not consume/move the argument. |
| same | `DenseHashMap2::size` | Returns live pair count. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashMap2::empty` | Tests size equals zero. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashMap2::begin() const` | Delegates const begin iterator. | None. | NONE-new | ENGINE | Iterator invalidation applies. |
| same | `DenseHashMap2::end() const` | Delegates const end iterator. | None. | NONE-new | ENGINE | Mechanical. |
| same | `DenseHashMap2::begin()` | Delegates mutable begin iterator. | None. | NONE-new | ENGINE | Mutable view preserves const key through `MutableItem`. |
| same | `DenseHashMap2::end()` | Delegates mutable end iterator. | None. | NONE-new | ENGINE | Mechanical. |
| `Common/include/Luau/HashUtil.h` H1-H2 | `DenseHashPointer::operator()` | Removes unnecessary `Common.h` include and replaces two shifted XORs with multiplicative/mix hashing for better arena-pointer scattering. | None; unconditional. | [dense_hash_pointer_operator_call.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/methods/dense_hash_pointer_operator_call.rs) | ENGINE | Exact wrapping/mixing affects hash distribution, not equality. |

### Compiler

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Compiler/src/Compiler.cpp` H1-H5 | `Compiler::compileFunction` | Computes cost once for feedback-enabled inlinable/no-upvalue functions, serializes it through `endFunction`, and reuses it for compiler inlining metadata. | Existing `LuauEmitCallFeedback=false`: serialized cost remains zero; old behavior otherwise. | [compiler_compile_function.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_function.rs) | ENGINE | A genuine computed cost of zero triggers recomputation for compiler metadata. |
| `Compiler/src/Types.cpp` H1 | `LuauCompileTypeAliases` | Removes the FFlag definition; its former ON behavior becomes unconditional. | Removed flag previously defaulted OFF; 0.729 executes former ON path. | [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs) | ENGINE | Remove registration/setter as well as branch reads. |
| `Compiler/src/Types.cpp` H2-H7 | `getType` | Removes deprecated one-level-resolution parameter; recursively resolves aliases with `seenAliases` cycle detection unconditionally. | Former `LuauCompileTypeAliases` ON path graduated. | [get_type.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/functions/get_type.rs) | ENGINE | Recursive aliases must fall back to `LBC_TYPE_ANY`. |
| `Compiler/src/Types.cpp` H8 | `getFunctionType` | Updates argument-type conversion to the new `getType` signature. | None after graduation. | [get_function_type.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/functions/get_function_type.rs) | ENGINE | Signature-only propagation with changed alias depth. |
| `Compiler/src/Types.cpp` H9 | `TypeMapVisitor::recordResolvedType(AstExpr*,…)` | Removes deprecated resolve-aliases argument when deriving expression bytecode type. | None after graduation. | [type_map_visitor_record_resolved_type_types.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/methods/type_map_visitor_record_resolved_type_types.rs) | ENGINE | Expression type metadata now gets deep alias resolution. |
| `Compiler/src/Types.cpp` H10 | `TypeMapVisitor::recordResolvedType(AstLocal*,…)` | Removes deprecated resolve-aliases argument when deriving local bytecode type. | None after graduation. | [type_map_visitor_record_resolved_type_types_alt_b.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/methods/type_map_visitor_record_resolved_type_types_alt_b.rs) | ENGINE | Local type metadata now gets deep alias resolution. |

### JIT Inliner — out of scope

The entire C++ `Inliner` module was introduced in official 0.727 and is absent from the 0.724 Rust translation.

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Inliner/src/JitInliner.cpp` H1 | `LuauJitInlineThreshold` | Adds baseline JIT inline-cost threshold, default 25. | FInt default 25. | NONE-new | OUT-OF-SCOPE | JIT-only. |
| same | `LuauJitInlineThresholdMaxBoost` | Adds maximum constant-argument profitability boost, default 300%. | FInt default 300. | NONE-new | OUT-OF-SCOPE | JIT-only. |
| same | `LuauJitInlineSmallFunSize` | Adds bytecode-size cutoff below which cost rejection is skipped, default 128. | FInt default 128. | NONE-new | OUT-OF-SCOPE | JIT-only. |
| same | `LuauJitInlineTooLongFunSize` | Replaces fixed maximum-length constant with configurable default `0xFFFF`. | FInt default 65535. | NONE-new | OUT-OF-SCOPE | JIT-only. |
| `Inliner/src/JitInliner.cpp` H2 | `JitInliner::createInlinedProto` | Copies caller proto cost into the synthesized inlined proto. | None. | NONE-untranslated | OUT-OF-SCOPE | Depends on 0.727 JIT/optimized-proto structures. |
| `Inliner/src/JitInliner.cpp` H3 | `kMaxFunctionBytecodeSize` | Removes fixed `constexpr 0xFFFF`; callers use `LuauJitInlineTooLongFunSize`. | Replaced by FInt default 65535. | NONE-untranslated | OUT-OF-SCOPE | JIT-only. |
| `Inliner/src/JitInliner.cpp` H3 | `JitInliner::computeCost` | Decodes packed cost model and applies up to seven constant-argument discounts; saturated base cost is not discounted. | None. | NONE-new | OUT-OF-SCOPE | Packed bit layout must match compiler `modelCost`. |
| `Inliner/src/JitInliner.cpp` H3 | `JitInliner::isConstOp` | Recognizes LOADB/LOADNIL/LOADN/LOADK/LOADKX and follows MOVE chains. | None. | NONE-new | OUT-OF-SCOPE | Recursive MOVE cycles would recurse indefinitely, though valid graph should prevent them. |
| `Inliner/src/JitInliner.cpp` H4-H6 | `JitInliner::onInlineFunction` | Uses configurable size bounds and cost/constant-argument profitability to reject expensive targets before building target graph. | Four new FInts at defaults 25/300/128/65535. | NONE-untranslated | OUT-OF-SCOPE | Depends on 0.727 graph/JIT inliner implementation. |
| `Inliner/src/JitInliner.cpp` H7 | `JitInliner::disable` (format-only context) | Adds final newline after the namespace close; no code change. | None. | NONE-untranslated | OUT-OF-SCOPE | Formatting-only hunk. |
| `VM/src/lfunc.cpp` H1 | `LuauInlineHitsThreshold` | Raises call-target hit threshold from 3 to 32 before requesting JIT inlining. | FInt default changes 3 → 32; 0.729 default is 32. | [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs) | OUT-OF-SCOPE | VM declaration, but its only effect is JIT-inliner scheduling. |

### VM and embedder API

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `VM/include/lua.h` H1; `VM/src/lapi.cpp` H1 | `lua_getuserdataname` | New API returns userdata tag metatable `__type` string, or `"userdata"` when absent/non-string. | None; unconditional API. | NONE-new | RT-API | Returned pointer is borrowed/interned; tag range assertion must match C API. |
| `VM/include/lualib.h` H1; `VM/src/laux.cpp` H1 | `luaL_checkudatatagged` | New auxiliary API returns userdata pointer for an exact tag or raises a type error using `lua_getuserdataname`. | None; unconditional API. | NONE-new | RT-API | `luaur-rt` currently wraps neither this nor the related tagged check surface. |
| `VM/src/ldo.cpp` H1 | `LuauResumeRestoreCcalls` | Removes the flag definition; former ON restoration semantics become unconditional. | Removed flag previously defaulted OFF; 0.729 executes former ON path. | [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs) | ENGINE | Remove flag registration/setter after both consumers are ported. |
| `VM/src/ldo.cpp` H2 | `resume_handle` | Deletes former flag-OFF fallback that reset `nCcalls` to `baseCcalls`. | Former `LuauResumeRestoreCcalls` ON behavior unconditional. | [resume_handle.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/resume_handle.rs) | ENGINE | High-risk coroutine/error-reentry call-depth invariant. |
| `VM/src/ldo.cpp` H3-H4 | `resume_finish` | Always restores `nCcalls/baseCcalls` from `oldnCcalls`, then exits with `nCcalls=oldnCcalls-1`. | Former flag-ON path unconditional. | [resume_finish.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/resume_finish.rs) | ENGINE | Must port atomically with `resume_handle`. |
| `VM/src/lobject.h` H1 | `Proto` | Adds `uint64_t cost` after optimized/deoptimized proto links. | None; unconditional struct layout. | [proto.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/records/proto.rs) | ENGINE | ABI/layout change; Rust baseline also lacks the prerequisite 0.727 optimized/deoptimized fields. |
| `VM/src/lfunc.cpp` H2 | `luaF_newproto` | Initializes new proto cost to zero. | None. | [lua_f_newproto.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/lua_f_newproto.rs) | ENGINE | Must follow the complete `Proto` layout update. |
| `VM/src/lgc.cpp` H1 | `markudatadirectfields` | New helper marks every non-null direct-field dispatch table. | Asserts `LuauDirectFieldGet=true`; default OFF means no call. | NONE-new | ENGINE | Centralizes GC liveness for dispatch tables. |
| `VM/src/lgc.cpp` H2 | `markroot` | Replaces inline direct-field marking loop with the new helper. | `LuauDirectFieldGet=false`: skipped by default. | [markroot.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/markroot.rs) | ENGINE | Behavior-equivalent extraction on the initial root pass. |
| `VM/src/lgc.cpp` H3 | `atomic` | Marks direct-field dispatch tables again during atomic GC before propagation. | `LuauDirectFieldGet=false`: new marking skipped by default. | [atomic.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/atomic.rs) | ENGINE | Critical ON-path liveness fix for tables changed after initial root marking. |
| `VM/src/lvmexecute.cpp` H1 | `LuauDirectFieldGet` flag version | Raises flag metadata version 2 → 3; boolean default and interpreter guard are unchanged. | Flag remains default `false`; release-default executes OFF direct-field path. | [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs); [luau_flagversion.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/macros/luau_flagversion.rs) | ENGINE | Rust has the mechanism but no current stamp invocation; its macro notes version reads are not yet used. |
| `VM/src/lvmload.cpp` H2-H4 | `loadsafe` | For v12 reads each proto byte length, loads cost for inlinable protos, then advances to `protoStartOffset+protoSize` to skip unknown trailing fields; removes v11 feedback-flag assertion. | Version checks are unconditional; declared `LuauCostModel` is not consulted here. | [loadsafe.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/loadsafe.rs) | ENGINE | Bounds/overflow validation of the size-based skip is security-sensitive. |

## FFlag/FInt inventory

`LUAU_FASTFLAGVARIABLE` initializes booleans to `false`; `LUAU_FASTINTVARIABLE` uses the stated integer. No DFFlag or DFInt was added, removed, or changed.

| flag | rung change | gated behavior | release-default executed path |
|---|---|---|---|
| `LuauTrackPrefixLocal` | Added, default false | Records the `AstLocal` bound to a qualified type prefix. | **OFF:** `prefixLocal` stays null. |
| `LuauNoDuplicateBinaryPrefix` | Added, default false | Explicitly rejects a remaining `0b`/`0B` prefix in binary numeric parsing. | **OFF:** no explicit pre-`strtoull` rejection. |
| `LuauBytecodeCostModel` | Added, default false | Selects v12; prefixes proto byte sizes and serializes inlinable cost metadata. | **OFF:** compiler emits the pre-v12 layout/version selected by existing flags. |
| `LuauCostModel` | Added, default false | Makes `BytecodeGraph::fromFunctionBytecode` consume inlinable cost metadata. | **OFF:** graph parser does not consume the cost. VM `loadsafe` nevertheless parses v12 based on version. |
| `LuauCompileTypeAliases` | Removed; old default false | Previously selected recursive alias resolution with cycle detection. | No flag remains: former **ON** behavior is unconditional. |
| `LuauResumeRestoreCcalls` | Removed; old default false | Previously selected restoration from `oldnCcalls` during coroutine resume completion/error handling. | No flag remains: former **ON** behavior is unconditional. |
| `LuauJitInlineThreshold` | Added FInt, default 25 | Baseline accepted inlined cost. | Uses **25**. |
| `LuauJitInlineThresholdMaxBoost` | Added FInt, default 300 | Caps constant-argument profitability boost. | Uses **300%**. |
| `LuauJitInlineSmallFunSize` | Added FInt, default 128 | Skips cost rejection for small target protos. | Uses **128 bytecode instructions/units as tested by `sizecode`**. |
| `LuauJitInlineTooLongFunSize` | Added FInt, default `0xFFFF` | Rejects caller or target functions exceeding the configurable bytecode length. | Uses **65535**. |
| `LuauInlineHitsThreshold` | Default changed 3 → 32 | Number of call-target hits before requesting JIT inlining. | Uses **32**. |
| `LuauDirectFieldGet` | Version stamp changed 2 → 3; boolean default unchanged | Version 3 accompanies atomic-GC remarking of direct-field dispatch tables. | **OFF:** direct-field lookup/marking paths remain skipped. |

Existing flags newly declared or newly used, but not themselves added/removed/flipped:

- `LuauCallFeedback` remains default false. The new BytecodeGraph hunk consumes feedback descriptions only when ON.
- `LuauEmitCallFeedback` remains default false. `Compiler::compileFunction` computes the serialized cost only when it is ON and the function is inlinable with no upvalues.
- `LuauDirectFieldGet` is a version-metadata change, not a boolean flip.

## Completeness accounting

| file | hunks | attribution |
|---|---:|---|
| `Ast/include/Luau/Ast.h` | 2 | `AstTypeReference` constructor and struct |
| `Ast/src/Ast.cpp` | 2 | `AstTypeReference` constructor |
| `Ast/src/Parser.cpp` | 6 | two new flags; `parseSimpleType`; `parseInteger`; `parseInteger64` |
| `Bytecode/include/Luau/BytecodeBuilder.h` | 2 | `endFunction`; `writeFunction` |
| `Bytecode/include/Luau/Sccp.h` | 1 | all listed SCCP interface/lattice/state symbols |
| `Bytecode/src/BytecodeBuilder.cpp` | 8 | cost flag; `endFunction`; `finalize`; `writeFunction`; `getVersion` |
| `Bytecode/src/BytecodeGraph.cpp` | 2 | flag declarations; `fromFunctionBytecode` |
| `Bytecode/src/Sccp.cpp` | 1 | all listed SCCP helpers and `BcVmConstImpl` methods |
| `Common/include/Luau/Bytecode.h` | 2 | v12 documentation and `LBC_VERSION_MAX` |
| `Common/include/Luau/DenseHash2.h` | 1 | all listed `DenseHash2` symbols |
| `Common/include/Luau/HashUtil.h` | 2 | header self-containment and `DenseHashPointer::operator()` |
| `Compiler/src/Compiler.cpp` | 5 | `Compiler::compileFunction` |
| `Compiler/src/Types.cpp` | 10 | flag graduation; `getType`; `getFunctionType`; both `recordResolvedType` overloads |
| `Inliner/src/JitInliner.cpp` | 7 | four FInts; proto cost copy; removed constant; two helpers; `onInlineFunction`; EOF newline |
| `VM/include/lua.h` | 1 | `lua_getuserdataname` declaration |
| `VM/include/lualib.h` | 1 | `luaL_checkudatatagged` declaration |
| `VM/src/lapi.cpp` | 1 | `lua_getuserdataname` definition |
| `VM/src/laux.cpp` | 1 | `luaL_checkudatatagged` definition |
| `VM/src/ldo.cpp` | 4 | resume flag removal; `resume_handle`; `resume_finish` |
| `VM/src/lfunc.cpp` | 2 | inline-hit FInt; `luaF_newproto` |
| `VM/src/lgc.cpp` | 3 | `markudatadirectfields`; `markroot`; `atomic` |
| `VM/src/lobject.h` | 1 | `Proto` |
| `VM/src/lvmexecute.cpp` | 1 | `LuauDirectFieldGet` version |
| `VM/src/lvmload.cpp` | 4 | `LuauCostModel` definition; `loadsafe` |
| **Total** | **70** | **70 attributed** |

- Hunks: **70 total / 70 attributed / 0 unresolved**
- Rows by class: **ENGINE 185 / RT-API 2 / OUT-OF-SCOPE 11**
- Total ledger rows: **198**
- UNRESOLVED: **none**

## Dependency notes

1. The JIT Inliner was introduced in official **0.727** (`f1f121dc`). Therefore the 0.729 changes to `createInlinedProto`, `onInlineFunction`, and the removed `kMaxFunctionBytecodeSize` require the 0.727 Inliner/optimized-proto rung first. They are `NONE-untranslated` against the 0.724 Rust baseline.

2. `Proto::cost` is inserted after `Proto::{optimized,deoptimized}`. Those fields also arrived with the 0.727 JIT Inliner and are absent from the current Rust `Proto`. The write lane must first land the earlier-rung layout and corresponding `luaF_newproto` initialization; adding only `cost` at the current Rust tail would produce the wrong structure-preserving order.

3. Bytecode v12 assumes the already-existing v11 feedback surface: `LPF_INLINABLE`, `LFT_CALLTARGET`, `feedbackvecsize`, `LuauEmitCallFeedback`/`LuauCallFeedback`, and varint64 readers. These were present at the official 0.724 baseline, so they are prerequisites but not missing-rung dependencies.

4. SCCP depends on existing BytecodeGraph entities (`BcOp`, `BcImm`, `BcFunction`, `BcVmConst`, `BcOpHash`, validation utilities, and `VecDeque`). Those exist at the 0.724 baseline; no intervening rung is required.

5. The direct-field GC hunk assumes the existing `global_State::udatadirectfields`, `UTAG_INTERNAL_LIMIT`, and `LuauDirectFieldGet` machinery. Those also predate this rung; the only 0.729 delta is helper extraction, atomic remarking, and the flag-version increment.