# Job 4: rung inventory — official 0.727 -> 0.728

Diff range: `f1f121dc..ddcea05e` in /Users/levi/dev/oss/luigi-rosso-luau, scoped to:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff f1f121dc..ddcea05e -- VM Compiler Ast Common Config Require Bytecode Inliner`

Inventory every hunk of that diff per the required output format in the
context above. The Rust twin check is against the CURRENT vendored crates in
this repo (which sit at the 0.724 baseline — for rungs after the first, a
twin whose earlier-rung context has not landed yet is still the correct twin
path; note the dependency in the dependency-notes section instead).

