# Context: luaur fork delta inventory (read-only job)

Nuxie vendors an in-house fork of `luaur`, a pure-Rust, structure-preserving
translation of the Luau C/C++ engine. Fork record: `docs/luau-fork.md` in this
repo. The translation baseline corresponds to official Luau release 0.724
(commit `8f33df91` "Sync to upstream/release/724"). The goal of the overall
project is to faithfully port the C++ deltas up to the `rive_0_732` branch tip
`86eb0096` of `https://github.com/luigi-rosso/luau` (what the pinned rive C++
runtime actually embeds), one upstream release rung at a time.

Your job is INVENTORY ONLY — read-only. No edits.

## Repos on disk

- Luau C++ history (full clone, NO worktree checkout — use `git -C ... show
  <rev>:<path>` and `git -C ... diff` to read): `/Users/levi/dev/oss/luigi-rosso-luau`
- The Rust fork (this repo): vendored crates under `vendor/`:
  - `vendor/luaur-ast-0.1.8`      ↔ `Ast/`
  - `vendor/luaur-bytecode-0.1.8` ↔ bytecode definitions (`Common/include/Luau/Bytecode*.h` and related)
  - `vendor/luaur-common-0.1.8`   ↔ `Common/` and shared enums/utilities
  - `vendor/luaur-compiler-0.1.8` ↔ `Compiler/`
  - `vendor/luaur-vm-0.1.8`       ↔ `VM/`
  - `vendor/luaur-rt-0.1.8`       = the crate author's own embedder/runtime layer
    (NOT a direct translation; changes here are only needed when the engine API
    surface underneath it shifts)

## Translation conventions (verified)

- One Rust file per C function: `src/functions/<c_function_name_lowercase>.rs`
  (e.g. `lua_pushcclosurek.rs`, `luau_execute.rs`).
- The `lvmexecute.cpp` interpreter switch is split per opcode case:
  `src/functions/vm_case_lvmexecute_alt_*.rs`.
- C structs → `src/records/<snake_case>.rs` (e.g. `call_info.rs`,
  `global_state.rs`); C enums → `src/enums/`; macros → `src/macros/`;
  member functions → `src/methods/`.
- The port is structure-preserving: a faithful delta port edits the Rust twin
  of each changed C symbol, mirroring the C hunk. Never re-architect.

## Required output (write NOTHING to disk; print as your final message)

A markdown ledger:

1. Header: the diff range, total hunk count, and the exact git command you used.
2. One table row per changed C symbol (function/struct/enum/macro/constant):
   `| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |`
   - class ∈ ENGINE (VM/Compiler/Ast/Bytecode/Common behavior the runtime can
     exercise), RT-API (changes the embedder-facing API that luaur-rt wraps),
     OUT-OF-SCOPE (Analysis/type-checker-only, CodeGen/JIT-only, CLI-only,
     tests, docs, build files).
   - Verify every claimed Rust twin path actually exists (ls/grep). If a
     symbol is new in this rung, say NONE-new. If it existed at the base but
     luaur never translated it, say NONE-untranslated.
3. FFlag section: every FFlag/DFFlag/DFInt added, removed, or flipped in this
   rung, and what behavior each gates. Luau ships changes dark behind flags —
   note for each whether the C code's flag-ON or flag-OFF path is the one a
   release build with default flag values executes.
4. Completeness accounting: every hunk in the diff must be attributed to some
   row (or listed under an explicit UNRESOLVED section — never silently skip).
   End with: hunks total / attributed / unresolved, and rows per class.
5. Dependency notes: symbols in this rung that depend on another rung's
   changes landing first (e.g. an enum value added in an earlier rung).

Be exhaustive and mechanical. This inventory is the binding work-list for a
write lane; a missed hunk becomes a silent behavior divergence.
