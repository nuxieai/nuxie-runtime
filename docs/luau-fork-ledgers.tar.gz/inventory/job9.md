# Rung inventory: official 0.732 → `rive_0_732`

- Diff range: `decb2d0526797a175d7c5ba8d4d78858ced98553..86eb00965bebd6d31f3c97c86e1a94918172ec5a`
- Total hunks: **29** using Git’s default three context lines.
- Exact command:

```sh
git -C /Users/levi/dev/oss/luigi-rosso-luau diff decb2d05..origin/rive_0_732 -- VM Compiler Ast Common Config Require Bytecode Inliner
```

## Symbol ledger

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Ast/include/Luau/ParseResult.h` | R01 — `ParseResult` | Adds `std::vector<Lexeme> lexemes` to the successful parse result. | None; unconditional. | `vendor/luaur-ast-0.1.8/src/records/parse_result.rs` | ENGINE | `Lexeme` retains source-oriented data; preserve ownership/lifetime semantics and default/fatal-result construction. |
| `Ast/include/Luau/Parser.h` | R02 — `Parser::lexemes` | Adds parser-owned accumulation storage for captured lexemes. | None; unconditional. | **NONE-new** — host record is `vendor/luaur-ast-0.1.8/src/records/parser.rs` | ENGINE | Every parser constructor must initialize the new vector. This is independent of `ParseOptions::captureComments`. |
| `Ast/src/Parser.cpp` | R03 — `Parser::parse` | Moves `p.lexemes` into `ParseResult` on success. The fatal-error aggregate keeps the new field default-empty. | None; unconditional. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse.rs` | ENGINE | Rust struct literals must be updated on both success and caught-error paths or compilation/semantic parity will break. |
| `Ast/src/Parser.cpp` | R04 — `Parser::nextLexeme` | Appends `lexer.current()` after the first advance and after each advance through comments. Captures comments/broken comments and the following non-comment token. | None; unconditional. | `vendor/luaur-ast-0.1.8/src/methods/parser_next_lexeme.rs` | ENGINE | Two separate hunks implement the capture points. Do not gate these pushes on `captureComments`; memory use now scales with token count. |
| `Common/include/Luau/Bytecode.h` | R05 — `LBC_VERSION_TARGET` | Lowers the compiler target byte from official 0.732’s **9** to **7** while leaving supported maximum **13**. | No direct guard. Compatibility explicitly assumes `FFlag::LuauIntegerType2` is **OFF**, its release default. | `vendor/luaur-common-0.1.8/src/enums/luau_bytecode_tag.rs` | ENGINE | Wire-format compatibility critical. Rust currently says target 6/max 11; earlier official rungs must establish v7 support and later max-version changes before applying the fork override. |
| `Common/include/Luau/Bytecode.h`<br>`Compiler/src/Builtins.cpp` | R06 — `LuauBuiltinFunction::{LBF_RIVE_*}` and layout invariants | Adds `LBF_RIVE_FROUND=243`, reserves 244, and assigns Vector fast functions to 245–255. Adds assertions that the block ends at 255 and does not overlap upstream IDs. | None; unconditional in every build of this fork. | **NONE-new** — add to existing `vendor/luaur-common-0.1.8/src/enums/luau_builtin_function.rs` | ENGINE | Exact numeric ABI is binding: bytecode contains these IDs. Preserve the gap at 244 and all explicit/implicit discriminants. |
| `Compiler/src/Builtins.cpp` | R07 — `getBuiltinFunctionId` | Recognizes `math.fround`; maps `Vector.xy`, `origin`, `dot`, `lerp`, `distance`, `distanceSquared`, `length`, `lengthSquared`, `normalized`, `cross`, `scaleAndAdd`, and `scaleAndSub`. | None; unconditional. | `vendor/luaur-compiler-0.1.8/src/functions/get_builtin_function_id.rs` | ENGINE | Exact case-sensitive names matter. `Vector.xy` deliberately maps to existing `LBF_VECTOR`, not a Rive ID. |
| `Compiler/src/Builtins.cpp` | R08 — `getBuiltinInfo` | Supplies argument/result counts for every Rive builtin and marks each `Flag_NoneSafe`. | None; unconditional. | `vendor/luaur-compiler-0.1.8/src/functions/get_builtin_info.rs` | ENGINE | Wrong arity or safety flags change fastcall generation and fallback behavior. `origin` is 0→1; scale/lerp operations are 3→1. |
| `Compiler/src/Types.cpp` | R09 — `TypeMapVisitor::visit(AstExprCall*)` | Records numeric results for fround/distance/length/dot/magnitude/cross and vector results for origin/normalize/lerp/scale-add/sub. | None; unconditional. | `vendor/luaur-compiler-0.1.8/src/methods/type_map_visitor_visit_types_alt_u.rs` | ENGINE | Compiler type metadata must match runtime results; `Vector.cross` here is scalar 2D perp-dot. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | R10 — `lua_pushvector2` | Adds public API `lua_pushvector2(L, float x, float y)`. It writes only `v[0]`, `v[1]`, and the vector tag, then increments the stack. | None; unconditional. | **NONE-new** — no `luaur-vm` or `luaur-rt` wrapper exists | RT-API | High risk: C leaves `z` untouched, performs no `ensure_stack`, and Rive calls it extensively. Three-component fast functions subsequently read `z`, so stale-slot behavior must be explicitly preserved or adjudicated by parity tests. |
| `VM/src/laux.cpp` | R11 — `luaL_where` | Rive path uses `ar.source`, retries debug lookup at level 0 if the requested level lacks a positive line, and falls back to `":: "`. | `#ifdef RIVE_LUAU`; pinned runtime defines it, so release executes the **ON** path. | `vendor/luaur-vm-0.1.8/src/functions/lua_l_where.rs` | ENGINE | Error strings are observable. Rust currently uses shortened chunk IDs, no level-0 retry, and an empty fallback. |
| `VM/src/lbaselib.cpp` | R12 — `writestring` | Places the stdout helper inside `#ifndef RIVE_LUAU`. | `RIVE_LUAU` **ON** in pinned runtime, so this symbol is not compiled. | `vendor/luaur-vm-0.1.8/src/functions/writestring.rs` | ENGINE | Rust currently compiles it. Remove/disable it consistently with `luaB_print`; avoid leaving dead imports. |
| `VM/src/lbaselib.cpp` | R13 — `luaB_print` | Places the base-library `print` implementation inside the same non-Rive compile guard. | `RIVE_LUAU` **ON**, so the function is absent. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_print.rs` | ENGINE | Rive intentionally exposes no global `print`; retaining it is an observable capability difference. |
| `VM/src/lbaselib.cpp` | R14 — `luaB_newproxy` | Compiles `newproxy` only for non-Rive builds. | `RIVE_LUAU` **ON**, so the function is absent. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_newproxy.rs` | ENGINE | Affects available globals and userdata/proxy creation behavior. |
| `VM/src/lbaselib.cpp` | R15 — `base_funcs` | Omits `"newproxy"` and `"print"` registrations from the Rive base-library table. | `RIVE_LUAU` **ON**, so both entries are omitted. | `vendor/luaur-vm-0.1.8/src/functions/luaopen_base.rs` | ENGINE | Rust currently registers both. Array sizing and terminator placement must be adjusted with the entries. |
| `VM/src/lbuiltins.cpp` | R16 — `luauF_fround` | Adds fastcall narrowing number→`float`→`double`; returns fallback `-1` for bad arity/type/results. Kept outside `LUAU_FASTMATH`. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/luau_f_fround.rs` | ENGINE | Preserve the exact f32 round-trip and prevent optimization from eliding the narrowing. |
| `VM/src/lbuiltins.cpp` | R17 — `luauF_vectordistance` | Computes `sqrt(dx²+dy²+dz²)` for two vectors. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/luau_f_vectordistance.rs` | ENGINE | Final `5a6e21b4` behavior is three-component, not the earlier Rive 2D implementation. |
| `VM/src/lbuiltins.cpp` | R18 — `luauF_vectordistancesquared` | Computes `dx²+dy²+dz²` without a square root. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/luau_f_vectordistancesquared.rs` | ENGINE | Must read all three components; interacts dangerously with `lua_pushvector2`’s untouched `z`. |
| `VM/src/lbuiltins.cpp` | R19 — `luauF_vectororigin` | Produces vector `(0,0,0)` when at most one result is requested. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/luau_f_vectororigin.rs` | ENGINE | Takes zero arguments but does not explicitly reject extra parameters; mirror the C predicate. |
| `VM/src/lbuiltins.cpp` | R20 — `luauF_vectorlengthsquared` | Computes `x²+y²+z²` for one vector. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/luau_f_vectorlengthsquared.rs` | ENGINE | Three-component behavior is required. |
| `VM/src/lbuiltins.cpp` | R21 — `luauF_rivevectornormalize` | Normalizes all three components. Zero-length vectors remain zero by using inverse length 1. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/luau_f_rivevectornormalize.rs` | ENGINE | Do not substitute upstream `luauF_vectornormalize`; upstream divides by zero for a zero vector. |
| `VM/src/lbuiltins.cpp` | R22 — `luauF_vector2cross` | Returns scalar `ax*by - ay*bx`; intentionally ignores `z`. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/luau_f_vector2cross.rs` | ENGINE | Despite the three-component migration, this remains a 2D perp-dot returning a number, not a 3D vector cross product. |
| `VM/src/lbuiltins.cpp` | R23 — `luauF_vectorscaleandadd` | Returns `a + b*s` for x/y/z. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/luau_f_vectorscaleandadd.rs` | ENGINE | Preserve operation order per component; floating-point contraction can alter results. |
| `VM/src/lbuiltins.cpp` | R24 — `luauF_vectorscaleandsub` | Returns `a - b*s` for x/y/z. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/luau_f_vectorscaleandsub.rs` | ENGINE | Same ordering/contraction concern as scale-and-add. |
| `VM/src/lbuiltins.cpp` | R25 — `luauF_table` | Replaces the old 64-entry missing tail with padding through 242, fround at 243, missing at 244, and the 11 Vector entries at 245–255. Adds a 256-entry assertion. | None; unconditional. | `vendor/luaur-vm-0.1.8/src/macros/luau_f_table.rs` | ENGINE | Critical ABI table. Current Rust table is a 256-slot all-missing fallback; IDs and reused upstream functions (`vectordot`, `vectormagnitude`, `vectorlerp`) must be wired exactly. |
| `VM/src/ldebug.cpp` | R26 — `pusherror` | Final Rive tip uses the full raw source string for Lua frames and formats non-Lua errors as `":: message"`. | `RIVE_LUAU` **ON** in pinned runtime. | `vendor/luaur-vm-0.1.8/src/functions/pusherror.rs` | ENGINE | The intermediate `8ebb53b8` “message only” implementation was superseded by `318d4752`; port the final tip, not the commit title. |
| `VM/src/lmathlib.cpp` | R27 — `math_fround` | Adds ordinary-library fallback performing number→`float`→`double`. | None; unconditional. | **NONE-new** — expected `vendor/luaur-vm-0.1.8/src/functions/math_fround.rs` | ENGINE | Must agree bit-for-bit with the native fast function for valid numeric input. |
| `VM/src/lmathlib.cpp` | R28 — `mathlib` | Registers `"fround"` immediately after `"frexp"`. | None; unconditional. | `vendor/luaur-vm-0.1.8/src/functions/luaopen_math.rs` | ENGINE | Required so invalid/unoptimized fastcalls have a callable fallback. Update table size and imports. |
| `VM/src/lstate.cpp` | R29 — `lua_newstate` comment | Adds only a four-line explanation that `udatadirectfields` is initialized unconditionally to survive an OFF→ON flag flip. No executable endpoint delta. | Loop is unconditional. Referenced `FFlag::LuauDirectFieldGet` defaults **OFF**, but does not guard this hunk. | `vendor/luaur-vm-0.1.8/src/functions/lua_newstate.rs` | OUT-OF-SCOPE | Current Rust still has the obsolete conditional loop. Removing that guard belongs to official 0.724→0.725; this rung contributes only documentation. |

## FFlags and compile-time guards

No `FFlag`, `DFFlag`, or `DFInt` declaration is added, removed, or default-flipped by the scoped endpoint diff.

| flag/guard | status and release default | gated behavior |
|---|---|---|
| `FFlag::LuauIntegerType2` | Unchanged; created by `LUAU_FASTFLAGVARIABLE`, therefore default **OFF**. | The `LBC_VERSION_TARGET=7` compatibility comment assumes the OFF path, so integer constants requiring newer serialization are not emitted. The target hunk itself is unconditional. |
| `FFlag::LuauDirectFieldGet` | Unchanged; default **OFF**. | Other VM code gates direct userdata fields and GC marking. `lua_newstate` initialization is deliberately unconditional so a later OFF→ON mutation cannot expose garbage pointers. |
| `RIVE_LUAU` | Not an FFlag and not defined inside this Luau diff. The pinned Rive runtime’s `scripting/premake5.lua` defines it for both `luau_vm` and conditional `luau_compiler`, so its effective release state is **ON**. | Removes `print`/`newproxy`; selects Rive `luaL_where`; selects full-source/`":: "` `pusherror` formatting. |

All new Rive bytecode IDs, compiler recognition, fast functions, fround fallback, and `lua_pushvector2` are **not** protected by `RIVE_LUAU` or an FFlag; they affect every build of this fork.

## Fork-only `Bytecode/` and `Inliner/`

Both directory trees are byte-identical between the two endpoints:

- `Bytecode/`: tree `1003fb39f530ac917ba885e8aff06b27fb3b6518`, 11 files.
- `Inliner/`: tree `b2c0ecfc921112569df96edd0cb3ea052d137f49`, 7 files.
- `git diff --quiet decb2d05..origin/rive_0_732 -- Bytecode Inliner` returned 0.

### `Bytecode/` — 11 files

- `include/Luau/BytecodeBuilder.h`
- `include/Luau/BytecodeCallInliner.h`
- `include/Luau/BytecodeGraph.h`
- `include/Luau/BytecodeOps.h`
- `include/Luau/BytecodeValidation.h`
- `include/Luau/Sccp.h`
- `src/BytecodeBuilder.cpp`
- `src/BytecodeGraph.cpp`
- `src/BytecodeGraphParser.h`
- `src/BytecodeGraphSerializer.h`
- `src/Sccp.cpp`

The standalone Luau `CMakeLists.txt` creates `Luau.Bytecode`, and `Sources.cmake` assigns all 11 files to it. The pinned Rive build does not use that CMake target directly: at runtime commit `395defdb`, `scripting/premake5.lua` globs `Bytecode/src/**.cpp` into `luau_compiler` only when Rive tools/docs enable that otherwise-`None` target. It is therefore **ENGINE when the pinned compiler/tool target is enabled**, but not part of the always-built `luau_vm`. There are zero Job 9 hunks to port here.

### `Inliner/` — 7 files

- `include/Luau/JitInliner.h`
- `include/luajitinliner.h`
- `src/JitInliner.cpp`
- `src/RuntimeBytecodeBuilder.h`
- `src/TValueVmConstImpl.cpp`
- `src/TValueVmConstImpl.h`
- `src/luajitinliner.cpp`

Standalone Luau CMake creates `Luau.Inliner`, and `Sources.cmake` assigns all seven files. The pinned Rive premake build never globs `Inliner/` and never links a corresponding target. It is therefore **OUT-OF-SCOPE** for the pinned runtime, as well as having zero Job 9 hunks.

## Highlighted patches outside the command’s scope

These patches were checked but contribute no hunk to the required command:

- `e1c64312` changes only `Analysis/src/EmbeddedBuiltinDefinitions.cpp` for buffer extension declarations (`readf16`, `writef16`, `stridedcopy`, `convert`): **Analysis-only / OUT-OF-SCOPE**.
- `b19ba2a9` and `30e5e1a2` change only `Analysis/src/FileResolver.cpp` require-path/suggestion behavior: **Analysis-only / OUT-OF-SCOPE**.
- `c146794d` changes only `Analysis/src/BuiltinDefinitions.cpp` to avoid the builtin `require` declaration under Rive: **Analysis-only / OUT-OF-SCOPE**.
- The Analysis and CodeGen portions of `c57dea32` are likewise excluded; its scoped compiler/common/VM portions are represented by R06–R09, R16, R25, R27, and R28.

## Completeness accounting

| diff file | hunks | attribution |
|---|---:|---|
| `Ast/include/Luau/ParseResult.h` | 1 | R01 |
| `Ast/include/Luau/Parser.h` | 1 | R02 |
| `Ast/src/Parser.cpp` | 3 | R03; R04 ×2 |
| `Common/include/Luau/Bytecode.h` | 2 | R05; R06 |
| `Compiler/src/Builtins.cpp` | 4 | R07 ×2; R08; R06 layout assertions |
| `Compiler/src/Types.cpp` | 2 | R09 ×2 |
| `VM/include/lua.h` | 1 | R10 declaration |
| `VM/src/lapi.cpp` | 1 | R10 implementation |
| `VM/src/laux.cpp` | 2 | R11 ×2 |
| `VM/src/lbaselib.cpp` | 5 | R12; R13; R14 ×2; R15 |
| `VM/src/lbuiltins.cpp` | 3 | R16; R17–R24 jointly; R25 |
| `VM/src/ldebug.cpp` | 1 | R26 |
| `VM/src/lmathlib.cpp` | 2 | R27; R28 |
| `VM/src/lstate.cpp` | 1 | R29 |
| **Total** | **29** | **29 attributed** |

The single `lbuiltins.cpp` vector-function hunk jointly introduces the eight independently inventoried symbols R17–R24; it is counted once in the unique hunk total.

- Hunks total / attributed / unresolved: **29 / 29 / 0**
- Ledger rows per class: **ENGINE 27 / RT-API 1 / OUT-OF-SCOPE 1**
- **UNRESOLVED: none**

## Dependency notes

1. **R05 depends on official 0.726 bytecode work.** Official 0.726 changed `LBC_VERSION_TARGET` from 6 to 7 and made the v7 table-with-constants format the default. Official 0.730 later raised the target to 9; Job 9 deliberately restores 7. Do not apply the numeric override without the earlier v7 serializer/loader changes and later supported-version updates.

2. **R29 depends on official 0.725.** That rung removed the `if (FFlag::LuauDirectFieldGet)` guard around `udatadirectfields` initialization. Current Rust still has the conditional. Job 9’s C hunk is comment-only because official 0.732 already contains the fix.

3. **R06–R09, R16–R25, R27–R28 are an atomic builtin set.** The numeric enum, compiler recognition, arity metadata, inferred result type, VM table slots, native functions, and fallback registration must agree. Partial landing can emit bytecode IDs whose runtime slot is `luauF_missing` or whose fallback does not exist.

4. **R10 is coupled to the three-component change in R17–R24.** `lua_pushvector2` predates `5a6e21b4` and leaves `z` untouched, while distance, length, dot, magnitude, normalize, lerp, and scale operations consume `z`. This is same-rung coupling rather than an earlier official-rung dependency, but it is the highest-risk parity edge.

5. The reused upstream functions `luauF_vectordot`, `luauF_vectormagnitude`, and `luauF_vectorlerp`, plus all pre-Rive builtin IDs through `LBF_BUFFER_WRITEINTEGER`, already exist at the 0.724 Rust baseline. They do not require a later rung before the Rive block can be represented.