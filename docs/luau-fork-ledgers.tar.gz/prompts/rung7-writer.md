# Writer lane: luau-fork rung 7 (official 0.730 -> 0.731)

Production writer porting one upstream Luau release delta into Nuxie's
vendored luaur fork. Read `docs/luau-fork.md`, then
`.luau-fork-work/prompts/preamble.md`, then the binding ledger
`.luau-fork-work/inventory/job7.md` (258 hunks — largest rung; budget
accordingly and lean on the ledger's ordering). C-side diff:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff e8ae48c4..f8ca77ac -- VM Compiler Ast Common Config Require Bytecode Inliner`

Rungs 1-6 (0.725-0.730) are landed. Ledger dependency notes written against
the 0.724 baseline that are NOW SATISFIED: SCCP + DenseHash2 + evaluator
(rungs 5-6), bytecode tag ladder through v12, class/export foundation,
`lua_c_init` macro. Verify each dependent twin before porting; mismatches ->
blocked file. Rows depending on the untranslated runtime bytecode inliner
(`TValueVmConstImpl`, `onInlineFunction`) DEFER with the standing rationale.

## Protocol (identical to rungs 1-6)

1. STRUCTURE-PRESERVING; ROW-BY-ROW COMMITS with prefix
   `luau-fork rung7: <symbol> (<c-file>) [e8ae48c4..f8ca77ac]`; plain
   commits, no trailers. Focused gate: `cargo check -p nuxie --features
   scripting` + `cargo test -p nuxie-scripting --lib`; SCCP/bytecode groups
   also run `cargo test -p luaur-bytecode`.
2. FFLAG POLICY: new flags (`LuauCompileIifeInline`, `LuauBytecodeFold`,
   `LuauXpcallFixMessageYieldPath`, and all others marked Added) register +
   pin `.set(false)`; their OFF paths stay byte-identical to current
   behavior. Removed/hardwired rows (e.g. the require-alias null check
   becoming unconditional — in the untranslated Require subsystem, defer)
   follow upstream's kept side. Removed declarations (`luaC_initobj`)
   delete grep-complete.
3. Atomic ordering (the ledger's note 3 is BINDING — commit groups in this
   exact sequence):
   a. `LuauBytecodeTag` additions (`LBC_CONSTANT_VECTORD` appended AFTER
      `LBC_CONSTANT_CLASS_SHAPE` — verify tag numbering against
      `git show f8ca77ac:Common/include/Luau/Bytecode.h`) + compiler/
      bytecode constant representations.
   b. VM precision/type/TValue/GC representation for double vectors —
      mirror C's gating exactly (whatever compile-time/flag gate C uses,
      the Rust twin uses; the ungated representation must remain
      byte-identical to current behavior).
   c. Fixed allocator + `lvector` object (`luaVec_newvector` calls the
      `lua_c_init` macro twin).
   d. Loader/table/hash/arithmetic/library/interpreter caller updates.
   e. Public/RT wrappers (`lua_memorydump`, `lua_allocationrate` wrap the
      existing `luaC_dump`/`luaC_allocationrate` twins).
   f. Class-hoisting rows land together across parser, value tracking, and
      compiler (one group).
   g. Post-inline SCCP (`LuauBytecodeFold`, dark) and `BcFunction` rows on
      the landed SCCP base.
   h. Xpcall yield-path unit (`LuauXpcallFixMessageYieldPath`, dark): both
      paths preserved around the continuation call-depth restoration.
4. Deferred rows -> `.luau-fork-work/rung7-blocked.md`; verified no-ops ->
   `.luau-fork-work/rung7-noop.md`.
5. End: rung-level `NUXIE_PATCH.md` entries ("Ported official Luau 0.731
   delta (upstream e8ae48c4..f8ca77ac)"), committed as
   `luau-fork rung7: NUXIE_PATCH.md rung entries`; one full
   `cargo test -p nuxie --features scripting`; fix forward only your own
   rows. Final message: dispositions, commits, gates, surprises.

Do not touch: workspace `Cargo.toml`, `Cargo.lock`, `docs/`, `corpus.toml`,
crates outside `vendor/luaur-*`, `NUXIE_PROVENANCE.md`, or
`.luau-fork-work/` beyond the two report files.
