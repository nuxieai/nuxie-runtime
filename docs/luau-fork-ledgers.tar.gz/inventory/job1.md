# Luau rung inventory: 0.724 → 0.725

- **Diff range:** `8f33df91..91caa731`
- **Total hunks:** **125** using Git’s default three lines of context
- **Command:**

```sh
git -C /Users/levi/dev/oss/luigi-rosso-luau diff 8f33df91..91caa731 -- VM Compiler Ast Common Config Require Bytecode Inliner
```

No files were written. Hunk identifiers below are file-local. When one hunk changes multiple symbols, it appears in multiple rows but counts once in completeness accounting.

## Symbol ledger

### Ast

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Ast/include/Luau/Ast.h` | `AstAttr::Type` | Changes the nested enum from unscoped `enum` to `enum class`; enumerator values are unchanged. | None. | `vendor/luaur-ast-0.1.8/src/enums/type_ast.rs` | ENGINE | C++-only scoping change; Rust already requires scoped variants. `H1` |
| `Ast/include/Luau/Ast.h` | `AstExprConstantString::QuoteStyle` | Makes the quote-style enum scoped. Values and layout remain unchanged. | None. | `vendor/luaur-ast-0.1.8/src/enums/quote_style_ast.rs` | ENGINE | Rust is already scoped; no behavioral Rust delta. `H2` |
| `Ast/include/Luau/Ast.h` | `AstExprTable::Item::Kind` | Makes table-item kind a scoped enum. | None. | `vendor/luaur-ast-0.1.8/src/enums/kind_ast.rs` | ENGINE | Rust already uses `ItemKind::…`; no semantic port needed. `H3` |
| `Ast/include/Luau/Ast.h` | `AstExprUnary::Op` | Makes unary-operation enum scoped. | None. | `vendor/luaur-ast-0.1.8/src/enums/op_ast.rs` | ENGINE | Rust already uses `AstExprUnaryOp::…`. `H4` |
| `Ast/include/Luau/Ast.h` | `AstStatLocal::keywordLocation` | Adds optional full location of the `local`/`const` keyword for exported local declarations. | Populated only through export-value parsing, effectively `LuauExportValueSyntax && LuauConst2`; both raw defaults OFF. | `vendor/luaur-ast-0.1.8/src/records/ast_stat_local.rs` | ENGINE | New field affects record initialization and pretty-print preservation. Current Rust record lacks it. `H5` |
| `Ast/include/Luau/Cst.h` | `CstExprConstantString::QuoteStyle` | Makes the CST quote-style enum scoped. | None. | `vendor/luaur-ast-0.1.8/src/enums/quote_style_cst.rs` | ENGINE | Rust already has scoped enum variants. `H1` |
| `Ast/include/Luau/Cst.h` | `CstExprTable::Separator` | Makes table separator enum scoped. | None. | `vendor/luaur-ast-0.1.8/src/enums/separator.rs` | ENGINE | Rust already uses scoped variants. `H2` |
| `Ast/include/Luau/Cst.h` | `CstStatLocal::declarationKeywordPosition` | Removes CST-owned export declaration keyword position; ownership moves to `AstStatLocal::keywordLocation`. | Export syntax path; raw `LuauExportValueSyntax` and `LuauConst2` defaults OFF. | `vendor/luaur-ast-0.1.8/src/records/cst_stat_local.rs` | ENGINE | Current Rust record still contains the removed field. `H3` |
| `Ast/include/Luau/Cst.h` | `CstTypeTable::Item::Kind` | Normalizes `enum struct` spelling to `enum class`; values are unchanged. | None. | `vendor/luaur-ast-0.1.8/src/enums/kind_cst.rs` | ENGINE | C++ spelling-only change; Rust already scoped. `H4` |
| `Ast/src/Ast.cpp` | `toString(AstExprUnary::Op)` | Qualifies all unary enum cases through `AstExprUnary::Op`. | None. | `vendor/luaur-ast-0.1.8/src/functions/to_string_ast.rs` | ENGINE | Rust already uses `AstExprUnaryOp::…`; no behavioral delta. `H1` |
| `Ast/src/Cst.cpp` | `CstStatLocal::CstStatLocal` | Stops initializing the removed `declarationKeywordPosition` field. | None directly. | `vendor/luaur-ast-0.1.8/src/methods/cst_stat_local_cst_stat_local.rs` | ENGINE | Must land with removal from the CST record. `H1` |
| `Ast/src/Cst.cpp` | `CstTypeSingletonString::CstTypeSingletonString` | Qualifies `QuotedInterp` through the scoped CST quote-style enum. | None. | `vendor/luaur-ast-0.1.8/src/methods/cst_type_singleton_string_cst_type_singleton_string.rs` | ENGINE | Rust already scoped. `H2` |
| `Ast/src/Parser.cpp` | `FFlag::DesugaredArrayTypeReferenceIsEmpty` | Removes the flag declaration and its branch; array-type desugaring now always uses an empty, zero-width location for synthesized `number`. | Removed flag had raw default OFF; new code hardwires its former **ON** path. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Behavior changes even under raw defaults. Remove the Rust flag and registry entry when porting. `H1`, `H12` |
| `Ast/src/Parser.cpp` | `FFlag::LuauExportValueSyntax` version | Adds `LUAU_FLAGVERSION(LuauExportValueSyntax, 3)`. No value change. | Raw default remains OFF. | `vendor/luaur-common-0.1.8/src/lib.rs`; `vendor/luaur-common-0.1.8/src/macros/luau_flagversion.rs` | ENGINE | Metadata-only, but Rust flag version registration must become `3`. `H1` |
| `Ast/src/Parser.cpp` | `Parser::parseReturn` | On export/top-level-return conflict, reports the error but keeps the parsed return node and sets `hasModuleReturn`; it no longer replaces the statement with an error AST node. | `LuauExportValueSyntax && LuauConst2`; raw default path is OFF. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_return.rs` | ENGINE | Error recovery/AST shape changes when enabled. `H2` |
| `Ast/src/Parser.cpp` | `Parser::parseExportValue` | Duplicate exports now report and continue; invalid `export local/const function` still parses the function for recovery. Moves keyword tracking from CST `Position` to AST `Location`. | Export-value path requires `LuauExportValueSyntax && LuauConst2`; raw defaults OFF. Class branch additionally uses `DebugLuauUserDefinedClasses`, default OFF. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_export_value.rs` | ENGINE | High-fanout parser change; current Rust returns error nodes early and writes the CST field. `H3-H8` |
| `Ast/src/Parser.cpp` | `Parser::extractStringDetails` | Updates CST quote-style assignments to scoped enumerators. | None. | `vendor/luaur-ast-0.1.8/src/methods/parser_extract_string_details.rs` | ENGINE | Rust already scoped. `H9` |
| `Ast/src/Parser.cpp` | `Parser::parseTableType` | Qualifies separator values and permanently synthesizes array index type `number` with an empty location. | Removed `DesugaredArrayTypeReferenceIsEmpty`; hardwired former ON path. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_table_type.rs` | ENGINE | Observable AST source-location change; current Rust retains the flag branch. `H10-H13` |
| `Ast/src/Parser.cpp` | `Parser::parseUnaryOp` | Returns scoped unary enum variants. | None. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_unary_op.rs` | ENGINE | Rust already scoped. `H14` |
| `Ast/src/Parser.cpp` | `Parser::checkUnaryConfusables` | Returns scoped `Not` after reporting `!` confusion. | None. | `vendor/luaur-ast-0.1.8/src/methods/parser_check_unary_confusables.rs` | ENGINE | Rust already scoped. `H15` |
| `Ast/src/Parser.cpp` | `Parser::tableSeparator` | Returns scoped `Comma`, `Semicolon`, or `Missing`. | None. | `vendor/luaur-ast-0.1.8/src/methods/parser_table_separator.rs` | ENGINE | Rust already scoped. `H16` |
| `Ast/src/Parser.cpp` | `Parser::parseTableConstructor` | Qualifies table-item kinds, separators, and unquoted string style. | None. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_table_constructor.rs` | ENGINE | Mechanical scoping only; current Rust already uses scoped variants. `H17-H22` |
| `Ast/src/Parser.cpp` | `Parser::parseString` | Qualifies simple/raw quote styles. | None. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_string.rs` | ENGINE | Mechanical scoping only. `H23` |
| `Ast/src/PrettyPrinter.cpp` | `StringWriter::sourceString` | Qualifies CST quote-style comparisons and switch cases. | None. | `vendor/luaur-ast-0.1.8/src/methods/string_writer_source_string.rs` | ENGINE | Rust already scoped. `H1-H2` |
| `Ast/src/PrettyPrinter.cpp` | `Printer::visualize(AstExpr*)` | Qualifies table-item, separator, and unary enum cases. | None. | `vendor/luaur-ast-0.1.8/src/methods/printer_visualize_pretty_printer_alt_b.rs` | ENGINE | Mechanical scoping only. `H3-H6` |
| `Ast/src/PrettyPrinter.cpp` | `Printer::visualize(AstStat*)` | For exported locals, advances to `AstStatLocal::keywordLocation.begin` instead of reading CST `declarationKeywordPosition`. | `LuauExportValueSyntax && LuauConst2`; raw default OFF. | `vendor/luaur-ast-0.1.8/src/methods/printer_visualize_pretty_printer_alt_c.rs` | ENGINE | Must land with AST field addition/CST field removal; permits preservation without CST ownership. `H7` |
| `Ast/src/PrettyPrinter.cpp` | `Printer::visualizeTypeAnnotation` | Qualifies CST table separator comparisons for indexers and properties. | None. | `vendor/luaur-ast-0.1.8/src/methods/printer_visualize_type_annotation.rs` | ENGINE | Mechanical scoping only. `H8-H9` |

### Compiler

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Compiler/src/Compiler.cpp` | translation-unit include set | Removes unused `<memory>` include. | None. | NONE-untranslated | OUT-OF-SCOPE | C++ build hygiene; no Rust port. `H1` |
| `Compiler/src/Compiler.cpp` | `Compiler::tryIndexConstantTable` | Qualifies table-item kinds. | None. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_try_index_constant_table.rs` | ENGINE | Rust already scoped. `H2` |
| `Compiler/src/Compiler.cpp` | `Compiler::compileExportTable` | Iterates exported classes keyed by `AstLocal*` and derives the emitted class name from `classLocal->name`. | Enclosing class emission uses `DebugLuauUserDefinedClasses`; raw default OFF. Export behavior also depends on `LuauExportValueSyntax`, default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_export_table.rs` | ENGINE | Must match the `exportedClasses` container type change. `H3` |
| `Compiler/src/Compiler.cpp` | `Compiler::compileClassDeclaration` | Registers exported classes immediately after `pushLocal`, calls `ensureExportTable`, and removes end-of-function vector insertion. This permits methods to reference the exported class during compilation. | `DebugLuauUserDefinedClasses` and exported branch `LuauExportValueSyntax`; both raw defaults OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_class_declaration.rs` | ENGINE | High-risk codegen fix; must land with map representation and `compileExpr` changes. `H4-H5` |
| `Compiler/src/Compiler.cpp` | `Compiler::getUnaryOp` | Qualifies unary enum switch cases. | None. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_get_unary_op.rs` | ENGINE | Mechanical in Rust. `H5` |
| `Compiler/src/Compiler.cpp` | `Compiler::compileConditionValue` | Qualifies unary `Not` comparison. | None. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_condition_value.rs` | ENGINE | Mechanical in Rust. `H6` |
| `Compiler/src/Compiler.cpp` | `Compiler::compileExprUnary` | Qualifies unary `Minus` in integer-literal special handling. | `LuauIntegerType2`; raw default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_expr_unary.rs` | ENGINE | Scoping-only delta. `H7` |
| `Compiler/src/Compiler.cpp` | `Compiler::compileExprTable` | Qualifies table-item kinds across sizing, DUPTABLE construction, and trailing-vararg handling. | Some paths use `LuauCompileDuptableConstantPack2`, raw default OFF; both flag branches only receive scoped-name updates. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_expr_table.rs` | ENGINE | Mechanical in Rust. `H8-H11` |
| `Compiler/src/Compiler.cpp` | `Compiler::compileExpr` | Exported class locals bypass export-table lookup. Other exported locals can load the export table from either a local register or an upvalue using the target register as scratch. | `LuauExportValueSyntax`; raw default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_expr.rs` | ENGINE | Critical closure/upvalue codegen correction; current Rust always assumes a local export-table register. `H12` |
| `Compiler/src/Compiler.cpp` | `Compiler::exportedClasses` | Changes storage from `vector<pair<AstName,u8>>` to `DenseHashMap<AstLocal*,u8>{nullptr}`. | Used only by export/class paths; raw relevant flags OFF. | `vendor/luaur-compiler-0.1.8/src/records/compiler.rs` | ENGINE | Container/key type must land atomically with all three compiler consumers. `H13` |
| `Compiler/src/ConstantFolding.cpp` | `foldUnary` | Qualifies `Not`, `Minus`, and `Len` cases. | None. | `vendor/luaur-compiler-0.1.8/src/functions/fold_unary.rs` | ENGINE | Mechanical in Rust. `H1-H3` |
| `Compiler/src/Types.cpp` | `TypeMapVisitor::visit(AstExprUnary*)` | Qualifies unary enum cases used to record bytecode types. | None. | `vendor/luaur-compiler-0.1.8/src/methods/type_map_visitor_visit_types_alt_k.rs` | ENGINE | Mechanical in Rust. `H1-H2` |

### Require

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Require/include/Luau/Require.h` | `luarequire_Configuration::load` callback contract | Documents that the module placeholder/require table is at stack index 6 and should be passed as the module chunk’s first argument to support cycles. | True only for `LuauCyclicRequireShortCircuit` ON; raw default is OFF. | NONE-untranslated | RT-API | Signature is unchanged, but callback stack contract changes when enabled. `H1` |
| `Require/src/RequireImpl.cpp` | `FFlag::LuauCyclicRequireShortCircuit` | Adds a new static fast flag controlling the entire cyclic-require implementation. | New raw default OFF. | NONE-new | ENGINE | Rust has no translated Require subsystem. `H1` |
| `Require/src/RequireImpl.cpp` | `modulePlaceholdersKey` | Adds registry key `_MODULEPLACEHOLDERS` for currently loading module placeholders keyed by chunk name. | Used only with cyclic-require flag ON. | NONE-new | ENGINE | Registry lifetime and cleanup are part of the new cycle state machine. `H2` |
| `Require/src/RequireImpl.cpp` | `CyclicDependencyIndexError` | New `__index` handler that errors when reading an invalidated placeholder export. | Flag ON path only. | NONE-new | ENGINE | Error message includes requested key. `H3` |
| `Require/src/RequireImpl.cpp` | `CyclicDependencyNewIndexError` | New `__newindex` handler that errors when writing an invalidated placeholder export. | Flag ON path only. | NONE-new | ENGINE | Error message includes requested key. `H3` |
| `Require/src/RequireImpl.cpp` | `invalidateModulePlaceholder` | Replaces placeholder metatable with locked error handlers while preserving the previous metatable in `__prev_metatable`. | Flag ON callers only. | NONE-new | ENGINE | Restoration depends on exact stack/metatable discipline. `H3` |
| `Require/src/RequireImpl.cpp` | `kRequireStackValues` | Changes fixed require continuation slots from 4 to 6 for path, key, chunkname, loadname, requirer chunkname, and placeholder. | Represents flag ON layout. | NONE-untranslated | ENGINE | Existing C symbol was untranslated; value changes from 4 to 6. `H3` |
| `Require/src/RequireImpl.cpp` | `kRequireStackValues_DEPRECATED` | Adds constant `4` for the old flag-OFF stack layout. | Flag OFF path uses this constant. | NONE-new | ENGINE | Prevents old callback layout from changing while the flag is dark. `H3` |
| `Require/src/RequireImpl.cpp` | `lua_requirecont` | Selects 4/6 fixed slots; on flag ON, freezes/invalidates replaced placeholders, updates cache, deregisters completed module, and restores the requiring module’s prior metatable. OFF retains old result caching. | `LuauCyclicRequireShortCircuit`; raw default executes OFF/legacy branch. | NONE-untranslated | ENGINE | Complex stack-index and error-path behavior; zero/multiple results and returned-placeholder identity are significant. `H3` |
| `Require/src/RequireImpl.cpp` | `lua_requireinternal` | On flag ON, records requirer name, invalidates its placeholder during a cycle, pre-caches/registers a new placeholder at slot 6, and passes the six-slot layout to `load`. | Raw default executes OFF/legacy four-slot path. | NONE-untranslated | ENGINE | Must agree exactly with `lua_requirecont` and embedder callback behavior. `H4` |

### VM and public API

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `VM/include/lua.h` | `lua_setuserdatametatable` / `lua_getuserdatametatable` contract | Notes that `LuauUdataMetatablePinned` removes the requirement that tag metatables already be rooted through `luaL_newmetatable`. | New flag raw default OFF, so old restriction remains by default. | `vendor/luaur-vm-0.1.8/src/functions/lua_setuserdatametatable.rs`; `vendor/luaur-vm-0.1.8/src/functions/lua_getuserdatametatable.rs` | RT-API | Documentation corresponds to GC pinning changes; signatures unchanged. `H1` |
| `VM/include/luaconf.h` | `LUA_MINSTACK` contract | Redefines the comment from a guaranteed number of available C-function slots to the initial number of reserved slots. | Effective auto-growth requires `LuauAutoStack` ON; raw default OFF. | `vendor/luaur-vm-0.1.8/src/macros/lua_minstack.rs` | RT-API | Public stack-capacity contract changes without changing constant value `20`. `H1` |
| `VM/include/lualib.h`; `VM/src/laux.cpp` | `luaL_pcallyieldable` | Adds public protected/yieldable-call helper. Stores error-function index on `CallInfo`, calls through `luaD_pcall`, propagates yields, clears HANDLE on synchronous completion, then invokes the C continuation. | Asserts `LuauCustomYieldablePcalls` ON; raw default OFF. | NONE-new | RT-API | New API declaration and implementation; no current `luaur-rt` wrapper exists. `lualib H1`, `laux H2` |
| `VM/src/lapi.cpp` | `FFlag::LuauAutoStack` | Adds flag controlling automatic stack growth for push/get/call APIs. | New raw default OFF. | NONE-new | ENGINE | Nuxie’s Rust runtime calls `set_all_flags(true)`; registry inclusion would make this ON locally. `H1` |
| `VM/src/lapi.cpp` | `FFlag::LuauCloneTableFix` | Adds flag for GC check/thread barrier before cloning a table. | New raw default OFF. | NONE-new | ENGINE | Flag-ON branch changes allocation/barrier ordering. `H1`, `H34` |
| `VM/src/lapi.cpp` | `ensure_stack_impl` macro | New macro checks whether `top + size` exceeds `ci->top`; under `LuauAutoStack`, calls `lua_checkstack`, then raises `"stack overflow"` on `errorL` if growth fails. | Guarded by `LuauAutoStack`; raw default OFF means no action. | NONE-new | ENGINE | `errorL` differs from target state for cross-thread moves. `H2` |
| `VM/src/lapi.cpp` | `ensure_stack` macro | Convenience wrapper using the same state as both target and error state. | `LuauAutoStack`; raw default OFF. | NONE-new | ENGINE | Required by all following API changes. `H2` |
| `VM/src/lapi.cpp` | `luaA_pushvalue` | Ensures one stack slot before pushing an internal TValue. | `LuauAutoStack`; raw default keeps old assertion behavior. | `vendor/luaur-vm-0.1.8/src/functions/lua_a_pushvalue.rs` | ENGINE | Internal helper, but broad call fanout. `H3` |
| `VM/src/lapi.cpp` | `luaA_pushclass` | Ensures one stack slot before pushing a class value. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_a_pushclass.rs` | ENGINE | Internal class API. `H3` |
| `VM/src/lapi.cpp` | `lua_xmove` | Replaces destination-capacity assertion with automatic growth; failures are raised on the source state. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_xmove.rs` | RT-API | Cross-thread error state is intentional and must be mirrored. `H4` |
| `VM/src/lapi.cpp` | `lua_xpush` | Ensures one destination slot, raising growth failure on the source state. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_xpush.rs` | RT-API | Cross-thread stack/barrier ordering matters. `H5` |
| `VM/src/lapi.cpp` | `lua_newthread` | Ensures one parent-stack slot before storing the new thread. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_newthread.rs` | RT-API | Growth can allocate before thread allocation. `H6` |
| `VM/src/lapi.cpp` | `lua_settop` | Replaces direct `stack_last` bound assertion with `ensure_stack` for positive-index expansion. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_settop.rs` | RT-API | Changes API from fixed-capacity assertion to possible allocation/error. `H7` |
| `VM/src/lapi.cpp` | `lua_pushvalue` | Ensures one slot before copying the indexed value. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushvalue.rs` | RT-API | `H8` |
| `VM/src/lapi.cpp` | `lua_pushnil` | Ensures one slot before push. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushnil.rs` | RT-API | `H9` |
| `VM/src/lapi.cpp` | `lua_pushnumber` | Ensures one slot before push. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushnumber.rs` | RT-API | `H9` |
| `VM/src/lapi.cpp` | `lua_pushinteger` | Ensures one slot before push. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushinteger.rs` | RT-API | `H9` |
| `VM/src/lapi.cpp` | `lua_pushinteger64` | Ensures one slot before push. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushinteger_64.rs` | RT-API | `H9` |
| `VM/src/lapi.cpp` | `lua_pushunsigned` | Ensures one slot before push. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushunsigned.rs` | RT-API | `H9` |
| `VM/src/lapi.cpp` | `lua_pushvector` | Both three- and four-component builds ensure one slot before push. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushvector_lapi.rs`; `vendor/luaur-vm-0.1.8/src/functions/lua_pushvector_lapi_alt_b.rs` | RT-API | Both compile-time vector-size variants must be updated. `H10` |
| `VM/src/lapi.cpp` | `lua_pushlstring` | Ensures one slot before allocating/interning and pushing the string. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushlstring.rs` | RT-API | Preserve GC/barrier/ensure ordering. `H11` |
| `VM/src/lapi.cpp` | `lua_pushcclosurek` | Ensures one result slot before validating upvalues and allocating the closure. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushcclosurek.rs` | RT-API | Directly targets the recorded Nuxie stack-assertion symptom. `H12` |
| `VM/src/lapi.cpp` | `lua_pushboolean` | Ensures one slot before push. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushboolean.rs` | RT-API | `H13` |
| `VM/src/lapi.cpp` | `lua_pushlightuserdatatagged` | Ensures one slot before tag validation/push. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushlightuserdatatagged.rs` | RT-API | `H13` |
| `VM/src/lapi.cpp` | `lua_pushthread` | Ensures one slot before pushing the current thread. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushthread.rs` | RT-API | `H14` |
| `VM/src/lapi.cpp` | `lua_getfield` | Ensures one result slot before lookup. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_getfield.rs` | RT-API | Metamethod lookup may yield/allocate after growth. `H15` |
| `VM/src/lapi.cpp` | `lua_rawgetfield` | Ensures one result slot before raw lookup. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_rawgetfield.rs` | RT-API | `H16` |
| `VM/src/lapi.cpp` | `lua_rawgeti` | Ensures one result slot before numeric lookup. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_rawgeti.rs` | RT-API | `H17` |
| `VM/src/lapi.cpp` | `lua_rawgetptagged` | Ensures one result slot before tagged-pointer lookup. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_rawgetptagged.rs` | RT-API | `H18` |
| `VM/src/lapi.cpp` | `lua_createtable` | Ensures one result slot before allocating/pushing the table. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_createtable.rs` | RT-API | Preserve GC check/barrier ordering. `H19` |
| `VM/src/lapi.cpp` | `lua_getmetatable` | Ensures one slot even though it may return no value. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_getmetatable.rs` | RT-API | Can grow unnecessarily when no metatable exists; mirror C exactly. `H20` |
| `VM/src/lapi.cpp` | `lua_getfenv` | Ensures one result slot before selecting/pushing environment. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_getfenv.rs` | RT-API | `H21` |
| `VM/src/lapi.cpp` | `checkresults` macro | Removes fixed-capacity result assertion used by `lua_call`/`lua_pcall`. | Replaced by `LuauAutoStack` growth logic. | `vendor/luaur-vm-0.1.8/src/macros/checkresults.rs` | ENGINE | Current Rust macro should be removed from these call paths. `H22` |
| `VM/src/lapi.cpp` | `lua_call` | If fixed `nresults` exceeds consumed function/argument slots, grows by the difference before the call. | `LuauAutoStack`; raw default OFF leaves no growth/check replacement beyond existing assertions. | `vendor/luaur-vm-0.1.8/src/functions/lua_call.rs` | RT-API | `LUA_MULTRET` bypasses growth. `H22` |
| `VM/src/lapi.cpp` | `lua_pcall` | Mirrors `lua_call` result-capacity growth before protected execution. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pcall.rs` | RT-API | Error-function stack offsets must remain valid across growth. `H23` |
| `VM/src/lapi.cpp` | `lua_next` | Ensures one extra slot before iteration. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_next.rs` | RT-API | Existing key plus possible key/value result drives net capacity need. `H24` |
| `VM/src/lapi.cpp` | `lua_rawiter` | Ensures two slots before raw iteration. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_rawiter.rs` | RT-API | Exact requested size is two. `H25` |
| `VM/src/lapi.cpp` | `lua_concat` | For `n == 0`, ensures one slot before pushing the empty string. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_concat.rs` | RT-API | Other concat paths unchanged. `H26` |
| `VM/src/lapi.cpp` | `lua_newuserdatatagged` | Ensures one slot before userdata allocation/push. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_newuserdatatagged.rs` | RT-API | Preserve allocation/GC ordering. `H27` |
| `VM/src/lapi.cpp` | `lua_newuserdatataggedwithmetatable` | Ensures one slot before userdata allocation and metatable assignment. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_newuserdatataggedwithmetatable.rs` | RT-API | Interacts with tagged-metatable pinning but has no direct pin flag branch. `H28` |
| `VM/src/lapi.cpp` | `lua_newuserdatadtor` | Ensures one slot before destructor userdata allocation. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_newuserdatadtor.rs` | RT-API | Preserve size-overflow handling. `H29` |
| `VM/src/lapi.cpp` | `lua_newbuffer` | Ensures one slot before buffer allocation. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_newbuffer.rs` | RT-API | `H30` |
| `VM/src/lapi.cpp` | `lua_getupvalue` | Ensures one slot before querying/pushing an upvalue. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_getupvalue.rs` | RT-API | Growth occurs even when the requested upvalue does not exist. `H31` |
| `VM/src/lapi.cpp` | `lua_getuserdatametatable` | Ensures one slot before pushing the tagged metatable or nil. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_getuserdatametatable.rs` | RT-API | Also relies on pinning for metatables not otherwise rooted. `H32` |
| `VM/src/lapi.cpp` | `lua_clonefunction` | Ensures one slot before cloning/pushing a Lua closure. | `LuauAutoStack`; raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_clonefunction.rs` | RT-API | Preserve GC check/barrier before ensure. `H33` |
| `VM/src/lapi.cpp` | `lua_clonetable` | Under clone-fix flag, adds GC check and thread barrier; independently ensures one result slot before cloning. | `LuauCloneTableFix` and `LuauAutoStack`; both raw defaults OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_clonetable.rs` | RT-API | Two independent dark changes share one hunk. `H34` |
| `VM/src/laux.cpp` | `luaL_pcallyieldable::CallContext` | New local context holds function stack pointer and desired result count; its runner invokes `luaD_callint` with current yieldability. | Used only by `LuauCustomYieldablePcalls` API. | NONE-new | ENGINE | Function pointer may move during stack reallocation, so saved stack offset handling is essential. `H2` |
| `VM/src/laux.cpp`; `VM/src/lbaselib.cpp`; `VM/src/ldo.cpp` | `FFlag::LuauCustomYieldablePcalls` | Adds one flag definition plus declarations in base-library and call machinery files. | New raw default OFF. | NONE-new | ENGINE | Controls a multi-file state-machine change; must not be partially ported. `laux H1`, `lbaselib H1`, `ldo H1` |
| `VM/src/lbaselib.cpp` | `luaB_pcallrun` | Adds assertion that legacy helper is used only with custom yieldable pcalls OFF. | Raw default OFF, so assertion passes. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_pcallrun.rs` | ENGINE | `H2` |
| `VM/src/lbaselib.cpp` | `luaB_pcally` | Flag ON delegates to `luaL_pcallyieldable`; OFF retains the legacy protected-call implementation. | Raw default executes OFF/legacy branch. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_pcally.rs` | ENGINE | Lua-visible `pcall` yield/error behavior changes when enabled. `H3` |
| `VM/src/lbaselib.cpp` | `luaB_xpcally` | Flag ON delegates to `luaL_pcallyieldable` with error function at stack index 1; OFF retains legacy path. | Raw default executes OFF/legacy branch. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_xpcally.rs` | ENGINE | Error-handler index must match new `CallInfo::errfunc` semantics. `H4` |
| `VM/src/lbaselib.cpp` | `luaB_xpcallerr` | Asserts this legacy error wrapper is only used with the new flag OFF. | Raw default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_xpcallerr.rs` | ENGINE | `H4` |
| `VM/src/lbaselib.cpp` | `luaB_xpcallcont` | Adds flag-ON error continuation returning exactly `false, error`; legacy branch retains its previous stack rebuild. | Raw default uses legacy OFF branch. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_xpcallcont.rs` | ENGINE | Stack insertion position `-2` is significant. `H5` |
| `VM/src/ldo.cpp` | `resume_continue` | For custom pcalls, clears HANDLE before invoking C continuation and loops directly on `SCHEDULED_REENTRY` instead of performing `luau_poscall`. | Raw default OFF preserves old behavior. | `vendor/luaur-vm-0.1.8/src/functions/resume_continue.rs` | ENGINE | Continuation state-machine change; partial port can corrupt call frames. `H2-H3` |
| `VM/src/ldo.cpp` | `restore_stack_limit` | Adds hard-stack-test reallocation of the current CI size when the call-info stack is not over `LUAI_MAXCALLS`. | Unguarded. | `vendor/luaur-vm-0.1.8/src/functions/restore_stack_limit.rs` | ENGINE | Test/debug macro may be no-op in normal builds, but structure must mirror C. `H4` |
| `VM/src/ldo.cpp` | `callerrfunc` | Moves the existing function earlier so `resume_handle` can invoke it; body is unchanged. | Called from new flag-ON resume path; existing `luaD_pcall` usage remains. | `vendor/luaur-vm-0.1.8/src/functions/callerrfunc.rs` | ENGINE | Rust already has a separate function file, so source-order relocation needs no Rust move. `H4`, `H6` |
| `VM/src/ldo.cpp` | `resume_handle` | Adds user error-handler execution, status normalization, restored CI/closure handling before continuation, and early return if continuation changes status. OFF preserves legacy ordering. | `LuauCustomYieldablePcalls`; raw default executes OFF/legacy branch. | `vendor/luaur-vm-0.1.8/src/functions/resume_handle.rs` | ENGINE | Highest-risk custom-pcall hunk; depends on `CallInfo::errfunc`, `callerrfunc`, and helper semantics. `H5` |
| `VM/src/lgc.cpp` | `FFlag::LuauUdataMetatablePinned` | Adds flag controlling root marking of tagged userdata metatables. | New raw default OFF. | NONE-new | ENGINE | Nuxie registry policy may enable it even though C raw default is dark. `H1` |
| `VM/src/lgc.cpp` | `marktaggetmt` | New helper marks every non-null `global_State::udatamt` entry. | Called only with pin flag ON. | NONE-new | ENGINE | Loop bound must be `LUA_UTAG_LIMIT`, not internal-tag limit. `H2` |
| `VM/src/lgc.cpp` | `markroot` | Marks tagged userdata metatables after normal metatables when pinning is enabled. | Raw default OFF skips new marking. | `vendor/luaur-vm-0.1.8/src/functions/markroot.rs` | ENGINE | Required to make public relaxed metatable contract safe. `H3` |
| `VM/src/lgc.cpp` | `atomic` | Re-marks tagged userdata metatables during atomic GC phase when pinning is enabled. | Raw default OFF skips new marking. | `vendor/luaur-vm-0.1.8/src/functions/atomic.rs` | ENGINE | Both root and atomic marking sites are required. `H4` |
| `VM/src/lgcdebug.cpp` | `luaC_validate` | Adds unconditional validation that every non-null tagged userdata metatable is not dead. | No direct guard, though logically paired with `LuauUdataMetatablePinned`. | `vendor/luaur-vm-0.1.8/src/functions/lua_c_validate.rs` | ENGINE | Validation is unconditional even while pinning defaults OFF; mirror exactly. `H1` |
| `VM/src/lstate.cpp` | `lua_newstate` | Initializes `udatadirectfields` unconditionally instead of only when `LuauDirectFieldGet` is ON. | Removed usage of existing flag; new code hardwires former **ON** initialization path. | `vendor/luaur-vm-0.1.8/src/functions/lua_newstate.rs` | ENGINE | Prevents uninitialized entries if flag state changes after state creation. `H1` |
| `VM/src/lstate.h` | `CallInfo` | Replaces `savedpc` field with a union: Lua frames use `savedpc`, C frames use integer stack index `errfunc`. | Structural change unguarded; `errfunc` is used by custom-pcall flag ON path. | `vendor/luaur-vm-0.1.8/src/records/call_info.rs` | ENGINE | ABI/layout stays one pointer-sized union slot in C++; Rust representation must preserve union semantics and initialization. `H1` |
| `VM/src/lvmexecute.cpp`; `VM/src/lstate.cpp` | `FFlag::LuauDirectFieldGet` version/init gate | Adds flag version `2`; separately removes this flag’s guard around direct-field array initialization. | Existing raw default remains OFF; initialization now follows former ON path regardless. | `vendor/luaur-common-0.1.8/src/lib.rs`; `vendor/luaur-vm-0.1.8/src/functions/lua_newstate.rs` | ENGINE | Version metadata does not enable behavior. Existing Rust `LUAU_FLAGVERSION` machinery is available. `lvmexecute H1`, `lstate H1` |

## FFlag inventory

Raw defaults below mean the values constructed by the engine’s `LUAU_FASTFLAGVARIABLE` macros. Luau CLI tools may explicitly enable nonexperimental `Luau*` flags after startup; that is separate from the compiled engine default.

| flag | rung change | gated behavior | raw-default release path |
|---|---|---|---|
| `DesugaredArrayTypeReferenceIsEmpty` | **Removed** | Selected empty source locations for synthesized `number` in `{T}` array types. | It previously defaulted OFF, but 0.725 hardwires the former **ON** behavior. |
| `LuauExportValueSyntax` | Adds version metadata **3** | Existing export-value parser/compiler/pretty-printer behavior; this rung improves recovery, locations, class self-reference, and export-table upvalues. | **OFF**. Version metadata does not flip it. |
| `LuauCyclicRequireShortCircuit` | **Added** | Placeholder caching, cycle short-circuiting, invalidation, restoration, and six-slot require callback layout. | **OFF**: legacy four-slot require behavior. |
| `LuauAutoStack` | **Added** | Automatic stack growth in core public push/get/call APIs. | **OFF**: old fixed-reservation/assertion behavior. |
| `LuauCloneTableFix` | **Added** | Performs GC check and thread barrier before `lua_clonetable`. | **OFF**: old clone path without those calls. |
| `LuauCustomYieldablePcalls` | **Added** | New `luaL_pcallyieldable` path, `pcall`/`xpcall` delegation, error-handler storage, and resume-state changes. | **OFF**: legacy base-library pcall implementation. |
| `LuauUdataMetatablePinned` | **Added** | Pins tagged userdata metatables during root and atomic GC marking. | **OFF**: metatables must remain rooted through the prior mechanism. |
| `LuauDirectFieldGet` | Adds version metadata **2**; removes one initialization guard | Existing direct-field-get feature remains flag-controlled, but `udatadirectfields` is now always initialized. | Flag remains **OFF**; initialization alone now follows the former ON path. |

No DFFlag, DFInt, or FInt was added, removed, or given a new default in this scoped diff.

### Rust-local flag-policy warning

Current `luaur-rt` constructors call `luaur_common::set_all_flags(true)` in `vendor/luaur-rt-0.1.8/src/state.rs`. Therefore, if the new `Luau*` flags are added to the Rust `set_all_flags` registry in the ordinary way, Nuxie will execute their **ON** paths even though their C static defaults are OFF. `LuauExportValueSyntax` is already an explicit local exception kept OFF.

## Completeness accounting

Default-context hunk counts:

| file | hunks |
|---|---:|
| `Ast/include/Luau/Ast.h` | 5 |
| `Ast/include/Luau/Cst.h` | 4 |
| `Ast/src/Ast.cpp` | 1 |
| `Ast/src/Cst.cpp` | 2 |
| `Ast/src/Parser.cpp` | 23 |
| `Ast/src/PrettyPrinter.cpp` | 9 |
| `Compiler/src/Compiler.cpp` | 13 |
| `Compiler/src/ConstantFolding.cpp` | 3 |
| `Compiler/src/Types.cpp` | 2 |
| `Require/include/Luau/Require.h` | 1 |
| `Require/src/RequireImpl.cpp` | 4 |
| `VM/include/lua.h` | 1 |
| `VM/include/luaconf.h` | 1 |
| `VM/include/lualib.h` | 1 |
| `VM/src/lapi.cpp` | 34 |
| `VM/src/laux.cpp` | 2 |
| `VM/src/lbaselib.cpp` | 5 |
| `VM/src/ldo.cpp` | 6 |
| `VM/src/lgc.cpp` | 4 |
| `VM/src/lgcdebug.cpp` | 1 |
| `VM/src/lstate.cpp` | 1 |
| `VM/src/lstate.h` | 1 |
| `VM/src/lvmexecute.cpp` | 1 |
| **Total** | **125** |

`Common`, `Config`, `Bytecode`, and `Inliner` contribute zero hunks.

- **Hunks:** total **125** / attributed **125** / unresolved **0**
- **Ledger rows:** **114**
- **Rows by class:** ENGINE **73** / RT-API **40** / OUT-OF-SCOPE **1**
- **UNRESOLVED:** none

## Dependency notes

No symbol in this first rung depends on a change from a prior post-0.724 rung. The referenced pre-existing flags, enum values, VM APIs, `DenseHashMap`, and `LUAU_FLAGVERSION` infrastructure are already present at the 0.724 baseline.

Within this rung, the required landing order is:

1. `AstStatLocal::keywordLocation` and removal of `CstStatLocal::declarationKeywordPosition` must precede the parser and pretty-printer changes.
2. `Compiler::exportedClasses` must change to `DenseHashMap<AstLocal*,u8>` together with `compileClassDeclaration`, `compileExportTable`, and `compileExpr`; none is safe independently.
3. `LuauAutoStack` plus `ensure_stack_impl`/`ensure_stack` must exist before porting the 34 `lapi.cpp` call-site hunks.
4. `CallInfo::errfunc`, `luaL_pcallyieldable`, the base-library pcall branches, and `ldo.cpp` resume changes form one atomic custom-pcall feature.
5. `marktaggetmt`, both GC marking call sites, and `luaC_validate` form the userdata-metatable pinning unit.
6. The cyclic-require six-slot layout, placeholder registry, continuation, internal loader, and embedder callback contract must land together.