# Writer lane: luau-fork rung 2 (official 0.725 -> 0.726)

You are a production writer porting one upstream Luau release delta into
Nuxie's vendored luaur fork. Read `docs/luau-fork.md` first, then the
translation-convention context in `.luau-fork-work/prompts/preamble.md`, then
the adjudicated ledger at `.luau-fork-work/inventory/job2.md` — the ledger is
your binding work-list. The C-side diff is:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff 91caa731..86d2a9dc -- VM Compiler Ast Common Config Require Bytecode Inliner`

Rung 1 (0.725) is already landed on this tree — the ledger's dependency
notes about 0.725 prerequisites (parseExportValue rewrite, table-item enum
scoping) are satisfied; verify the twin's current state matches that
expectation before porting a dependent row, and record any mismatch in the
blocked file rather than improvising.

## Hard rules

1. STRUCTURE-PRESERVING. Each ledger row names a changed C symbol and its
   Rust twin file. Port the C hunk into the twin mirroring the C change
   shape. Never re-architect, never "improve", never deviate from luaur's
   existing idioms. A NONE-new symbol gets a new file following the same
   conventions, wired into the module tree exactly like its siblings.
2. ROW-BY-ROW COMMITS. For each ledger row or atomic row-group: implement ->
   focused gate -> `git add` ONLY that row's files -> commit with message
   `luau-fork rung2: <symbol> (<c-file>) [91caa731..86d2a9dc]`.
   Plain commits, NO Co-Authored-By or other trailers.
3. Focused per-row gate: `cargo check -p nuxie --features scripting` plus
   `cargo test -p nuxie-scripting --lib` (4 pre-existing failures in
   `vm::context_init_tests` are baseline — ignore exactly those).
4. FFLAG POLICY (binding): new flags `LuauCstAttr` and `LuauVirtualBcBuilder`
   are registered in luaur-common's registry AND pinned `.set(false)` inside
   `set_all_flags` (the mechanism rung 1 established for `LuauAutoStack` et
   al. in `vendor/luaur-common-0.1.8/src/lib.rs`). Never flip a new flag ON.
   The REMOVED flag `LuauCompileDuptableConstantPack2` is deleted from the
   registry, from `set_all_flags`, and from every use site, hardwiring the
   former-ON path exactly as upstream does — including sites where the Rust
   baseline had already baked parts of it ON (table-shape equality/hash);
   after this rung those sites must match upstream's unconditional code, and
   the removal must be consistent everywhere the Rust flag currently appears
   (grep for it; a leftover reference is a build break or worse).
5. Atomic row-groups:
   a. Attribute-CST unit (`LuauCstAttr`): all new CST records
      (`CstAttr`, `CstParametrizedAttr`, `CstAttrList`), record field
      additions, the parseAttribute split
      (`parseAttribute`/`parseAttribute_DEPRECATED`/`parseAttrList`/
      `parseAttributes`/`getAttributeStartLocation`), the propagation
      through parseFunctionStat/parseLocal*/parseExportValue/
      parseFunctionBody/parseAttributedFunction/parseSimpleExpr/
      parseCallList, and the pretty-printer rows. Commit as a
      `[group a N/M]` series; the flag-OFF legacy paths must remain
      byte-equivalent to the current behavior.
   b. Duptable-pack removal + `LBC_VERSION_TARGET = 7` +
      `BytecodeBuilder::getVersion` + `writeFunction`
      `LBC_CONSTANT_TABLE_WITH_CONSTANTS` emission + `compileExprTable`
      unconditional packing + TableShape equality/hash: ONE atomic group —
      landing the behavior without the version constant (or vice versa)
      emits inconsistent bytecode.
   c. `GETIMPORT` decomposition: `BcGetImport` + graph-parser decode +
      serializer reconstruct: one atomic group (round-trip 1-3 components).
   d. `LuauVirtualBcBuilder` scaffolding: helpers
      (`calcLinesSpan`/`fillBaselineInfo`/`clearState`/`validateConst`/
      `validateProto`/`validateClosure`) + the flag-gated call sites in
      `endFunction`/`writeLineInfo`/`validateInstructions`. C++ "virtual"
      dispatch has no luaur analogue: translate the hooks as plain methods
      in luaur's existing method idiom, preserving BOTH the ON and OFF code
      paths behind the flag exactly. The C++ `virtual`/`protected`/
      destructor rows with no behavioral Rust payload are no-op rows —
      verify and record them in the no-op file.
   e. CallInliner correctness fixes (`replaceNamecall`, `setReturnOp`,
      `migrateInstructions`, `fillUnderCallArguments`, `inlineTarget`,
      `validate`/`validatePhis`, `callerFbVecSize` threading, `inlineCall`
      signature): port exactly; `fillUnderCallArguments` is high-risk
      (previous indexing underflowed unsigned Reg — mirror the fixed bounds
      precisely).
   f. `BcImm`/`BcVmConst` kind-aware equality: the existing Rust twins may
      derive or hand-roll equality with different semantics (the ledger
      warns the union-backed compare may look at the wrong member). Replace
      with explicit implementations matching C's new operators exactly —
      including exact floating-point `==` semantics (NaN inequality) and
      per-kind payload selection.
   g. `expandJumps` return-type change: update the signature and every Rust
      caller (they may continue to ignore the result, but the signature
      must match).
   h. `Compiler::hasMultiRet` unit: record field + `compileStatReturn`
      tracking + `compileFunction` eligibility/reset.
6. If a row cannot be ported faithfully, SKIP it, record it in
   `.luau-fork-work/rung2-blocked.md` with the reason, and continue. No-op
   rows go to `.luau-fork-work/rung2-noop.md` after verifying the claim.
7. At the end: add ONE rung-level entry to each modified crate's
   `NUXIE_PATCH.md`: "Ported official Luau 0.726 delta (upstream
   91caa731..86d2a9dc)" plus touched areas. Commit as
   `luau-fork rung2: NUXIE_PATCH.md rung entries`.
8. Then run `cargo test -p nuxie --features scripting` once; fix forward
   only rows YOU touched; anything else goes in the blocked file. Final
   message: rows ported / no-op / skipped, commits, gate results, surprises.

Do not touch: workspace `Cargo.toml`, `Cargo.lock`, `docs/`, `corpus.toml`,
any crate outside `vendor/luaur-*`, `NUXIE_PROVENANCE.md` files, or anything
under `.luau-fork-work/` except the two report files named above.
