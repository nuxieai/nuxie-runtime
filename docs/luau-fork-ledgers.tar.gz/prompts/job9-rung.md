# Job 9: rung inventory — official 0.732 -> rive_0_732 fork tip 86eb0096

Diff range: `decb2d05..origin/rive_0_732` in /Users/levi/dev/oss/luigi-rosso-luau, scoped to:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff decb2d05..origin/rive_0_732 -- VM Compiler Ast Common Config Require Bytecode Inliner`

Inventory every hunk of that diff per the required output format in the
context above. The Rust twin check is against the CURRENT vendored crates in
this repo (which sit at the 0.724 baseline — for rungs after the first, a
twin whose earlier-rung context has not landed yet is still the correct twin
path; note the dependency in the dependency-notes section instead).

Fork-patch context you must pay special attention to (these are rive-authored
patches the pinned C++ runtime ships): LBC_VERSION_TARGET held at 7 for
pre-rive_0_36 runtime compatibility (18b6d3b3); Rive Vector fast functions
operating on all 3 components (5a6e21b4); native math.fround builtin in the
Rive LBF block (c57dea32); unconditional udatadirectfields init to survive
FFlag flip after newstate (01ca363b); buffer extension type declarations
(e1c64312); require-path behaviors (b19ba2a9, 30e5e1a2, c146794d); RIVE_LUAU
define (ac021354); pusherror only pushes message (8ebb53b8); debug info at
level 0 fallback (70c4630e). Also enumerate the fork-only directories
Bytecode/ and Inliner/ — determine whether the pinned rive-runtime build
actually compiles them (check Sources.cmake / CMakeLists) before classing.
