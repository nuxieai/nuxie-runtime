# Writer lane: luau-fork rung 3 (official 0.726 -> 0.727)

You are a production writer porting one upstream Luau release delta into
Nuxie's vendored luaur fork. Read `docs/luau-fork.md`, then
`.luau-fork-work/prompts/preamble.md`, then the binding ledger
`.luau-fork-work/inventory/job3.md`. The C-side diff is:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff 86d2a9dc..f1f121dc -- VM Compiler Ast Common Config Require Bytecode Inliner`

Rungs 1 (0.725) and 2 (0.726) are landed on this tree — the ledger's
dependency notes (CallInfo savedpc/errfunc union, attribute-CST signatures,
`parseAttributedFunction`) are satisfied; verify each dependent twin's state
before porting and record mismatches in the blocked file, never improvise.

## Hard rules

1. STRUCTURE-PRESERVING, ROW-BY-ROW COMMITS, focused gates, report files —
   identical protocol to rungs 1-2. Commit message prefix:
   `luau-fork rung3: <symbol> (<c-file>) [86d2a9dc..f1f121dc]`. Plain
   commits, no trailers. Focused gate: `cargo check -p nuxie --features
   scripting` + `cargo test -p nuxie-scripting --lib` (the 4 pre-existing
   `vm::context_init_tests` failures are baseline — ignore exactly those).
2. FFLAG POLICY (binding, same as prior rungs):
   - NEW flags (`LuauDisallowExternClassInTypeDefinitions`,
     `LuauStoreConstKeywordBegin`, and every other flag the ledger marks
     Added — including the CallInfo-proto / proto-promotion / GC-accounting
     gates) register in luaur-common AND pin `.set(false)` in
     `set_all_flags`. Never flip one ON.
   - REMOVED flags hardwire exactly the side upstream keeps:
     `LuauConst2`, `LuauCstTypeGroup`, `LuauCompileNoOptNext`,
     `LuauCompilePropagateTableProps2`, `LuauCompileFoldOptimize`,
     `LuauCompileFastcall3CostModel` hardwire their ON paths;
     `LuauClosureUsageCounter` is removed WITH its machinery — delete the
     `Closure::usage` field and every counter touch point (the OFF side is
     what upstream keeps). Each removal must be grep-complete across
     vendor/ (registry, set_all_flags, all sites).
3. Atomic row-groups:
   a. Closure-usage removal: `Closure` layout + `luaF_newLclosure`/
      `luaF_newCclosure` + every frame-entry/exit/unwind counter site +
      flag removal. One group.
   b. `CallInfo` gains `Proto* p`: layout row + every initialization/
      maintenance site the ledger lists, matching C field ORDER exactly in
      the `repr(C)` struct (it sits on top of rung-2's union — verify
      offsets by reading C `lstate.h` at f1f121dc).
   c. Proto optimized/deoptimized links: `Proto` layout + `luaF_newproto`
      init + `traverseproto` GC marking (unconditional — GC safety) +
      `getproto` macro + `luaF_promoteproto` (both flag paths, single
      evaluation, C-closure null behavior).
   d. Each removed-compiler-flag hardwiring is its own group per flag
      (Const2 is large: parser + compiler + printer + deprecated-parser
      deletion together).
   e. GC dummy-node accounting (`propagatemark` + `cleartable`): one group,
      identical formula both sites, flag-gated per ledger.
4. `Inliner/` rows (all OUT-OF-SCOPE in the ledger): do NOT port. Record
   them in `.luau-fork-work/rung3-blocked.md` under a "deferred:
   runtime-inliner infrastructure" heading with this rationale: the new
   Inliner/ machinery is reachable only via flags our keep-OFF profile
   pins dark; it becomes a port obligation the day such a flag is enabled.
   Same for the Require Q-rows (untranslated subsystem).
5. No-op rows -> `.luau-fork-work/rung3-noop.md` after verifying each claim.
6. End: rung-level `NUXIE_PATCH.md` entries per modified crate
   ("Ported official Luau 0.727 delta (upstream 86d2a9dc..f1f121dc)"),
   committed as `luau-fork rung3: NUXIE_PATCH.md rung entries`; then one
   full `cargo test -p nuxie --features scripting`; fix forward only your
   own rows. Final message: rows ported / no-op / deferred, commits, gate
   results, surprises.

Do not touch: workspace `Cargo.toml`, `Cargo.lock`, `docs/`, `corpus.toml`,
crates outside `vendor/luaur-*`, `NUXIE_PROVENANCE.md`, or
`.luau-fork-work/` beyond the two report files.
