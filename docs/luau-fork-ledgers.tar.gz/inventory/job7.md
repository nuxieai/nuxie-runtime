# Rung inventory: official Luau 0.730 → 0.731

- Diff range: `e8ae48c4..f8ca77ac`
- Scoped files: `VM Compiler Ast Common Config Require Bytecode Inliner`
- Total default-context hunks: **258**
- Exact command:

```sh
git -C /Users/levi/dev/oss/luigi-rosso-luau diff e8ae48c4..f8ca77ac -- VM Compiler Ast Common Config Require Bytecode Inliner
```

I also split the diff with `--unified=0` as a cross-check; that yields 448 adjacent edit fragments, all reconciled back to the 258 binding hunks above.

`NONE-new` means the C symbol is introduced in this rung. `NONE-untranslated` means it existed at `e8ae48c4` but the 0.724 Rust fork has no translated twin.

## Ast, Bytecode, and Common

| c file | symbol | change summary | FFlag guard(s) + default path | rust twin path | class | risk notes |
|---|---|---|---|---|---|---|
| `Ast/include/Luau/Parser.h` | `Parser` | `classesWithinModule` changes from a name set to `AstName → AstStatClass*`; declares class lookup and member lvalue helpers. | `DebugLuauUserDefinedClasses`; default **OFF** | `vendor/luaur-ast-0.1.8/src/records/parser.rs` | ENGINE | Changes parser state layout and enables definition-location diagnostics. |
| `Ast/src/Parser.cpp` | `LuauTrackPrefixLocal` declaration | Declaration is only reordered relative to `LuauNoDuplicateBinaryPrefix`. | Existing flag; no default change | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Textual/no-behavior delta. |
| `Ast/src/Parser.cpp` | `LuauNoDuplicateBinaryPrefix` declaration | Declaration is only reordered. | Existing flag; no default change | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Textual/no-behavior delta. |
| `Ast/src/Parser.cpp` | `Parser::getMatchingClass` | New helper resolves a global expression to the module’s stored class declaration. | `DebugLuauUserDefinedClasses`; default **OFF** | NONE-new | ENGINE | Requires the new map-valued parser field. |
| `Ast/src/Parser.cpp` | `Parser::isExprLValue` | Moves the old static helper onto `Parser`; a global referring to a class is no longer assignable. | Guard ON rejects class globals; default **OFF** retains old behavior | `vendor/luaur-ast-0.1.8/src/functions/is_expr_l_value.rs` | ENGINE | Correct twin exists but changes from free-function semantics to parser-state-aware behavior. |
| `Ast/src/Parser.cpp` | `Parser::parseClassStat` | Class names are allocated without entering the normal local stack; completed declarations are stored in the class map. Duplicate recovery no longer restores locals. | `DebugLuauUserDefinedClasses`; default **OFF** | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_class_stat.rs` | ENGINE | Foundational class-hoisting semantic change. |
| `Ast/src/Parser.cpp` | `Parser::reportLValueError` | Adds a class-specific assignment diagnostic including the declaration line. | Guard ON; default **OFF** | `vendor/luaur-ast-0.1.8/src/methods/parser_report_l_value_error.rs` | ENGINE | Diagnostic depends on stored `AstStatClass*` remaining valid. |
| `Ast/src/Parser.cpp` | `Parser::parseAssignment` | Removes a blank line only. | Existing `LuauExportValueSyntax`; no behavior change | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_assignment.rs` | ENGINE | Formatting-only hunk. |
| `Bytecode/include/Luau/BytecodeBuilder.h`<br>`Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::addConstantVector*` | Renames the float API to `addConstantVectorf` and adds `addConstantVectord`; each stores and interns its native-width components. | None; selected by caller | Existing float twin: `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_add_constant_vector.rs`; double entry is NONE-new | ENGINE | API rename touches every compiler/graph caller; float and double constants must not alias. |
| `Bytecode/include/Luau/BytecodeBuilder.h` | `BytecodeBuilder::Constant` | Splits `Type_Vector/valueVector` into `Type_Vectorf/valueVectorf` and `Type_Vectord/valueVectord`. | None | `vendor/luaur-bytecode-0.1.8/src/records/constant.rs` | ENGINE | Representation and serialized tag selection change. |
| `Bytecode/include/Luau/BytecodeBuilder.h` | `BytecodeBuilder::ConstantKey` | Replaces one `extra` word with `extra1..extra3`, allowing four 64-bit vector components. | None | `vendor/luaur-bytecode-0.1.8/src/records/constant_key.rs` | ENGINE | Hash/equality must consume all new words. |
| `Bytecode/include/Luau/BytecodeBuilder.h` | `ConstantKey::operator==` | Compares `extra1`, `extra2`, and `extra3` in addition to type/value. | None | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_constant_key_operator_eq.rs` | ENGINE | Missing a field would silently deduplicate unequal constants. |
| `Bytecode/src/BytecodeBuilder.cpp` | `ConstantKeyHash::operator()` | Retains the 32-bit vector hash and adds a four-double hash, folding each 64-bit lane before spatial mixing. | None | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_constant_key_hash_operator_call.rs` | ENGINE | Must match equality for both widths, including signed zero behavior. |
| `Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::writeFunction` | Writes `Vectorf` with `LBC_CONSTANT_VECTOR`/four floats and `Vectord` with the new tag/four doubles. | None | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_write_function.rs` | ENGINE | Bytecode wire-format change; tag numbering is binding. |
| `Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::dumpConstant` | Separately formats float vectors at 9 digits and doubles at 17 digits; both omit zero `w`. | None | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_dump_constant.rs` | ENGINE | Observable dump/debug output changes. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcVmConstKind` | Splits `Vector` into `Vectorf` and `Vectord`. | None | `vendor/luaur-bytecode-0.1.8/src/enums/bc_vm_const_kind.rs` | ENGINE | All switches over this enum need both cases. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcVmConst` | Adds separate `[float;4]` and `[double;4]` payloads. | None | `vendor/luaur-bytecode-0.1.8/src/records/bc_vm_const.rs` | ENGINE | Rust union/layout must preserve both payload widths. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcVmConst::operator==` | Adds componentwise equality for both vector precisions. | None | NONE-untranslated | ENGINE | C equality existed at the rung base, but luaur has no translated equality implementation. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcFunction::eraseUse` | New reusable helper removes a user from an instruction or phi use-list. | None | NONE-new | ENGINE | Def-use consistency is an optimizer invariant. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcFunction::eraseOp` | New helper removes an instruction op from its owning block. | None | NONE-new | ENGINE | Does not itself erase operands’ use links. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcFunction::setOps` | New helper erases old use links, replaces operands, and records the new links. | None | NONE-new | ENGINE | Central fix for stale SCCP def-use edges. |
| `Bytecode/include/Luau/Sccp.h` | `Sccp::rewriteToLoad` | Delegates use removal to `BcFunction::eraseUse`. | None | NONE-untranslated | ENGINE | SCCP exists at the 0.730 C base but not in the 0.724 Rust fork. |
| `Bytecode/include/Luau/Sccp.h` | `Sccp::eraseOp` | Removes the local duplicate helper in favor of `BcFunction::eraseOp`. | None | NONE-untranslated | ENGINE | Port only after the earlier SCCP baseline exists. |
| `Bytecode/include/Luau/Sccp.h` | `Sccp::eraseUse` | Removes the local duplicate helper in favor of `BcFunction::eraseUse`. | None | NONE-untranslated | ENGINE | Same dependency. |
| `Bytecode/include/Luau/Sccp.h` | `Sccp::replaceUses` | Uses `func.eraseOp` for folded jump instructions. | None | NONE-untranslated | ENGINE | Incorrect erasure leaves invalid block contents. |
| `Bytecode/include/Luau/Sccp.h` | `Sccp::updateBlockUses` | Converts block-use vector size with `static_cast<uint32_t>`. | None | NONE-untranslated | ENGINE | Narrowing made explicit; no intended semantic change. |
| `Bytecode/include/Luau/Sccp.h` | `Sccp::eraseDeadProducer` | Uses `func.eraseOp`. | None | NONE-untranslated | ENGINE | Def-use consistency change. |
| `Bytecode/include/Luau/Sccp.h` | `Sccp::arithToK` | Every arithmetic rewrite now calls `func.setOps`; zero/one simplifications and K/RK rewrites preserve use lists. | None | NONE-untranslated | ENGINE | High optimizer risk: formerly clearing operands left stale uses. |
| `Bytecode/src/BytecodeGraph.cpp` | `fromFunctionBytecode` | Reads float-vector constants into `Vectorf` and recognizes `LBC_CONSTANT_VECTORD` as four doubles. | None | `vendor/luaur-bytecode-0.1.8/src/functions/from_function_bytecode.rs` | ENGINE | Loader must consume exactly 16 vs 32 payload bytes. |
| `Bytecode/src/BytecodeGraph.cpp` | `toFunctionBytecode` | Emits graph constants through the matching float/double builder entry point. | None | `vendor/luaur-bytecode-0.1.8/src/functions/to_function_bytecode_bytecode_graph.rs` | ENGINE | Round-trip precision and tag preservation required. |
| `Bytecode/src/Sccp.cpp` | `BcVmConstImpl::evaluate` | Division and floor-division by zero are now folded, producing IEEE infinities/NaNs rather than declining the fold. | None | NONE-untranslated | ENGINE | Observable constant-folding change; must match runtime arithmetic. |
| `Common/include/Luau/Bytecode.h` | `LuauBytecodeTag::LBC_CONSTANT_VECTORD` | Appends a new serialized constant tag immediately before `LBC_CONSTANT__COUNT`. | None | `vendor/luaur-common-0.1.8/src/enums/luau_bytecode_tag.rs` | ENGINE | Never reorder: numeric bytecode compatibility depends on append-only placement. |
| `Common/include/Luau/Common.h` | `LUAU_MAYBE_UNUSED` | New empty MSVC macro and `__attribute__((unused))` elsewhere. | None | NONE-new | OUT-OF-SCOPE | Compilation-warning annotation only. |
| `Common/include/Luau/DenseHash2.h` | `DenseHash2::hash` | Removes `LUAU_ASSERT(hashShift > 32)`, allowing the clipped/edge shift configuration. | None | NONE-untranslated | ENGINE | This is commit `5bc7f4b2` (“Clip this assert”); DenseHash2 is absent from luaur. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashSet2::DenseHashSet2` | Removes `explicit` from the bucket-count constructor. | None | NONE-untranslated | ENGINE | Source-level implicit-conversion change; used by SCCP containers. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashMap2::DenseHashMap2` | Removes `explicit` from the bucket-count constructor. | None | NONE-untranslated | ENGINE | Same SCCP dependency. |

## Compiler

| c file | symbol | change summary | FFlag guard(s) + default path | rust twin path | class | risk notes |
|---|---|---|---|---|---|---|
| `Compiler/include/Luau/Compiler.h` | `CompileOptions` | Adds `vectorPrecision`: `0` for float components, `1` for doubles. | None; normal zero-initialized default is float | `vendor/luaur-compiler-0.1.8/src/records/compile_options.rs` | RT-API | Field has no in-class initializer in C++; non-zero-initialized callers risk indeterminate behavior. `luaur-rt` builds this through `Default`. |
| `Compiler/include/luacode.h` | `lua_CompileOptions` | Adds the C ABI `vectorPrecision` field in the corresponding position. | None; zeroed default is float | `vendor/luaur-compiler-0.1.8/src/records/lua_compile_options.rs` | RT-API | ABI/layout change for embedders. |
| `Compiler/src/ConstantFolding.h` | `Compile::Constant` | Splits vector type and union payload into float/double variants. | None | `vendor/luaur-compiler-0.1.8/src/records/constant.rs` | ENGINE | Propagates through all compiler folding and callbacks. |
| `Compiler/src/BuiltinFolding.cpp` | `cvector → cvectorf` | Renames the float constructor and stops accepting doubles implicitly. | None | `vendor/luaur-compiler-0.1.8/src/functions/cvector.rs` | ENGINE | Existing twin should be renamed/adapted. |
| `Compiler/src/BuiltinFolding.cpp` | `cvectord` | New constructor for double-vector constants. | None | NONE-new | ENGINE | New constant representation. |
| `Compiler/src/BuiltinFolding.cpp` | `ctype` | Both vector widths report `"vector"`. | None | `vendor/luaur-compiler-0.1.8/src/functions/ctype.rs` | ENGINE | Exhaustiveness update. |
| `Compiler/src/BuiltinFolding.cpp` | `ctypeof` | Both vector widths remain runtime-dependent and fold to unknown. | None | `vendor/luaur-compiler-0.1.8/src/functions/ctypeof.rs` | ENGINE | Exhaustiveness update. |
| `Compiler/src/BuiltinFolding.cpp`<br>`Compiler/src/BuiltinFolding.h` | `foldBuiltin` | Adds `vectorDoublePrecision`; the vector constructor builtin folds to float or double components accordingly. | None; caller passes `vectorPrecision == 1` | `vendor/luaur-compiler-0.1.8/src/functions/fold_builtin.rs` | ENGINE | All call sites must pass the option consistently. |
| `Compiler/src/Compiler.cpp` | `LuauCompileIifeInline` | New fast flag controlling whether IIFEs bypass the normal inline cost ceiling. | New flag default **OFF** | NONE-new | ENGINE | Default build preserves the previous cost rejection. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileFunction` | Preallocates top-level class locals before compiling the function body. | `DebugLuauUserDefinedClasses`; default **OFF** | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_function.rs` | ENGINE | Enables forward class references and mutually referring classes. |
| `Compiler/src/Compiler.cpp` | `Compiler::tryCompileInlinedCall` | When the new flag is ON, IIFEs bypass `inlinedCost > threshold`; other functions remain cost-limited. | `LuauCompileIifeInline`; default **OFF** | `vendor/luaur-compiler-0.1.8/src/methods/compiler_try_compile_inlined_call.rs` | ENGINE | Can substantially increase generated bytecode when enabled. |
| `Compiler/src/Compiler.cpp` | `Compiler::costModelInlinedCall` | Passes vector precision into temporary constant folding used by the inline cost model. | None | `vendor/luaur-compiler-0.1.8/src/methods/compiler_cost_model_inlined_call.rs` | ENGINE | Cost model and emitted constants must see identical precision. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileInlinedCall` | Passes vector precision into the inlined body’s constant-folding pass. | None | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_inlined_call.rs` | ENGINE | Precision mismatch would make inlining alter semantics. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileClassDeclaration` | Uses a preallocated class local/register instead of allocating and pushing a local at the declaration. | `DebugLuauUserDefinedClasses`; default **OFF** | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_class_declaration.rs` | ENGINE | Depends on `preallocateHoistedClasses` running exactly once at top level. |
| `Compiler/src/Compiler.cpp` | `Compiler::isConstantVector` | Accepts both float and double constant variants. | None | `vendor/luaur-compiler-0.1.8/src/methods/compiler_is_constant_vector.rs` | ENGINE | Exhaustiveness update. |
| `Compiler/src/Compiler.cpp` | `Compiler::getConstantIndex` | Interns float and double vector constants through separate builder APIs. | None | `vendor/luaur-compiler-0.1.8/src/methods/compiler_get_constant_index.rs` | ENGINE | Must preserve component width. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileExprIndexName` | Suppresses GETIMPORT-chain optimization when the root name is a hoisted class local. | Class guard ON; default **OFF** | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_expr_index_name.rs` | ENGINE | Prevents class references from being compiled as globals/imports. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileExprGlobal` | Resolves class names to local registers or upvalues before normal global/import handling. | Class guard ON; default **OFF** | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_expr_global.rs` | ENGINE | Register/upvalue resolution must align with hoisting. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileExprConstant` | Emits separate float/double vector constants. | None | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_expr_constant.rs` | ENGINE | Constant-limit checks apply to both paths. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileLValue` | Produces a class-specific compile error if a class global is assigned. | Class guard ON; default **OFF** | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_l_value.rs` | ENGINE | Mirrors parser rejection and protects synthesized AST paths. |
| `Compiler/src/Compiler.cpp` | `Compiler::getExprLocalReg` | Treats class global expressions as references to their hoisted local register. | Class guard ON; default **OFF** | `vendor/luaur-compiler-0.1.8/src/methods/compiler_get_expr_local_reg.rs` | ENGINE | Used by optimization/register reuse paths. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileUnrolledFor` | Passes vector precision to every per-iteration refolding call. | None | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_unrolled_for.rs` | ENGINE | First and later iterations must use the same precision. |
| `Compiler/src/Compiler.cpp` | `Compiler::preallocateHoistedClasses` | New top-level scan allocates one register/local per class and initializes it to nil before statements execute. | Class guard ON; default **OFF** | NONE-new | ENGINE | Register pressure and local lifetime change for class-enabled builds. |
| `Compiler/src/Compiler.cpp` | `Compiler::classLocals` | New `AstName → AstLocal*` compiler map. | Class guard consumers; field exists unconditionally | `vendor/luaur-compiler-0.1.8/src/records/compiler.rs` | ENGINE | Must be populated before compilation. |
| `Compiler/src/Compiler.cpp` | `compileOrThrow` | Passes `classLocals` into value tracking and vector precision into root constant folding. | Class behavior default **OFF**; vector option normally float | `vendor/luaur-compiler-0.1.8/src/functions/compile_or_throw_compiler.rs` and `compile_or_throw_compiler_alt_b.rs` | ENGINE | Root orchestration point for both feature families. |
| `Compiler/src/Compiler.cpp` | `setCompileConstantVector` | Existing callback helper now creates `Type_Vectorf`. | None | `vendor/luaur-compiler-0.1.8/src/functions/set_compile_constant_vector.rs` | RT-API | Explicitly fixes existing callback results to float precision. |
| `Compiler/include/Luau/Compiler.h`<br>`Compiler/src/Compiler.cpp` | `setCompileConstantVectord` | New C++ callback helper creates `Type_Vectord` from four doubles. | None | NONE-new | RT-API | Required for precision-preserving library constant callbacks. |
| `Compiler/include/luacode.h`<br>`Compiler/src/lcode.cpp` | `luau_set_compile_constant_vectord` | New C ABI wrapper around `setCompileConstantVectord`. | None | NONE-new | RT-API | Public compiler API expansion. |
| `Compiler/src/ConstantFolding.cpp` | `constantsEqual` | Compares float vectors only with float and double only with double, lane by lane. | None | `vendor/luaur-compiler-0.1.8/src/functions/constants_equal.rs` | ENGINE | Mixed-precision vectors are deliberately unequal. |
| `Compiler/src/ConstantFolding.cpp` | `foldUnary` | Vector negation now has separate float and double implementations. | None | `vendor/luaur-compiler-0.1.8/src/functions/fold_unary.rs` | ENGINE | Must preserve lane precision and signed zeros. |
| `Compiler/src/ConstantFolding.cpp` | `foldBinary` | Adds separate float/double folding for add, subtract, multiply, divide, and floor-divide across vector/vector and scalar/vector combinations. | None | `vendor/luaur-compiler-0.1.8/src/functions/fold_binary.rs` | ENGINE | Large semantic surface; includes IEEE zero/NaN behavior and `w`-lane validity checks. |
| `Compiler/src/ConstantFolding.cpp` | `ConstantVisitor` | Stores the selected vector precision and accepts it in the constructor. | None | `vendor/luaur-compiler-0.1.8/src/records/constant_visitor.rs` and `methods/constant_visitor_constant_visitor.rs` | ENGINE | Every construction site must initialize the new field. |
| `Compiler/src/ConstantFolding.cpp` | `ConstantVisitor::visit(AstExprCall*)` | Passes vector precision to builtin folding. | None | `vendor/luaur-compiler-0.1.8/src/methods/constant_visitor_visit_constant_folding_alt_b.rs` | ENGINE | Controls compile-time vector constructor width. |
| `Compiler/src/ConstantFolding.cpp` | `ConstantVisitor::visit(AstExprIndexName*)` | Handles component extraction for both widths and converts callback-returned vectors to the configured precision. | None | `vendor/luaur-compiler-0.1.8/src/methods/constant_visitor_visit_constant_folding_alt_b.rs` | ENGINE | Callback conversion can narrow doubles or widen already-rounded floats. |
| `Compiler/src/ConstantFolding.cpp`<br>`Compiler/src/ConstantFolding.h` | `foldConstants` | Adds and forwards `vectorDoublePrecision`. | None | `vendor/luaur-compiler-0.1.8/src/functions/fold_constants.rs` | ENGINE | Signature change reaches all folding sites. |
| `Compiler/src/ValueTracking.cpp` | `ValueVisitor` | Stores a reference to the class-local map and accepts it in the constructor. | Class behavior default **OFF** | `vendor/luaur-compiler-0.1.8/src/records/value_visitor.rs` and `methods/value_visitor_value_visitor.rs` | ENGINE | Visitor lifetime now includes a third map. |
| `Compiler/src/ValueTracking.cpp` | `ValueVisitor::visit(AstStatClass*)` | Records each class name/local and marks its variable written. | Guard ON; default **OFF** | NONE-new | ENGINE | Prevents invalid constant/immutability assumptions for class locals. |
| `Compiler/src/ValueTracking.cpp`<br>`Compiler/src/ValueTracking.h` | `trackValues` | Adds the class-local map parameter and forwards it to `ValueVisitor`. | Class behavior default **OFF** | `vendor/luaur-compiler-0.1.8/src/functions/track_values.rs` | ENGINE | Signature change reaches `compileOrThrow`. |

## Inliner and Require

| c file | symbol | change summary | FFlag guard(s) + default path | rust twin path | class | risk notes |
|---|---|---|---|---|---|---|
| `Inliner/src/JitInliner.cpp` | `LuauBytecodeFold` | New flag for running SCCP after JIT bytecode inlining. | New flag default **OFF** | NONE-new | OUT-OF-SCOPE | JIT/Inliner component is not vendored. |
| `Inliner/src/JitInliner.cpp` | `createInlinedProto` | Makes vector-size conversions explicit when assigning graph/code sizes to integer proto fields. | None | NONE-untranslated | OUT-OF-SCOPE | JIT-only narrowing cleanup. |
| `Inliner/src/JitInliner.cpp` | `hasFoldableConstants` | New scan detects load-constant/load-immediate instructions. | None | NONE-new | OUT-OF-SCOPE | Used to avoid unnecessary SCCP setup. |
| `Inliner/src/JitInliner.cpp` | `onInlineFunction` | Optionally constructs a runtime TValue evaluator and runs SCCP after inlining. | `LuauBytecodeFold`; default **OFF** | NONE-untranslated | OUT-OF-SCOPE | Depends on BytecodeGraph/SCCP and new evaluator lifetime. |
| `Inliner/src/RuntimeBytecodeBuilder.h` | `RuntimeBytecodeBuilder::constTypeToTT` | Recognizes both vector constant widths as `LUA_TVECTOR`. | None | NONE-untranslated | OUT-OF-SCOPE | JIT runtime builder absent from luaur. |
| `Inliner/src/RuntimeBytecodeBuilder.h` | `RuntimeBytecodeBuilder::dumpConstant` | Reads vectors through `LUA_VECTOR_TYPE`. | `LUA_VECTOR_DOUBLE`; default float | NONE-untranslated | OUT-OF-SCOPE | JIT-only. |
| `Inliner/src/RuntimeBytecodeBuilder.h` | `RuntimeBytecodeBuilder::emitCode` | Adds explicit integer conversions for `log2` and instruction count arithmetic. | None | NONE-untranslated | OUT-OF-SCOPE | JIT-only narrowing cleanup. |
| `Inliner/src/TValueVmConstImpl.h` | `kDefaultBackingSize` | New scratch TValue chunk size constant, value 8. | None | NONE-new | OUT-OF-SCOPE | JIT-only scratch allocator. |
| `Inliner/src/TValueVmConstImpl.h` | `TempTValueBacking` | New non-copyable scratch-TValue chunk owner. | None | NONE-new | OUT-OF-SCOPE | Allocates through VM memory APIs and frees all chunks. |
| `Inliner/src/TValueVmConstImpl.h` | `TempTValueBacking::TempTValueBacking` | Constructor immediately allocates the first chunk. | None | NONE-new | OUT-OF-SCOPE | Can throw on allocation. |
| `Inliner/src/TValueVmConstImpl.h` | `TempTValueBacking::~TempTValueBacking` | Frees every scratch chunk. | None | NONE-new | OUT-OF-SCOPE | Uses fixed `chunkSize` for all chunks. |
| `Inliner/src/TValueVmConstImpl.h` | `TempTValueBacking::nextTValue` | Returns the next slot, allocating another chunk when full. | None | NONE-new | OUT-OF-SCOPE | Returned pointers must remain stable. |
| `Inliner/src/TValueVmConstImpl.h` | `TempTValueBacking::allocateChunk` | Allocates a TValue array in the active memory category. | None | NONE-new | OUT-OF-SCOPE | JIT-only. |
| `Inliner/src/TValueVmConstImpl.h` | `TValueVmConstImpl` | New `VmConstOps` implementation backed by runtime `TValue*` constants. | Used only under `LuauBytecodeFold`; default **OFF** | NONE-new | OUT-OF-SCOPE | Ties Bytecode SCCP to VM TValue semantics. |
| `Inliner/src/TValueVmConstImpl.h` | `TValueVmConstImpl::TValueVmConstImpl` | Stores graph reference and scratch backing. | Same | NONE-new | OUT-OF-SCOPE | Backing must outlive SCCP and serialization. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::evaluate` | Folds numeric/vector arithmetic for ADD/SUB/MUL/DIV/IDIV/MOD/POW into runtime TValues. | Same | NONE-new | OUT-OF-SCOPE | Uses runtime float-vector semantics in this commit’s implementation. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::falsey` | Evaluates VM constants and boolean immediates for truthiness. | Same | NONE-new | OUT-OF-SCOPE | JIT-only. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::cmp` overloads | Compares numbers, booleans, strings, and integer/boolean immediates. | Same | NONE-new | OUT-OF-SCOPE | String comparison is lexical by bytes/length. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::makeNil` | Allocates and returns a nil runtime constant. | Same | NONE-new | OUT-OF-SCOPE | Consumes scratch backing. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::makeImm` overloads | Constructs boolean and integer immediates. | Same | NONE-new | OUT-OF-SCOPE | JIT-only. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::asImm` | Returns the graph immediate reference for an op. | Same | NONE-new | OUT-OF-SCOPE | JIT-only. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::isOrderable` | Treats only numbers and strings as orderable. | Same | NONE-new | OUT-OF-SCOPE | Must match VM comparison semantics. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::kindEquals` | Compares TValue tags. | Same | NONE-new | OUT-OF-SCOPE | JIT-only. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::eq` overloads | Adds equality for VM constants, boolean/int immediates, numbers, and strings. | Same | NONE-new | OUT-OF-SCOPE | Returns unknown for unsupported combinations. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::isArithmeticConstant` | Accepts numeric TValues only. | Same | NONE-new | OUT-OF-SCOPE | Vectors are not considered K-rewrite arithmetic constants here. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::asNumber` | Extracts the numeric TValue payload. | Same | NONE-new | OUT-OF-SCOPE | Caller must first establish numeric type. |
| `Require/src/RequireNavigator.cpp` | `LuauRequireAliasOverrideOrderFix` | Removed. Target behavior now always resets to the requirer before alias override resolution. | Removed flag default was **OFF**; target effectively makes its former ON ordering unconditional | NONE-untranslated | OUT-OF-SCOPE | Standalone Require component is not vendored. |
| `Require/src/RequireNavigator.cpp` | `LuauRequireResolveAliasNullCheck` | Removed. Null-check/error behavior is now unconditional. | Removed flag default was **OFF**; target effectively executes former ON behavior | NONE-untranslated | OUT-OF-SCOPE | Eliminates an unchecked optional dereference. |
| `Require/src/RequireNavigator.cpp` | `LuauSelfIsSelfAndAlwaysSelf` | New dynamic flag making `@self` immediate and unoverrideable. | New DFFlag default **OFF** | NONE-new | OUT-OF-SCOPE | Default path retains later `@self` handling. |
| `Require/src/RequireNavigator.cpp` | `Navigator::navigateImpl` | Always resets to requirer before overrides; ON-path handles `@self` immediately, OFF-path retains legacy fallback position. | `LuauSelfIsSelfAndAlwaysSelf`; default **OFF** | NONE-untranslated | OUT-OF-SCOPE | Alias precedence changes unconditionally due removal of the old ordering flag. |
| `Require/src/RequireNavigator.cpp` | `Navigator::navigateToAndPopulateConfig` | Always checks `getAlias` for null and returns a resolution error. | Former null-check flag removed; fixed path always active | NONE-untranslated | OUT-OF-SCOPE | Behavior changes even with all target flags at defaults. |

## VM and embedder API

| c file | symbol | change summary | FFlag guard(s) + default path | rust twin path | class | risk notes |
|---|---|---|---|---|---|---|
| `VM/include/lua.h` | `lua_Type` | When vectors are float they remain inline value types; when double, `LUA_TVECTOR` moves below GC types and becomes collectable. | `LUA_VECTOR_DOUBLE`; default `0` selects old float placement | `vendor/luaur-vm-0.1.8/src/enums/lua_type.rs` | RT-API | Type-tag numbering/layout changes in double builds. |
| `VM/include/luaconf.h` | `LUA_VECTOR_DOUBLE` / `LUA_VECTOR_TYPE` | Adds precision configuration; defaults to float and aliases the component type to float or double. | Compile-time default **float** | NONE-new | RT-API | Cross-cutting ABI and TValue representation switch. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_tovector` | Return type changes from `const float*` to `const LUA_VECTOR_TYPE*`. | Default float | `vendor/luaur-vm-0.1.8/src/functions/lua_tovector.rs` | RT-API | Public signature changes in double builds. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_pushvector` overloads | Accept `LUA_VECTOR_TYPE`; double builds perform GC check/thread barrier before allocating a vector object. | Default float keeps inline TValue path | `vendor/luaur-vm-0.1.8/src/functions/lua_pushvector_lapi.rs` and `lua_pushvector_lapi_alt_b.rs` | RT-API | `luaur-rt` directly wraps the current `f32` functions and must track any precision exposure. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `LUA_GCISPAUSED` / `lua_gc` | Adds a GC operation returning whether the collector state is paused. | None | `vendor/luaur-vm-0.1.8/src/enums/lua_gc_op.rs`; `functions/lua_gc.rs` | RT-API | Public enum/API behavior expansion. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_CategoryName` / `lua_memorydump` | New category-name callback and public JSON heap-dump wrapper around `luaC_dump`. | None | NONE-new; lower-level twin exists at `vendor/luaur-vm-0.1.8/src/functions/lua_c_dump.rs` | RT-API | Public API is new even though the internal dumper already exists. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_allocationrate` | New wrapper returning `luaC_allocationrate`, including `-1` when unavailable. | None | NONE-new; lower-level twin exists at `vendor/luaur-vm-0.1.8/src/functions/lua_c_allocationrate.rs` | RT-API | Public API expansion. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_setpointerencodekey` | New API installs four pointer-encoding keys while forcing the first even and second odd. | None | NONE-new | RT-API | Alters pointer-obfuscation output globally. |
| `VM/include/lua.h` | `lua_UserdataMark`, `lua_EmbedderMark`, `lua_EmbedderGc` | New callback types for cross-heap fixed-point GC marking. | APIs require `LuauGcTraceUdata` ON; default **OFF** | NONE-new | RT-API | Callbacks execute during GC and must be non-reentrant. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_setuserdatamark` | Registers a native mark callback per userdata tag. | Asserts flag ON; default **OFF** | NONE-new | RT-API | Invalid to call in a default build. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_setembeddergc` | Registers the embedder GC callback. | Asserts flag ON; default **OFF** | NONE-new | RT-API | Callback participates in atomic fixed-point marking. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_weakref` | Allocates a ref in the weak-value registry. | Asserts flag ON; default **OFF** | NONE-new | RT-API | Does not keep the referenced object alive by itself. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_weakunref` | Releases a weak-registry reference and returns `LUA_NOREF`. | Asserts flag ON; default **OFF** | NONE-new | RT-API | Uses the weak registry’s independent free list. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_getweakref` | Pushes the current weak reference value, returning its type. | Asserts flag ON; default **OFF** | NONE-new | RT-API | Collected entries produce nil. |
| `VM/src/lapi.cpp` | `registryref` | New shared helper implements strong or weak registry allocation through a passed table/free-list. | Asserts `LuauGcTraceUdata` ON | NONE-new | ENGINE | Only called by the ref APIs’ ON paths. |
| `VM/src/lapi.cpp` | `registryunref` | New shared helper releases a slot through a passed table/free-list. | Asserts flag ON | NONE-new | ENGINE | Registry free-list integrity is critical. |
| `VM/src/lapi.cpp` | `lua_ref` | Under the new flag, delegates to `registryref`; OFF path retains the prior implementation. | Default **OFF** executes old path | `vendor/luaur-vm-0.1.8/src/functions/lua_ref.rs` | RT-API | `luaur-rt` uses this for owned handles. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_unref` | Return type changes from `void` to `int`; returns `LUA_NOREF` and optionally uses `registryunref`. | Default **OFF** retains old freeing algorithm | `vendor/luaur-vm-0.1.8/src/functions/lua_unref.rs` | RT-API | ABI/signature change; `luaur-rt` currently ignores the return value. |
| `VM/include/lua.h`<br>`VM/src/ldebug.cpp` | `lua_callhook` | New public wrapper invokes `luau_callhook` for a thread in break/yield state. | None | NONE-new; internal twin exists at `vendor/luaur-vm-0.1.8/src/functions/luau_callhook.rs` | RT-API | Requires a non-base call frame and non-null hook. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_hascustomexecution` | New wrapper for `luaG_hasnative(level)`. | None | NONE-new | RT-API | Debug/custom execution API expansion. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_incustomexecution` | New wrapper for `luaG_isnative(level)`. | None | NONE-new | RT-API | Distinguishes configured from currently active custom execution. |
| `VM/include/lua.h`<br>`VM/src/ldebug.cpp` | `lua_atbreakpoint` | New API returns whether the current thread is stopped at a breakpoint. | None | NONE-new | RT-API | Intended for debug callbacks. |
| `VM/include/lua.h` | coverage/counter declarations | Moves `lua_Coverage`, counter callback typedefs, `lua_getcoverage`, and `lua_getcounters` below the complete `lua_Debug` definition. | None | Existing twins: `functions/lua_getcoverage.rs`, `functions/lua_getcounters.rs`, and corresponding type aliases | RT-API | Declaration-order-only; no ABI or behavior change. |
| `VM/include/lua.h` | `lua_Debug` | Corrects the userdata comment from `luau_callhook` to `lua_callhook`. | None | `vendor/luaur-vm-0.1.8/src/records/lua_debug.rs` | RT-API | Documentation-only. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_userdatadirectfield_setnumber` | In double-vector builds, unwraps `DirectFieldResult` to find the destination slot. | `LuauDirectFieldGet` existing default **OFF**; representation selected by vector macro | `vendor/luaur-vm-0.1.8/src/functions/lua_userdatadirectfield_setnumber.rs` | RT-API | Callback result ABI differs in double builds. |
| `VM/include/lua.h`<br>`VM/src/lapi.cpp` | `lua_userdatadirectfield_setvector` | Uses `LUA_VECTOR_TYPE`; double builds allocate through the state in `DirectFieldResult`. | Same | `functions/lua_userdatadirectfield_setvector_lapi.rs` and `_alt_b.rs` | RT-API | Most sensitive direct-field ABI change. |
| `VM/src/lapi.cpp` | `lua_userdatadirectfield_setboolean` | Unwraps `DirectFieldResult` in double builds. | Same | `vendor/luaur-vm-0.1.8/src/functions/lua_userdatadirectfield_setboolean.rs` | RT-API | Callback result pointer is no longer always a `TValue*`. |
| `VM/src/lapi.cpp` | `lua_userdatadirectfield_setinteger64` | Same destination unwrapping. | Same | `vendor/luaur-vm-0.1.8/src/functions/lua_userdatadirectfield_setinteger_64.rs` | RT-API | Same ABI concern. |
| `VM/src/lapi.cpp` | `lua_userdatadirectfield_setnil` | Same destination unwrapping. | Same | `vendor/luaur-vm-0.1.8/src/functions/lua_userdatadirectfield_setnil.rs` | RT-API | Same ABI concern. |
| `VM/include/lualib.h`<br>`VM/src/laux.cpp` | `luaL_checkvector` | Returns `const LUA_VECTOR_TYPE*`. | Default float | `vendor/luaur-vm-0.1.8/src/functions/lua_l_checkvector.rs` | RT-API | Public auxiliary-library signature changes in double builds. |
| `VM/include/lualib.h`<br>`VM/src/laux.cpp` | `luaL_optvector` | Uses `LUA_VECTOR_TYPE` for return/default pointers. | Default float | `vendor/luaur-vm-0.1.8/src/functions/lua_l_optvector.rs` | RT-API | Same ABI concern. |
| `VM/src/laux.cpp` | `luaL_tolstring` | Reads vector components through `LUA_VECTOR_TYPE`. | Default float | `vendor/luaur-vm-0.1.8/src/functions/lua_l_tolstring.rs` | RT-API | Double builds retain `%g` conversion but source precision changes. |

## VM internals

| c file | symbol | change summary | FFlag guard(s) + default path | rust twin path | class | risk notes |
|---|---|---|---|---|---|---|
| `VM/src/ldo.cpp` | `LuauXpcallFixMessageYieldPath` | New flag controlling `nCcalls/baseCcalls` restoration around yieldable protected-call error handlers. | New flag default **OFF** | NONE-new | ENGINE | Dark by default. |
| `VM/src/ldo.cpp` | `resume_handle` | ON path delays/restores `nCcalls` for the continuation instead of immediately after the error function. | New flag OFF by default; also depends on `LuauCustomYieldablePcalls` | `vendor/luaur-vm-0.1.8/src/functions/resume_handle.rs` | ENGINE | Incorrect call-depth restoration can corrupt later resume/error behavior. |
| `VM/src/ldo.cpp` | `resume_finish` | With both flags ON, restores `baseCcalls` to the saved baseline without overwriting current `nCcalls`. | Both existing/new flags default **OFF** | `vendor/luaur-vm-0.1.8/src/functions/resume_finish.rs` | ENGINE | Paired with `resume_handle`; port atomically. |
| `VM/src/lgc.cpp` | `LuauGcTraceUdata` | New versioned flag enabling cross-heap userdata tracing and weak references. | New flag default **OFF**, version 2 | NONE-new | ENGINE | Large dark GC feature. |
| `VM/src/lvmexecute.cpp` | `LuauBackedgeHeapCheck` | New versioned flag enabling GC checks at loop/jump backedges. | New flag default **OFF**, version 2 | NONE-new | ENGINE | Double-vector assist scaling is partly forced even with flag OFF. |
| `VM/src/lgc.cpp` | `stringmark` | Marked strings now explicitly become black, not merely non-white. | None | `vendor/luaur-vm-0.1.8/src/macros/stringmark.rs` | ENGINE | GC color invariant change. |
| `VM/src/lgc.cpp` | `reallymarkobject` | Blacks strings explicitly; under GC tracing invokes userdata native mark callbacks; treats GC vectors as black leaf objects. | Userdata callback path default **OFF**; vector case compiled only for double vectors | `vendor/luaur-vm-0.1.8/src/functions/reallymarkobject.rs` | ENGINE | Central marking switch; missing vector case can corrupt GC. |
| `VM/src/lgc.cpp` | `embeddermarkref` | New callback marks a white collectable object referenced from the weak registry. | Asserts `LuauGcTraceUdata` ON | NONE-new | ENGINE | Drives the cross-heap fixed-point. |
| `VM/src/lgc.cpp` | `freeobj` | Frees `LUA_TVECTOR` through `luaVec_freevector`. | Double-vector builds | `vendor/luaur-vm-0.1.8/src/functions/freeobj.rs` | ENGINE | Object-size/page allocator must match allocation. |
| `VM/src/lgc.cpp` | `markroot` | Marks the weak registry and resets embedder GC state at cycle start. | GC trace flag; default **OFF** | `vendor/luaur-vm-0.1.8/src/functions/markroot.rs` | ENGINE | Weak registry must itself remain reachable. |
| `VM/src/lgc.cpp` | `atomic` | Repeatedly asks the embedder for refs and propagates gray objects until reaching a fixed point; records embedder timing. | GC trace flag; default **OFF** | `vendor/luaur-vm-0.1.8/src/functions/atomic.rs` | ENGINE | Callback/mark loop termination and reentrancy are high risk. |
| `VM/src/lgc.cpp` | `luaC_step` | Changes work limit to `size_t`; assist steps grow to cover allocation debt when backedge checks are ON or vectors are double. | Default flag OFF and vector-double `0`: old fixed limit | `vendor/luaur-vm-0.1.8/src/functions/lua_c_step.rs` | ENGINE | Forced behavior change in double-vector builds. |
| `VM/src/lgc.h` | `luaC_initobj` | Removes a stale declaration with no implementation. | None | NONE-untranslated | ENGINE | No runtime body existed at the base. |
| `VM/src/lgcdebug.cpp` | `validateobj` | Accepts GC vector objects as leaf objects. | Double-vector builds | `vendor/luaur-vm-0.1.8/src/functions/validateobj.rs` | ENGINE | Debug validation otherwise rejects valid vectors. |
| `VM/src/lgcdebug.cpp` | `dumpobj` | Treats outlined vector data as constant-size and emits no child data. | Double-vector builds | `vendor/luaur-vm-0.1.8/src/functions/dumpobj.rs` | ENGINE | Heap-dump accounting change. |
| `VM/src/lgcdebug.cpp` | `enumobj` | Enumerates vectors as `sizeof(LuauVector)` leaf nodes. | Double-vector builds | `vendor/luaur-vm-0.1.8/src/functions/enumobj.rs` | ENGINE | Required by heap enumeration/memory dump. |
| `VM/src/lmem.cpp` | `newblock` | Marks the allocator helper `LUAU_FORCEINLINE`. | None | `vendor/luaur-vm-0.1.8/src/functions/newblock.rs` | ENGINE | Performance/codegen annotation only. |
| `VM/src/lmem.cpp` | `freeblock` | Marks the allocator helper `LUAU_FORCEINLINE`. | None | `vendor/luaur-vm-0.1.8/src/functions/freeblock.rs` | ENGINE | Performance/codegen annotation only. |
| `VM/src/lmem.cpp`<br>`VM/src/lmem.h` | `luaM_newgcofixed_` | New fixed-size GCO allocator using size classes and exact accounting. | Used by double-vector allocation | NONE-new | ENGINE | Does not call the general allocator path; size-class assumptions are binding. |
| `VM/src/lmem.h` | `luaM_newgcofixed` macro | Casted public macro wrapper for `luaM_newgcofixed_`. | Same | NONE-new | ENGINE | New allocation primitive. |
| `VM/src/lmem.cpp`<br>`VM/src/lmem.h` | `luaM_freegcofixed_` | New fixed-size GCO free path, clears tag, returns block to its page, and decrements accounting. | Used by double-vector collection | NONE-new | ENGINE | Must use the original allocation size/category/page. |
| `VM/src/lmem.h` | `luaM_freegcofixed` macro | Converts an object to `GCObject*` and calls the fixed free path. | Same | NONE-new | ENGINE | New freeing primitive. |
| `VM/src/lnumutils.h` | `luai_veceq` overloads | Adds double-vector equality alongside existing float equality. | Selected by `LUA_VECTOR_TYPE`; default float | `vendor/luaur-vm-0.1.8/src/functions/luai_veceq.rs` | ENGINE | Rust cannot overload directly; implement precision-configured equivalent. |
| `VM/src/lnumutils.h` | `luai_vecisnan` overloads | Adds double-vector NaN detection. | Default float | `vendor/luaur-vm-0.1.8/src/functions/luai_vecisnan.rs` | ENGINE | Must respect three- vs four-wide configuration. |
| `VM/src/lnumutils.h` | `luaui_signf → luai_signf`, `luai_signd` | Corrects float helper spelling and adds double sign. | Precision-selected | Existing float twin: `vendor/luaur-vm-0.1.8/src/functions/luaui_signf.rs`; double helper NONE-new | ENGINE | Rename reaches builtin/vector-library callers. |
| `VM/src/lnumutils.h` | `luaui_clampf → luai_clampf`, `luai_clampd` | Corrects float spelling and adds double clamp. | Precision-selected | Existing float twin: `vendor/luaur-vm-0.1.8/src/functions/luaui_clampf.rs`; double helper NONE-new | ENGINE | Rename plus overload. |
| `VM/src/lnumutils.h` | `luai_lerpf`, `luai_lerpd` | Makes float constants explicitly float and adds double lerp. | Precision-selected | `vendor/luaur-vm-0.1.8/src/functions/luai_lerpf.rs`; double helper NONE-new | ENGINE | Preserves exact `t == 1` endpoint behavior. |
| `VM/src/lnumutils.h` | precision-dispatch numeric macros | Adds `luai_fabs`, `luai_sqrt`, `luai_floor`, `luai_ceil`, `luai_sign`, `luai_clamp`, and `luai_lerp`. | `LUA_VECTOR_DOUBLE`; default float branch | NONE-new | ENGINE | All vector fast paths/libraries depend on these aliases. |
| `VM/src/lobject.h` | `condvector4` | New compile-time selector for four- vs three-wide expressions. | `LUA_VECTOR_SIZE`; default 3 | NONE-new | ENGINE | Avoids accessing absent `w` storage. |
| `VM/src/lobject.h` | `condvectordouble` | New compile-time selector for double- vs float-vector expressions. | `LUA_VECTOR_DOUBLE`; default float | NONE-new | ENGINE | Used inside representation macros. |
| `VM/src/lobject.h` | `vvalue` | Reads inline float lanes or outlined `GCObject::vec.v` depending on precision. | Default inline float | `vendor/luaur-vm-0.1.8/src/macros/vvalue.rs` | ENGINE | Fundamental representation switch. |
| `VM/src/lobject.h` | `setvvalue` | Signature gains `lua_State*`; double builds allocate `LuauVector`, float builds store inline and cast lanes. | Default inline float | `vendor/luaur-vm-0.1.8/src/macros/setvvalue.rs` | ENGINE | Every call site changes; double path may allocate/fail. |
| `VM/src/lobject.h` | `DirectFieldResult` | New wrapper containing state and destination slot for direct-field callbacks. | Needed only when vectors are double | NONE-new | ENGINE | Changes callback result convention. |
| `VM/src/lobject.h` | `LuauVector` | New GC object with common header and configurable-width component array. | Used when `LUA_VECTOR_DOUBLE == 1` | NONE-new | ENGINE | Object layout, tag, allocation, and collection must land together. |
| `VM/src/lstate.cpp` | `weakenvalues` | New helper assigns a weak-value metatable to the weak registry. | Asserts GC trace flag ON | NONE-new | ENGINE | Metatable/table barriers and initialization ordering matter. |
| `VM/src/lstate.cpp` | `f_luaopen` | Creates the weak registry when GC userdata tracing is enabled. | Default **OFF** | `vendor/luaur-vm-0.1.8/src/functions/f_luaopen.rs` | ENGINE | Must occur after `luaT_init` and before normal use. |
| `VM/src/lstate.cpp` | `lua_newstate` | Initializes weak-registry/embedder fields and per-tag userdata mark callbacks. | Fields initialized regardless; table created only with flag ON | `vendor/luaur-vm-0.1.8/src/functions/lua_newstate.rs` | ENGINE | New global-state fields must never be left uninitialized. |
| `VM/src/lstate.h` | `GCCycleMetrics` | Adds `atomictimeembedder`. | Recorded only with GC metrics and flag ON | `vendor/luaur-vm-0.1.8/src/records/gc_cycle_metrics.rs` | ENGINE | Metrics layout/output change. |
| `VM/src/lstate.h` | `global_State` | Adds userdata mark callbacks, weak registry/free-list, and embedder GC callback. | Feature use default **OFF** | `vendor/luaur-vm-0.1.8/src/records/global_state.rs` | ENGINE | Central state-layout change. |
| `VM/src/lstate.h` | `GCObject` / `gco2vec` | Adds the `LuauVector` union arm and conversion macro. | Double-vector representation | `vendor/luaur-vm-0.1.8/src/records/gc_object.rs`; `gco2vec` is NONE-new | ENGINE | Must remain layout-compatible with common GC header. |
| `VM/src/ltable.cpp` | `hashvec` overloads | Marks float hashing maybe-unused and adds double hashing with signed-zero normalization and 64-bit lane folding. | Precision-selected; default float | `vendor/luaur-vm-0.1.8/src/functions/hashvec.rs` | ENGINE | Equality/hash consistency is required for vector table keys. |
| `VM/src/ltm.cpp` | `luaT_typenames` | Places `"vector"` at the type-tag position selected by float vs GC double representation. | Default float | NONE-untranslated | ENGINE | luaur does not translate this C global array directly. |
| `VM/src/lvector.cpp` | `luaVec_newvector` | New fixed-size GC vector allocator/initializer. | Double-vector path | NONE-new | ENGINE | Uses `luaC_init` and active memory category. |
| `VM/src/lvector.cpp` | `luaVec_freevector` | New fixed-size vector free helper. | Double-vector path | NONE-new | ENGINE | Allocation/free symmetry required. |
| `VM/src/lvector.h` | `sizevector` | New `sizeof(LuauVector)` macro. | Double-vector path | NONE-new | ENGINE | Used for both allocation and freeing. |
| `VM/src/lvm.h`<br>`VM/src/lvmutils.cpp` | `luaV_tovector` | Returns `const LUA_VECTOR_TYPE*`. | Default float | `vendor/luaur-vm-0.1.8/src/functions/lua_v_tovector.rs` | ENGINE | Internal signature change. |
| `VM/src/lvmload.cpp` | `loadsafe` | Uses state-aware `setvvalue` for float tags and loads the new double-vector tag. | Runtime representation selected by vector macro | `vendor/luaur-vm-0.1.8/src/functions/loadsafe.rs` | ENGINE | Accepts both serialized precisions and converts into configured runtime representation. |
| `VM/src/lvmutils.cpp` | `luaV_doarithimpl` | Converts all vector arithmetic to `LUA_VECTOR_TYPE` and state-aware allocation, including vector/scalar floor division. | Default float | `vendor/luaur-vm-0.1.8/src/functions/lua_v_doarithimpl.rs` | ENGINE | Slow-path arithmetic must exactly match interpreter fast paths. |

### VM builtin vector fast paths

| c file | symbol | change summary | FFlag guard(s) + default path | rust twin path | class | risk notes |
|---|---|---|---|---|---|---|
| `VM/src/lbuiltins.cpp` | `luauF_vector` | Constructs `LUA_VECTOR_TYPE` lanes and calls state-aware `setvvalue`. | Default float | `vendor/luaur-vm-0.1.8/src/functions/luau_f_vector.rs` | ENGINE | Double path allocates. |
| `VM/src/lbuiltins.cpp` | `luauF_vectormagnitude` | Uses configurable lanes and precision-dispatched square root. | Default float | `functions/luau_f_vectormagnitude.rs` | ENGINE | Numeric precision changes in double builds. |
| `VM/src/lbuiltins.cpp` | `luauF_vectornormalize` | Uses configurable inverse magnitude and state-aware result storage. | Default float | `functions/luau_f_vectornormalize.rs` | ENGINE | Zero-vector NaN behavior must match. |
| `VM/src/lbuiltins.cpp` | `luauF_vectorcross` | Uses configurable lane pointers and state-aware result storage. | Default float | `functions/luau_f_vectorcross.rs` | ENGINE | `w` remains zero. |
| `VM/src/lbuiltins.cpp` | `luauF_vectordot` | Reads configurable lane type. | Default float | `functions/luau_f_vectordot.rs` | ENGINE | Four-wide build includes `w`. |
| `VM/src/lbuiltins.cpp` | `luauF_vectorfloor` | Uses precision-dispatched floor and state-aware vector storage. | Default float | `functions/luau_f_vectorfloor.rs` | ENGINE | Double build preserves more input precision. |
| `VM/src/lbuiltins.cpp` | `luauF_vectorceil` | Uses precision-dispatched ceil and state-aware storage. | Default float | `functions/luau_f_vectorceil.rs` | ENGINE | Same. |
| `VM/src/lbuiltins.cpp` | `luauF_vectorabs` | Uses precision-dispatched absolute value and state-aware storage. | Default float | `functions/luau_f_vectorabs.rs` | ENGINE | Same. |
| `VM/src/lbuiltins.cpp` | `luauF_vectorsign` | Uses renamed/precision-dispatched sign helper. | Default float | `functions/luau_f_vectorsign.rs` | ENGINE | Helper rename required. |
| `VM/src/lbuiltins.cpp` | `luauF_vectorclamp` | Uses configurable lanes, precision-dispatched clamp, and state-aware storage. | Default float | `functions/luau_f_vectorclamp.rs` | ENGINE | Retains per-lane min/max validation. |
| `VM/src/lbuiltins.cpp` | `luauF_vectormin` | Uses `LUA_VECTOR_TYPE` for inputs/scratch/result. | Default float | `functions/luau_f_vectormin.rs` | ENGINE | Variadic path must preserve configured precision. |
| `VM/src/lbuiltins.cpp` | `luauF_vectormax` | Uses `LUA_VECTOR_TYPE` for inputs/scratch/result. | Default float | `functions/luau_f_vectormax.rs` | ENGINE | Same. |
| `VM/src/lbuiltins.cpp` | `luauF_vectorlerp` | Converts `t` to configured precision and calls precision-dispatched lerp. | Default float | `functions/luau_f_vectorlerp.rs` | ENGINE | Double build changes interpolation rounding. |

Paths in this subsection are under `vendor/luaur-vm-0.1.8/src/`.

### Vector library

| c file | symbol | change summary | FFlag guard(s) + default path | rust twin path | class | risk notes |
|---|---|---|---|---|---|---|
| `VM/src/lveclib.cpp` | `vector_create` | Casts constructor arguments to `LUA_VECTOR_TYPE`. | Default float | `vendor/luaur-vm-0.1.8/src/functions/vector_create.rs` | ENGINE | Public constructor precision changes in double builds. |
| `VM/src/lveclib.cpp` | `vector_magnitude` | Uses configurable lanes and precision-dispatched sqrt. | Default float | `functions/vector_magnitude.rs` | ENGINE | Precision change. |
| `VM/src/lveclib.cpp` | `vector_normalize` | Uses configurable inverse magnitude. | Default float | `functions/vector_normalize.rs` | ENGINE | Zero/NaN behavior must match fast builtin. |
| `VM/src/lveclib.cpp` | `vector_cross` | Uses configurable input pointers and zero literal. | Default float | `functions/vector_cross.rs` | ENGINE | `w` remains zero. |
| `VM/src/lveclib.cpp` | `vector_dot` | Reads configurable lane type. | Default float | `functions/vector_dot.rs` | ENGINE | Four-wide includes `w`. |
| `VM/src/lveclib.cpp` | `vector_angle` | Uses configurable vector/axis pointers and cross-product scratch. | Default float | `functions/vector_angle.rs` | ENGINE | Angle calculation still ultimately uses doubles. |
| `VM/src/lveclib.cpp` | `vector_floor` | Uses precision-dispatched floor. | Default float | `functions/vector_floor.rs` | ENGINE | Precision change. |
| `VM/src/lveclib.cpp` | `vector_ceil` | Uses precision-dispatched ceil. | Default float | `functions/vector_ceil.rs` | ENGINE | Precision change. |
| `VM/src/lveclib.cpp` | `vector_abs` | Uses precision-dispatched absolute value. | Default float | `functions/vector_abs.rs` | ENGINE | Precision change. |
| `VM/src/lveclib.cpp` | `vector_sign` | Uses precision-dispatched sign. | Default float | `functions/vector_sign.rs` | ENGINE | Helper rename required. |
| `VM/src/lveclib.cpp` | `vector_clamp` | Uses configurable pointers and precision-dispatched clamp. | Default float | `functions/vector_clamp.rs` | ENGINE | Mirrors fast builtin validation. |
| `VM/src/lveclib.cpp` | `vector_min` | Uses configurable scratch/input component type. | Default float | `functions/vector_min.rs` | ENGINE | Variadic precision. |
| `VM/src/lveclib.cpp` | `vector_max` | Uses configurable scratch/input component type. | Default float | `functions/vector_max.rs` | ENGINE | Variadic precision. |
| `VM/src/lveclib.cpp` | `vector_index` | Reads components through `LUA_VECTOR_TYPE`. | Default float | `functions/vector_index.rs` | ENGINE | Returned Lua number remains double. |
| `VM/src/lveclib.cpp` | `vector_lerp` | Uses configurable input/`t` types and precision-dispatched lerp. | Default float | `functions/vector_lerp.rs` | ENGINE | Must match builtin folding and fast path. |
| `VM/src/lveclib.cpp` | `createmetatable` | Uses precision-neutral numeric literals for the dummy vector. | Default float | `functions/createmetatable_lveclib.rs` | ENGINE | Double build allocates a dummy GC vector. |
| `VM/src/lveclib.cpp` | `luaopen_vector` | Uses precision-neutral literals for `zero` and `one`. | Default float | `functions/luaopen_vector.rs` | ENGINE | Double build creates GC-backed constants. |

Paths without a vendor prefix in this subsection are under `vendor/luaur-vm-0.1.8/src/`.

### Interpreter switch

All opcode-case twins currently live in the verified consolidated file `vendor/luaur-vm-0.1.8/src/functions/luau_execute.rs`; the old `vm_case_lvmexecute_alt_*.rs` files are only doc-pointer artifacts in this fork.

| c file | symbol | change summary | FFlag guard(s) + default path | rust twin path | class | risk notes |
|---|---|---|---|---|---|---|
| `VM/src/lvmexecute.cpp` | `VM_CHECK_GC` | New low-overhead conditional GC-step macro that saves PC and refreshes base only when needed. | Called under `LuauBackedgeHeapCheck`; default **OFF** | NONE-new | ENGINE | Must preserve interpreter reentry/base invariants. |
| `VM/src/lvmexecute.cpp` | `LOP_GETTABLEKS` case | Direct-field callbacks receive `DirectFieldResult` in double builds; vector field reads use `LUA_VECTOR_TYPE`. | `LuauDirectFieldGet` default **OFF**; double representation default OFF | `vendor/luaur-vm-0.1.8/src/functions/luau_execute.rs` | ENGINE | Callback ABI and vector representation meet in this case. |
| `VM/src/lvmexecute.cpp` | `LOP_ADD` case | Vector addition uses configured lanes and state-aware `setvvalue`. | Default float | same | ENGINE | Double path allocates. |
| `VM/src/lvmexecute.cpp` | `LOP_SUB` case | Same conversion for subtraction. | Default float | same | ENGINE | Must match slow path. |
| `VM/src/lvmexecute.cpp` | `LOP_MUL` case | Converts vector/vector and scalar/vector multiplication to configured precision. | Default float | same | ENGINE | Three operand-shape branches. |
| `VM/src/lvmexecute.cpp` | `LOP_DIV` case | Converts all vector division shapes to configured precision. | Default float | same | ENGINE | IEEE zero/NaN behavior must match folding. |
| `VM/src/lvmexecute.cpp` | `LOP_IDIV` case | Vector/scalar floor division uses configured casts and state-aware result storage. | Default float | same | ENGINE | Must match `luai_numidiv` slow path. |
| `VM/src/lvmexecute.cpp` | `LOP_MULK` case | Vector-by-number-constant multiply uses configured precision. | Default float | same | ENGINE | Double path allocates. |
| `VM/src/lvmexecute.cpp` | `LOP_DIVK` case | Vector-by-number-constant division uses configured precision. | Default float | same | ENGINE | Same. |
| `VM/src/lvmexecute.cpp` | `LOP_IDIVK` case | Vector-by-number-constant floor division uses configured precision. | Default float | same | ENGINE | Same. |
| `VM/src/lvmexecute.cpp` | `LOP_UNM` case | Vector negation uses configured lanes and state-aware storage. | Default float | same | ENGINE | Must preserve signed zeros. |
| `VM/src/lvmexecute.cpp` | `LOP_FORNLOOP` case | Adds a conditional GC check at the loop backedge. | Backedge flag default **OFF** | same | ENGINE | New safepoint when enabled. |
| `VM/src/lvmexecute.cpp` | `LOP_FORGLOOP` case | Adds a conditional GC check at the generic-loop backedge. | Backedge flag default **OFF** | same | ENGINE | New safepoint when enabled. |
| `VM/src/lvmexecute.cpp` | `LOP_JUMPBACK` case | Adds a conditional GC check before taking the jump. | Backedge flag default **OFF** | same | ENGINE | Main tight-loop safepoint. |
| `VM/src/lvmexecute.cpp` | `LOP_JUMPX` case | Adds the same conditional GC check to extended jumps. | Backedge flag default **OFF** | same | ENGINE | Applied to the opcode generally, not conditioned on offset sign in the hunk. |
| `VM/src/lvmexecute.cpp` | `LOP_DIVRK` case | Number-constant divided by vector uses configured precision. | Default float | same | ENGINE | Scalar/vector reverse division branch. |

## FFlag and configuration inventory

Added flags:

| flag | default | gates | default release path |
|---|---:|---|---|
| `FFlag::LuauCompileIifeInline` | `false` | Lets IIFEs bypass the normal compiler inline cost ceiling. | **OFF**: previous cost ceiling applies to every call. |
| `FFlag::LuauBytecodeFold` | `false` | Runs SCCP on bytecode after JIT inlining. | **OFF**: no post-inline SCCP. |
| `DFFlag::LuauSelfIsSelfAndAlwaysSelf` | `false` | Makes `@self` resolve immediately from the requirer and prevents overrides. | **OFF**: legacy later `@self` handling remains. |
| `FFlag::LuauXpcallFixMessageYieldPath` | `false` | Changes call-depth restoration around yieldable xpcall error-message continuations. | **OFF**: old `nCcalls/baseCcalls` restoration. |
| `FFlag::LuauGcTraceUdata`, version 2 | `false` | Enables native userdata mark callbacks, weak refs, embedder fixed-point GC, and associated state. | **OFF**: no weak registry or embedder marking; new APIs assert if used. |
| `FFlag::LuauBackedgeHeapCheck`, version 2 | `false` | Adds interpreter GC checks at loop/jump backedges and adjusts assist work. | **OFF**: no new backedge checks. Assist scaling is nevertheless forced when `LUA_VECTOR_DOUBLE == 1`. |

Removed flags:

| flag | old default | replacement behavior |
|---|---:|---|
| `DFFlag::LuauRequireAliasOverrideOrderFix` | `false` | Reset-to-requirer ordering is now unconditional. Thus the target default executes what was effectively the old flag-ON ordering. |
| `FFlag::LuauRequireResolveAliasNullCheck` | `false` | Alias optional-null checking is now unconditional. Thus the target default executes the former flag-ON safety behavior. |

Flipped flags: **none**.

Pre-existing guards materially used by this rung:

- `DebugLuauUserDefinedClasses`, default `false`: all parser/compiler class-hoisting behavior is dark by default.
- `LuauCustomYieldablePcalls`, default `false`: the xpcall fix’s final branch requires this and the new fix flag.
- `LuauDirectFieldGet`, default `false`: guards userdata direct-field helpers; double-vector result plumbing additionally depends on `LUA_VECTOR_DOUBLE`.
- `LUA_VECTOR_DOUBLE` is not an FFlag. It is newly added with default `0`, so a default build executes the float/inline-vector path.
- `LUA_VECTOR_SIZE` remains default `3`.

## Completeness accounting

Default-context hunk attribution by file:

| file | hunks | attributed symbols |
|---|---:|---|
| `Ast/include/Luau/Parser.h` | 2 | `Parser` helper declarations; class map field |
| `Ast/src/Parser.cpp` | 6 | flag declaration reorder; `getMatchingClass`; `isExprLValue`; `parseClassStat`; `reportLValueError`; `parseAssignment` |
| `Bytecode/include/Luau/BytecodeBuilder.h` | 4 | vector builder API; `Constant`; `ConstantKey`; equality |
| `Bytecode/include/Luau/BytecodeGraph.h` | 5 | include for erase helpers; `BcVmConstKind`; `BcVmConst`; equality; `BcFunction` helpers |
| `Bytecode/include/Luau/Sccp.h` | 8 | `rewriteToLoad`; removed erase helpers; `replaceUses`; `updateBlockUses`; `eraseDeadProducer`; `arithToK` |
| `Bytecode/src/BytecodeBuilder.cpp` | 5 | key hash; vector add APIs; `writeFunction`; `dumpConstant` |
| `Bytecode/src/BytecodeGraph.cpp` | 2 | `fromFunctionBytecode`; `toFunctionBytecode` |
| `Bytecode/src/Sccp.cpp` | 2 | `BcVmConstImpl::evaluate` DIV and IDIV |
| `Common/include/Luau/Bytecode.h` | 1 | `LBC_CONSTANT_VECTORD` |
| `Common/include/Luau/Common.h` | 2 | platform branches of `LUAU_MAYBE_UNUSED` |
| `Common/include/Luau/DenseHash2.h` | 3 | hash assertion; set/map constructors |
| `Compiler/include/Luau/Compiler.h` | 2 | `CompileOptions`; `setCompileConstantVectord` |
| `Compiler/include/luacode.h` | 2 | `lua_CompileOptions`; C helper declaration |
| `Compiler/src/BuiltinFolding.cpp` | 5 | vector constructors; `ctype`; `ctypeof`; `foldBuiltin` |
| `Compiler/src/BuiltinFolding.h` | 1 | `foldBuiltin` signature |
| `Compiler/src/Compiler.cpp` | 21 | new flag; class hoisting/resolution; inline folding; vector emission; unrolled folding; orchestration; callback helpers |
| `Compiler/src/ConstantFolding.cpp` | 15 | equality; unary/binary folding; visitor state/calls/indexing/callback conversion; `foldConstants` |
| `Compiler/src/ConstantFolding.h` | 3 | `Constant` enum/payload; `foldConstants` declaration |
| `Compiler/src/ValueTracking.cpp` | 3 | visitor state/constructor; class visit; `trackValues` |
| `Compiler/src/ValueTracking.h` | 1 | `trackValues` declaration |
| `Compiler/src/lcode.cpp` | 1 | `luau_set_compile_constant_vectord` |
| `Inliner/src/JitInliner.cpp` | 6 | includes/flag; `createInlinedProto`; `hasFoldableConstants`; `onInlineFunction` |
| `Inliner/src/RuntimeBytecodeBuilder.h` | 3 | `constTypeToTT`; `dumpConstant`; `emitCode` |
| `Inliner/src/TValueVmConstImpl.cpp` | 1 | all new `TValueVmConstImpl` method bodies |
| `Inliner/src/TValueVmConstImpl.h` | 1 | constant, backing type, evaluator type and declarations |
| `Require/src/RequireNavigator.cpp` | 5 | three flags; `navigateImpl`; `navigateToAndPopulateConfig` |
| `VM/include/lua.h` | 13 | vector type/API; GC op/dump/rate; pointer key; embedder GC/weak refs; direct-field APIs; ref/debug APIs; declaration relocation |
| `VM/include/luaconf.h` | 1 | vector precision macros |
| `VM/include/lualib.h` | 1 | auxiliary vector APIs |
| `VM/src/lapi.cpp` | 10 | vector APIs; GC/dump/debug/key APIs; ref helpers/weak refs; allocation rate; direct-field results |
| `VM/src/laux.cpp` | 2 | check/optional vector APIs; vector tostring |
| `VM/src/lbuiltins.cpp` | 20 | include plus all listed `luauF_vector*` fast paths |
| `VM/src/ldebug.cpp` | 3 | include; `lua_callhook`; `lua_atbreakpoint` |
| `VM/src/ldo.cpp` | 4 | new flag; `resume_handle`; `resume_finish` |
| `VM/src/lgc.cpp` | 12 | includes/flags; string colors; userdata/vector marking; embedder marking; free/root/atomic; `luaC_step` |
| `VM/src/lgc.h` | 1 | stale `luaC_initobj` declaration removal |
| `VM/src/lgcdebug.cpp` | 3 | `validateobj`; `dumpobj`; `enumobj` |
| `VM/src/lmem.cpp` | 4 | force-inline allocator helpers; fixed GCO allocate/free |
| `VM/src/lmem.h` | 2 | fixed GCO macros and declarations |
| `VM/src/lnumutils.h` | 4 | vector equality/NaN overloads; sign/clamp; lerp/dispatch macros |
| `VM/src/lobject.h` | 5 | conditional macros; `vvalue`; `setvvalue`; `DirectFieldResult`; `LuauVector` |
| `VM/src/lstate.cpp` | 5 | flag declaration; `weakenvalues`; `f_luaopen`; two `lua_newstate` initialization areas |
| `VM/src/lstate.h` | 4 | metrics; `global_State`; `GCObject`; `gco2vec` |
| `VM/src/ltable.cpp` | 2 | float and double `hashvec` |
| `VM/src/ltm.cpp` | 2 | conditional `luaT_typenames` placement |
| `VM/src/lveclib.cpp` | 20 | include plus all listed vector-library functions |
| `VM/src/lvector.cpp` | 1 | `luaVec_newvector`; `luaVec_freevector` |
| `VM/src/lvector.h` | 1 | `sizevector` and function declarations |
| `VM/src/lvm.h` | 1 | `luaV_tovector` declaration |
| `VM/src/lvmexecute.cpp` | 20 | include/flag/macro; GETTABLEKS; vector arithmetic cases; four GC-check cases |
| `VM/src/lvmload.cpp` | 2 | vector include; `loadsafe` tags |
| `VM/src/lvmutils.cpp` | 5 | vector include; `luaV_tovector`; grouped arithmetic branches |

Accounting result:

- Hunks total: **258**
- Hunks attributed: **258**
- Unresolved: **0**
- Ledger rows by class, counting overload/callback families as one logical row:
  - ENGINE: **163**
  - RT-API: **35**
  - OUT-OF-SCOPE: **32**

## Dependency notes

1. The class-hoisting rows depend on the earlier user-defined-class foundation: `DebugLuauUserDefinedClasses`, `AstStatClass`, class bytecode/runtime objects, and the associated export-value work must already exist. The current Rust fork has much of that baseline, but these rows must land together across parser, value tracking, and compiler.

2. `LBC_CONSTANT_VECTORD` is appended after `LBC_CONSTANT_CLASS_SHAPE`. Any earlier rung introducing or renumbering `LBC_CONSTANT_INTEGER`/`LBC_CONSTANT_CLASS_SHAPE` must land first; otherwise bytecode tag numbers diverge.

3. The double-vector port has a strict internal order:
   `LuauBytecodeTag` and compiler/bytecode constant representations → VM precision/type/TValue/GC representation → fixed allocator and `lvector` → loader/table/hash/arithmetic/library/interpreter callers → public/RT wrappers.

4. `luaVec_newvector` calls `luaC_init`; therefore the earlier transition represented in Rust by `vendor/luaur-vm-0.1.8/src/macros/lua_c_init.rs` must be present before adding the new vector object. The stale `luaC_initobj` declaration is removed in this rung.

5. The `BcFunction`/SCCP rows depend on BytecodeGraph and SCCP work already present in the C 0.730 base. The current 0.724 Rust fork has BytecodeGraph records but no translated `Sccp`; port the missing earlier SCCP baseline before applying these edits.

6. The JIT `TValueVmConstImpl` and `onInlineFunction` work depends on the same SCCP baseline and the runtime bytecode inliner. It remains OUT-OF-SCOPE for the currently vendored crate family.

7. The direct-field result changes depend on the earlier `LuauDirectFieldGet` API and opcode machinery. They become representation-critical only when double vectors are enabled.

8. `lua_memorydump` and `lua_allocationrate` are new public wrappers over already-translated internal functions (`luaC_dump` and `luaC_allocationrate`), so those internal twins must remain wired before adding the API exports.

9. The Require alias changes depend on the standalone Require navigator/config subsystem, which is not part of the vendored luaur crate set.