# luaur 0.1.8 baseline audit against Luau `8f33df91`

Compared against:

```sh
git -C /Users/levi/dev/oss/luigi-rosso-luau show 8f33df91:<path>
git -C /Users/levi/dev/oss/luigi-rosso-luau grep -n <pattern> 8f33df91 -- VM Compiler
```

Commit resolved to `8f33df910d790c1321a20028af8d8134fa3e0334`, dated 2026-06-05, subject `Sync to upstream/release/724 (#2425)`.

## Bottom line

There is no evidence that the vendored engine definitions are pre-0.724. The bytecode versions, opcode ordering, builtin IDs, userdata/typeinfo surface, and compiler option layout all match the C fork at `8f33df91`, including its Rive extensions through bytecode version 11.

The effective base nevertheless diverges in several places:

1. All Rust fast-call dispatch slots are wired to `luauF_missing`, so no translated fast builtin ever executes.
2. Three FFlag gates are incomplete or baked:
   - `LuauCompileDuptableConstantPack2` is baked ON in table-shape equality/hash.
   - `LuauCompileNoOptNext` is omitted, giving its OFF behavior.
   - `LuauIntegerBufferFastcalls` is omitted from the buffer-integer builtin gate, giving its ON behavior when `LuauIntegerFastcalls` is ON.
3. `luaur-rt` selects a different effective flag profile from the Luau CLI: `FixMathNoisePrecision` is ON instead of OFF, while `LuauExportValueSyntax` is OFF instead of ON.
4. `math.ldexp` constant folding uses multiplication by `2^exp`, not `ldexp`; this differs for edge cases such as `ldexp(0, 2000)`.
5. Rust assertions ignore a custom assertion handler’s “do not trap” return value.
6. The high-level `luaur-rt::Compiler` does not expose five fields supported by the engine’s full `CompileOptions`.

These are translation/embedder divergences, not evidence of an older Luau release base.

## Per-subsystem verdicts

| Subsystem | Verdict | Reason |
|---|---|---|
| Bytecode constants/types | **matches 0.724** | Version range `3..11`, target `6`, type-info range `1..3`, target `3`, constant tags, and bytecode types are exact. |
| Opcode enum/interpreter | **matches 0.724** | All 89 valid opcodes have identical numeric ordering and an interpreter match arm. |
| Builtin enum | **matches 0.724** | All 133 builtin IDs have identical order; `getBuiltinInfo` covers the same IDs and metadata. |
| VM fast-call implementation | **diverges: all fastcalls disabled** | Rust’s 256-entry dispatch array contains only `luauF_missing`. |
| VM API/userdata | **matches 0.724** | `lua_pushcclosurek`, userdata limits, proxy exception, direct-access arrays, and direct-field surface match. |
| Assertion infrastructure | **diverges: handler suppression lost** | Checks are otherwise identical, but Rust always traps after calling the handler. |
| Compiler options/levels | **matches 0.724** | All engine fields, defaults, and optimization/debug thresholds match. |
| Compiler folding | **diverges: `ldexp` implementation** | Foldable builtin set matches, but `LDEXP` has different edge behavior. |
| FFlag plumbing | **diverges: three incomplete gates** | Most flags are runtime values, but the three gates above are baked/omitted. |
| Effective RT defaults | **diverges** | `luaur-rt` enables `FixMathNoisePrecision` and disables export-value syntax relative to the Luau CLI profile. |
| `luaur-rt` compiler API | **diverges: narrower wrapper** | Engine fields exist, but the safe wrapper does not expose userdata types, known-member libraries/callbacks, or disabled builtins. |

## 1. Bytecode versioning and type information

C at `8f33df91:Common/include/Luau/Bytecode.h:497-522`:

```text
LBC_VERSION_MIN         = 3
LBC_VERSION_MAX         = 11
LBC_VERSION_TARGET      = 6
LBC_TYPE_VERSION_MIN    = 1
LBC_TYPE_VERSION_MAX    = 3
LBC_TYPE_VERSION_TARGET = 3
```

Rust is identical at [luau_bytecode_tag.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/enums/luau_bytecode_tag.rs:13).

The bytecode types also match exactly:

- C: `8f33df91:Common/include/Luau/Bytecode.h:525-548`
- Rust: [luau_bytecode_type.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/enums/luau_bytecode_type.rs:19)

This includes:

```text
0 nil, 1 boolean, 2 number, 3 string, 4 table, 5 function,
6 thread, 7 userdata, 8 vector, 9 buffer, 10 integer,
15 any, 64..95 tagged userdata, optional bit 128, invalid 256
```

The compiler version-selection ladder is also exact:

| Condition, highest first | Emitted version |
|---|---:|
| `LuauEmitCallFeedback` | 11 |
| `DebugLuauUserDefinedClasses` | 10 |
| `LuauCompileUdataDirect` | 9 |
| `LuauIntegerType2` | 8 |
| `LuauCompileDuptableConstantPack2` | 7 |
| otherwise | target 6 |

C: `8f33df91:Bytecode/src/BytecodeBuilder.cpp:1313-1337`. Rust: [bytecode_builder_get_version.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_get_version.rs:4) and [bytecode_builder_get_type_encoding_version.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_get_type_encoding_version.rs:4).

Therefore `LBC_VERSION_TARGET = 6` is not evidence that luaur emits only v6. `luaur-rt` enables `LuauEmitCallFeedback`, so its effective compiler emits v11.

### Verdict

**matches 0.724** for versions and type information. The prior “advertised range lags official Luau” evidence does not apply to this vendored tree.

## 2. Opcode enum and interpreter coverage

C enum: `8f33df91:Common/include/Luau/Bytecode.h:61-455`.  
Rust enum: [luau_opcode.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/enums/luau_opcode.rs:4).

Both contain 89 valid opcodes, followed by `LOP__COUNT = 89`, with this exact order:

```text
 0 NOP                 1 BREAK               2 LOADNIL             3 LOADB
 4 LOADN               5 LOADK               6 MOVE                7 GETGLOBAL
 8 SETGLOBAL           9 GETUPVAL           10 SETUPVAL           11 CLOSEUPVALS
12 GETIMPORT          13 GETTABLE           14 SETTABLE           15 GETTABLEKS
16 SETTABLEKS         17 GETTABLEN          18 SETTABLEN          19 NEWCLOSURE
20 NAMECALL           21 CALL               22 RETURN             23 JUMP
24 JUMPBACK           25 JUMPIF             26 JUMPIFNOT          27 JUMPIFEQ
28 JUMPIFLE           29 JUMPIFLT           30 JUMPIFNOTEQ        31 JUMPIFNOTLE
32 JUMPIFNOTLT        33 ADD                34 SUB                35 MUL
36 DIV                37 MOD                38 POW                39 ADDK
40 SUBK               41 MULK               42 DIVK               43 MODK
44 POWK               45 AND                46 OR                 47 ANDK
48 ORK                49 CONCAT             50 NOT                51 MINUS
52 LENGTH             53 NEWTABLE           54 DUPTABLE           55 SETLIST
56 FORNPREP           57 FORNLOOP           58 FORGLOOP           59 FORGPREP_INEXT
60 FASTCALL3          61 FORGPREP_NEXT      62 NATIVECALL         63 GETVARARGS
64 DUPCLOSURE         65 PREPVARARGS        66 LOADKX             67 JUMPX
68 FASTCALL           69 COVERAGE           70 CAPTURE            71 SUBRK
72 DIVRK              73 FASTCALL1          74 FASTCALL2          75 FASTCALL2K
76 FORGPREP           77 JUMPXEQKNIL        78 JUMPXEQKB          79 JUMPXEQKN
80 JUMPXEQKS          81 IDIV               82 IDIVK              83 GETUDATAKS
84 SETUDATAKS         85 NAMECALLUDATA      86 NEWCLASSMEMBER     87 CALLFB
88 CMPPROTO
```

The Rust interpreter has 89 distinct match arms in [luau_execute.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/luau_execute.rs:227), including the custom `CALLFB`, userdata, class, and proto-comparison cases.

There are 88 `vm_case_lvmexecute_alt_*.rs` index files. They start with `LOADNIL`; `NOP` exists only as the first monolithic match arm. For example, [vm_case_lvmexecute_alt_b.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/vm_case_lvmexecute_alt_b.rs:1) points to C line 326, while the NOP arm is directly at [luau_execute.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/luau_execute.rs:228). This is a translation-index irregularity, not missing execution coverage.

`getOpLength` also matches the C two-word opcode set. C: `8f33df91:Common/include/Luau/BytecodeUtils.h:9-47`; Rust: [get_op_length.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/functions/get_op_length.rs:4).

### Verdict

**matches 0.724** for enum values and execution coverage.

## 3. Builtin-function enum and fast-call dispatch

C enum: `8f33df91:Common/include/Luau/Bytecode.h:550-736`.  
Rust enum: [luau_builtin_function.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/enums/luau_builtin_function.rs:4).

Both contain 133 entries in this exact order:

```text
0 NONE; 1 ASSERT;
2 MATH_ABS; 3 MATH_ACOS; 4 MATH_ASIN; 5 MATH_ATAN2; 6 MATH_ATAN;
7 MATH_CEIL; 8 MATH_COSH; 9 MATH_COS; 10 MATH_DEG; 11 MATH_EXP;
12 MATH_FLOOR; 13 MATH_FMOD; 14 MATH_FREXP; 15 MATH_LDEXP;
16 MATH_LOG10; 17 MATH_LOG; 18 MATH_MAX; 19 MATH_MIN; 20 MATH_MODF;
21 MATH_POW; 22 MATH_RAD; 23 MATH_SINH; 24 MATH_SIN; 25 MATH_SQRT;
26 MATH_TANH; 27 MATH_TAN;
28 BIT32_ARSHIFT; 29 BIT32_BAND; 30 BIT32_BNOT; 31 BIT32_BOR;
32 BIT32_BXOR; 33 BIT32_BTEST; 34 BIT32_EXTRACT; 35 BIT32_LROTATE;
36 BIT32_LSHIFT; 37 BIT32_REPLACE; 38 BIT32_RROTATE; 39 BIT32_RSHIFT;
40 TYPE; 41 STRING_BYTE; 42 STRING_CHAR; 43 STRING_LEN; 44 TYPEOF;
45 STRING_SUB; 46 MATH_CLAMP; 47 MATH_SIGN; 48 MATH_ROUND;
49 RAWSET; 50 RAWGET; 51 RAWEQUAL; 52 TABLE_INSERT; 53 TABLE_UNPACK;
54 VECTOR; 55 BIT32_COUNTLZ; 56 BIT32_COUNTRZ; 57 SELECT_VARARG;
58 RAWLEN; 59 BIT32_EXTRACTK; 60 GETMETATABLE; 61 SETMETATABLE;
62 TONUMBER; 63 TOSTRING; 64 BIT32_BYTESWAP;
65 BUFFER_READI8; 66 BUFFER_READU8; 67 BUFFER_WRITEU8;
68 BUFFER_READI16; 69 BUFFER_READU16; 70 BUFFER_WRITEU16;
71 BUFFER_READI32; 72 BUFFER_READU32; 73 BUFFER_WRITEU32;
74 BUFFER_READF32; 75 BUFFER_WRITEF32; 76 BUFFER_READF64; 77 BUFFER_WRITEF64;
78 VECTOR_MAGNITUDE; 79 VECTOR_NORMALIZE; 80 VECTOR_CROSS; 81 VECTOR_DOT;
82 VECTOR_FLOOR; 83 VECTOR_CEIL; 84 VECTOR_ABS; 85 VECTOR_SIGN;
86 VECTOR_CLAMP; 87 VECTOR_MIN; 88 VECTOR_MAX; 89 MATH_LERP;
90 VECTOR_LERP; 91 MATH_ISNAN; 92 MATH_ISINF; 93 MATH_ISFINITE;
94 INTEGER_CREATE; 95 INTEGER_TONUMBER; 96 INTEGER_NEG; 97 INTEGER_ADD;
98 INTEGER_SUB; 99 INTEGER_MUL; 100 INTEGER_DIV; 101 INTEGER_MIN;
102 INTEGER_MAX; 103 INTEGER_REM; 104 INTEGER_IDIV; 105 INTEGER_UDIV;
106 INTEGER_UREM; 107 INTEGER_MOD; 108 INTEGER_CLAMP; 109 INTEGER_BAND;
110 INTEGER_BOR; 111 INTEGER_BNOT; 112 INTEGER_BXOR; 113 INTEGER_LT;
114 INTEGER_LE; 115 INTEGER_ULT; 116 INTEGER_ULE; 117 INTEGER_GT;
118 INTEGER_GE; 119 INTEGER_UGT; 120 INTEGER_UGE; 121 INTEGER_LSHIFT;
122 INTEGER_RSHIFT; 123 INTEGER_ARSHIFT; 124 INTEGER_LROTATE;
125 INTEGER_RROTATE; 126 INTEGER_EXTRACT; 127 INTEGER_BTEST;
128 INTEGER_COUNTRZ; 129 INTEGER_COUNTLZ; 130 INTEGER_BSWAP;
131 BUFFER_READINTEGER; 132 BUFFER_WRITEINTEGER
```

`getBuiltinInfo` mentions all 133 IDs on both sides, with matching parameter count, result count, and `Flag_NoneSafe` groupings. C: `8f33df91:Compiler/src/Builtins.cpp:481-735`; Rust: [get_builtin_info.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/functions/get_builtin_info.rs:5).

### Fast-call table divergence

C’s `luauF_table[256]` contains:

- index 0: `NULL`
- indices 1–132: the corresponding real fast builtin
- indices 133–196: `luauF_missing`
- indices 197–255: implicit zero initialization, therefore `NULL`

C citation: `8f33df91:VM/src/lbuiltins.cpp:2563-2754`.

Rust contains:

```rust
pub static luauF_table: [luau_FastFunction; 256] =
    [Some(crate::functions::luau_f_missing::luau_f_missing); 256];
```

Rust citation: [luau_f_table.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/macros/luau_f_table.rs:1).

`luau_f_missing` returns `-1`, causing the interpreter to use the ordinary call sequence. See [luau_f_missing.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/luau_f_missing.rs:5) and the dispatch/fallback site at [luau_execute.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/luau_execute.rs:3834).

Thus all real fast-call functions are present as Rust source files but unreachable through `luauF_table`.

### Verdict

- Builtin IDs and compiler metadata: **matches 0.724**
- VM dispatch: **diverges: every fast builtin is disabled**

## 4. FFlags and FInts

### Default model

C `LUAU_FASTFLAGVARIABLE` constructs every boolean flag with `false`; `LUAU_FASTINTVARIABLE` uses its explicit numeric default. C: `8f33df91:Common/include/Luau/Common.h:132-171`.

Rust mirrors that static initialization at [luau_fastflagvariable.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/macros/luau_fastflagvariable.rs:10) and [luau_fastintvariable.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/macros/luau_fastintvariable.rs:5).

There are no `DFFlag` or `DFInt` uses under `VM/` or `Compiler/` at this commit.

Two effective-default contexts matter:

- A raw C or Rust engine library starts every boolean flag OFF.
- Luau command-line tools call `setLuauFlagsDefault`, enabling non-experimental flags whose names begin with `Luau`; Debug flags and `FixMathNoisePrecision` stay OFF. C: `8f33df91:CLI/src/Flags.cpp:33-45`.
- `luaur-rt` calls `set_all_flags(true)` at VM construction. Rust: [state.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-rt-0.1.8/src/state.rs:139). Its explicit list is at [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs:37).

### Boolean flags used by VM/Compiler

| Flag | Behavior gated | luaur handling | C CLI | `luaur-rt` |
|---|---|---|---:|---:|
| `DebugLuauNoInline` | Honors the debug no-inline function attribute | Runtime option | OFF | OFF |
| `DebugLuauUserDefinedClasses` | Class AST/compiler/bytecode-v10 behavior | Runtime option | OFF | OFF |
| `DebugLuauUserDefinedClassesRuntime` | Runtime class/object table operations and class library | Runtime option | OFF | OFF |
| `FixMathNoisePrecision` | Wraps noise inputs modulo 256 before float conversion | Runtime option | **OFF** | **ON** |
| `LuauCallFeedback` | Processes `CALLFB` feedback slots | Runtime option | ON | ON |
| `LuauClosureUsageCounter` | Maintains closure usage/hit counters | Runtime option | ON | ON |
| `LuauCompileDuptableConstantPack2` | Constant-bearing DUPTABLE shapes and bytecode v7 | Runtime option except table-shape equality/hash are **baked ON** | ON | ON |
| `LuauCompileFastcall3CostModel` | Treats up to three-argument builtins as short calls | Runtime option | ON | ON |
| `LuauCompileFoldOptimize` | New constant-folding/table-property path | Runtime option | ON | ON |
| `LuauCompileInlineTableFunctions` | Finds function expressions through table fields/instantiation | Runtime option | ON | ON |
| `LuauCompileNewTableMutationTracker` | Selects new table mutation tracker | Runtime option | ON | ON |
| `LuauCompileNoOptNext` | Disables `for ... in next,t` specialization when environment access is unsafe | Declared, but compiler use is **omitted/baked OFF** | ON | ON, but ignored |
| `LuauCompilePropagateTableProps2` | Propagates table properties in constant folding | Runtime option | ON | ON |
| `LuauCompileStringInterpTargetTop` | Reuses target-top register for string interpolation | Runtime option | ON | ON |
| `LuauCompileTypeAliases` | Emits/reads type aliases in type maps | Runtime option | ON | ON |
| `LuauDirectFieldGet` | Per-field userdata getter tables and interpreter shortcut | Runtime option | ON | ON |
| `LuauEmitCallFeedback` | Emits v11 `CALLFB` and inlinable proto flags | Runtime option | ON | ON |
| `LuauExportValueSyntax` | Exported-value parser/compiler path | Runtime option | **ON** | **OFF** |
| `LuauIntegerBufferFastcalls` | Enables `buffer.readinteger`/`writeinteger` IDs with integer fastcalls | Declared, but conjunct is **omitted/baked ON** | ON | ON |
| `LuauIntegerFastcalls` | Integer library and integer/buffer builtin IDs | Runtime option | ON | ON |
| `LuauIntegerLibrary` | Registers integer library and integer-aware buffer functions | Runtime option | ON | ON |
| `LuauIntegerType2` | Integer literals/constants/typeinfo and bytecode v8 | Runtime option | ON | ON |
| `LuauResumeRestoreCcalls` | Restores C-call counters across protected coroutine resumes | Runtime option | ON | ON |
| `LuauUdataDirectAccess6` | Loads/marks direct userdata access metadata | Runtime option | ON | ON |
| `LuauYieldIter2` | Finishes yielded iterator operations correctly | Runtime option | ON | ON |

`LuauCompileUdataDirect`, used under `Bytecode/` rather than `VM/` or `Compiler/`, is also a matching runtime option and raises emitted bytecode to v9. Both the C CLI and `luaur-rt` enable it.

Relevant Rust flag definitions are collected at [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs:200), [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs:278), and [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs:339).

### FInts

| FInt | C default | Rust default | Use |
|---|---:|---:|---|
| `LuauCompileInlineDepth` | 5 | 5 | Maximum recursive inlining depth |
| `LuauCompileInlineThreshold` | 25 | 25 | Base inlining cost threshold |
| `LuauCompileInlineThresholdMaxBoost` | 300 | 300 | Maximum call-site boost |
| `LuauCompileLoopUnrollThreshold` | 25 | 25 | Base loop-unroll threshold |
| `LuauCompileLoopUnrollThresholdMaxBoost` | 300 | 300 | Maximum unroll boost |
| `LuauInlineHitsThreshold` | 3 | 3 | Runtime feedback hit threshold |

C definitions: `8f33df91:Compiler/src/Compiler.cpp:26-31` and `8f33df91:VM/src/lfunc.cpp:10`. Rust: [lib.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/lib.rs:447).

## 5. `lua_pushcclosurek` and stack assertions

C function: `8f33df91:VM/src/lapi.cpp:742-758`.  
Rust function: [lua_pushcclosurek.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/lua_pushcclosurek.rs:23).

Both enforce:

1. function pointer is non-null / `Some`;
2. `nup >= 0`;
3. `nup <= L->top - L->base`;
4. after consuming the upvalues and placing the closure, `L->top < L->ci->top` before incrementing the stack top;
5. the newly allocated closure is white.

Rust macro citations:

- `api_checknelems`: [api_checknelems.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/macros/api_checknelems.rs:3)
- final stack-capacity assertion: [api_incr_top.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/macros/api_incr_top.rs:3)

C equivalents are `8f33df91:VM/src/lapi.cpp:49-57`.

The Rust assertion is not stricter than C at this commit. A SIGTRAP on this check points to stack/call-frame state at the caller, or to comparing an assertions-disabled C release with an assertions-enabled Rust build—not to a pre-0.724 `lua_pushcclosurek`.

One assertion-discipline discrepancy exists: C traps only if `assertCallHandler` returns nonzero (`8f33df91:Common/include/Luau/Common.h:66-70`). Rust calls the handler and then traps unconditionally at [luau_assert.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/macros/luau_assert.rs:3), even though [assert_call_handler.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-common-0.1.8/src/functions/assert_call_handler.rs:6) preserves the handler’s return value.

## 6. Userdata and typeinfo surface

C limits:

- `LUA_UTAG_LIMIT = 128`
- `LUA_LUTAG_LIMIT = 128`
- `UTAG_IDTOR = 128`
- `UTAG_PROXY = 129`
- `UTAG_INTERNAL_LIMIT = 130`

C: `8f33df91:VM/include/luaconf.h:99-107` and `8f33df91:VM/src/ludata.h:7-14`.

Rust matches at:

- [lua_utag_limit.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/macros/lua_utag_limit.rs:1)
- [lua_lutag_limit.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/macros/lua_lutag_limit.rs:1)
- [utag_idtor.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/macros/utag_idtor.rs:1)
- [utag_proxy.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/macros/utag_proxy.rs:1)
- [utag_internal_limit.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/macros/utag_internal_limit.rs:1)

`lua_newuserdatatagged` accepts tags `0..127` plus `UTAG_PROXY = 129`; it does not accept `UTAG_IDTOR = 128`. This is identical in C (`8f33df91:VM/src/lapi.cpp:1432-1441`) and Rust ([lua_newuserdatatagged.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/lua_newuserdatatagged.rs:15)).

`lua_newuserdatataggedwithmetatable` accepts only `0..127`, also identically. C: `8f33df91:VM/src/lapi.cpp:1443-1460`; Rust: [lua_newuserdatataggedwithmetatable.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/lua_newuserdatataggedwithmetatable.rs:15).

The base already contains both direct-access areas:

```text
udatadirect[130]
udatadirectfields[130]
udatagc[128]
udatamt[128]
lightuserdataname[128]
```

C: `8f33df91:VM/src/lstate.h:231-242`. Rust: [global_state.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/records/global_state.rs:37).

The experimental registration and result-writing APIs are present in Rust, including `lua_registeruserdatadirectaccess`, `lua_registeruserdatadirectfieldget`, and all number/vector/boolean/integer64/nil setters. The registration logic matches C’s metatable lookup and flag gate. C: `8f33df91:VM/src/lapi.cpp:1643-1681,1760-1817`; Rust: [lua_registeruserdatadirectaccess.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/lua_registeruserdatadirectaccess.rs:12) and [lua_registeruserdatadirectfieldget.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/lua_registeruserdatadirectfieldget.rs:17).

### Verdict

**matches 0.724**. Userdata-direct-field support is already part of the base.

## 7. Compiler options and folding

### `CompileOptions`

The engine `CompileOptions` layouts are identical, with defaults:

```text
optimizationLevel = 1
debugLevel        = 1
typeInfoLevel     = 0
coverageLevel     = 0
vectorLib         = null
vectorCtor        = null
vectorType        = null
mutableGlobals    = null
userdataTypes     = null
librariesWithKnownMembers = null
libraryMemberTypeCb        = null
libraryMemberConstantCb    = null
disabledBuiltins           = null
```

C: `8f33df91:Compiler/include/Luau/Compiler.h:26-71`.  
Rust: [compile_options.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/records/compile_options.rs:4).

The public C-ABI duplicate also matches field-for-field. C: `8f33df91:Compiler/include/luacode.h:23-67`; Rust: [lua_compile_options.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/records/lua_compile_options.rs:12).

Optimization/debug semantics match:

- optimization 0: no optimization;
- optimization 1: imports, builtin analysis, folding/prediction that preserves debuggability;
- optimization 2: inlining, loop unrolling, builtin constant folding, and extra type maps;
- debug 0: no debug support;
- debug 1: line/function information;
- debug 2: locals and upvalue names.

Representative C conditions are at `8f33df91:Compiler/src/Compiler.cpp:472-606,1203-1244,3694-3698,3884,5080-5148`; the corresponding Rust conditions are in [compiler_compile_function.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_function.rs:88), [compiler_compile_expr_call.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_expr_call.rs:33), and [compile_or_throw_compiler.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/functions/compile_or_throw_compiler.rs:79).

### Builtin folding set

Both sides fold the same 50 builtin IDs:

```text
MATH_ABS ACOS ASIN ATAN2 ATAN CEIL COSH COS DEG EXP FLOOR FMOD LDEXP
LOG10 LOG MAX MIN POW RAD SINH SIN SQRT TANH TAN
BIT32_ARSHIFT BAND BNOT BOR BXOR BTEST EXTRACT LROTATE LSHIFT REPLACE
RROTATE RSHIFT
TYPE STRING_BYTE STRING_CHAR STRING_LEN TYPEOF STRING_SUB
MATH_CLAMP MATH_SIGN MATH_ROUND VECTOR MATH_LERP
MATH_ISNAN MATH_ISINF MATH_ISFINITE
```

They also fold the same seven `math` constants: `pi`, `huge`, `nan`, `e`, `phi`, `sqrt2`, and `tau`.

C: `8f33df91:Compiler/src/BuiltinFolding.cpp:137-665`.  
Rust: [fold_builtin.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/functions/fold_builtin.rs:21) and [fold_builtin_math.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/functions/fold_builtin_math.rs:13).

Concrete folding discrepancy:

- C uses `ldexp(value, int(exp))` at `BuiltinFolding.cpp:203-206`.
- Rust uses `value * 2.0f64.powi(exp)` at [fold_builtin.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/src/functions/fold_builtin.rs:119).

For example, C `ldexp(0.0, 2000)` remains zero, while the Rust expression evaluates `0.0 * infinity`, producing NaN.

### High-level RT wrapper

The full engine structure contains every C field, but `luaur_rt::Compiler` stores and exposes only levels, vector configuration, and mutable globals. See [compiler.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-rt-0.1.8/src/compiler.rs:33).

It does not expose:

- `userdataTypes`
- `librariesWithKnownMembers`
- `libraryMemberTypeCb`
- `libraryMemberConstantCb`
- `disabledBuiltins`

That is an RT-API limitation, not an engine-layout lag.

## Concrete discrepancy ledger

| Area | C at `8f33df91` | Vendored Rust | Effect |
|---|---|---|---|
| Fast-call dispatch | Real functions at IDs 1–132; missing fallback at 133–196 | All 256 entries are `luau_f_missing` | Every fastcall falls back to an ordinary call |
| `LuauCompileDuptableConstantPack2` | OFF path ignores constants in table-shape equality/hash | Equality/hash always include constant state | Baked ON for these two methods |
| `LuauCompileNoOptNext` | ON requires no `getfenv`/`setfenv` before specializing `next,t` | Environment condition absent | Baked OFF behavior; unsafe specialization can remain enabled |
| `LuauIntegerBufferFastcalls` | Integer buffer IDs require both integer flags | Checks only `LuauIntegerFastcalls` | Second gate baked ON |
| Effective `FixMathNoisePrecision` | C CLI leaves non-`Luau` flag OFF | `luaur-rt` sets it ON | Different default `math.noise` path |
| Effective `LuauExportValueSyntax` | C CLI enables it | `luaur-rt` explicitly keeps it OFF | Different parser/compiler feature profile |
| `math.ldexp` fold | `ldexp(x, exp)` | `x * 2.powi(exp)` | Edge-case numeric divergence |
| Assertion handler | Handler return 0 suppresses debug break | Handler return is ignored | Rust always traps on failed enabled assertion |
| VM case index files | 89 C cases | 89 executable arms but only 88 index stubs | NOP lacks its expected per-case index file; no runtime gap |
| RT compiler wrapper | All 13 engine option fields available | Five advanced fields not exposed | Narrower embedder API |
| Identification globals | C defines `lua_ident` and `luau_ident` | No Rust twins found | Non-behavioral symbol/identification omission |

## Version and release markers

- Every vendored crate declares package version `0.1.8`; for example [luaur-vm Cargo.toml](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/Cargo.toml:12).
- Every `.cargo_vcs_info.json` records luaur commit `f0eac7f7cce691d0cdb0b93c3eef9d599f71d739`; for example [luaur-vm metadata](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/.cargo_vcs_info.json:1).
- The Nuxie provenance documents say “0.724-era” / `8f33df9`; for example [compiler provenance](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-compiler-0.1.8/NUXIE_PROVENANCE.md:9).
- The runtime `_VERSION` global is the bare string `"Luau"` in both C (`8f33df91:VM/src/lbaselib.cpp:467-476`) and Rust ([luaopen_base.rs](/Users/levi/dev/worktrees/nuxie-luau-fork/vendor/luaur-vm-0.1.8/src/functions/luaopen_base.rs:127)).
- No numeric Luau release number or `8f33df91` is embedded in executable Rust source.
- C’s unused identification strings `lua_ident` and `luau_ident` at `8f33df91:VM/src/lapi.cpp:42-47` have no Rust twins.

## Anchors not fully resolvable

- The published crates do not contain the upstream luaur README—the Cargo manifests say `readme = false`. The README’s `8f33df9` claim can therefore only be corroborated through the Nuxie provenance files, not re-read from the vendored package.
- The external pinned Rive C++ host’s flag initialization is not present in the Luau repository. This report distinguishes the raw library defaults, Luau CLI defaults, and `luaur-rt` defaults; it cannot infer an additional host override outside those trees.
- No requested source anchor remained unresolved. No pre-0.724 matching release or commit could be assigned to the discrepancies because they are local translation choices/omissions, not recognizable older Luau implementations.

No files were written or edited.