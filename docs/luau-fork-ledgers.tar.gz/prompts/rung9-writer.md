# Writer lane: luau-fork rung 9 (official 0.732 -> rive_0_732 tip 86eb0096)

Production writer porting the RIVE FORK PATCH SET — the final rung that makes
the vendored engine match what the pinned rive C++ runtime actually embeds.
Read `docs/luau-fork.md`, then `.luau-fork-work/prompts/preamble.md`, then
the binding ledger `.luau-fork-work/inventory/job9.md`. C-side diff:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff decb2d05..origin/rive_0_732 -- VM Compiler Ast Common Config Require Bytecode Inliner`

Rungs 1-8 are landed. Commit prefix:
`luau-fork rung9: <symbol> (<c-file>) [decb2d05..86eb0096]`; plain commits,
no trailers; row-by-row protocol and focused gates identical to prior rungs.

## Rung-specific adjudications (binding)

1. **RIVE_LUAU is baked ON.** C guards several rows with `#ifdef RIVE_LUAU`;
   the pinned runtime defines it, and Nuxie is exclusively the rive build.
   Do not introduce a Rust cfg: hardwire the RIVE_LUAU=ON side exactly
   (R11 `luaL_where` rive format with level-0 retry and `":: "` fallback;
   R12-R15 remove `writestring`/`luaB_print`/`luaB_newproxy` and their
   base_funcs registrations — delete or unwire following luaur's idiom,
   no dead imports; R26 `pusherror` FINAL TIP semantics: full raw source
   for Lua frames, `":: message"` for non-Lua — port the tip state
   `318d4752`, NOT the intermediate `8ebb53b8` message-only form).
   Record the bake in each affected crate's NUXIE_PATCH.md rung entry.
2. **Fast-call table (R25) ports the DIFF, not the C base state.** Our
   baseline deliberately has all 256 slots `luauF_missing` (documented
   divergence 1). This rung wires ONLY what the diff adds/changes:
   `luauF_fround` at 243, missing at 244, the 11 Vector entries at 245-255
   (reusing the EXISTING translated `luau_f_vectordot`/`vectormagnitude`/
   `vectorlerp` twins where C reuses upstream functions), padding through
   242 stays `luauF_missing` (where C has real upstream builtins — that
   remaining gap IS divergence 1, do not widen or narrow it further).
   Add the 256-entry assertion twin.
3. **Builtin ABI (R06-R09):** `LBF_RIVE_FROUND=243`, reserved 244, Vector
   block 245-255 with EXACT discriminants; `getBuiltinFunctionId`
   recognition (case-sensitive names; `Vector.xy` maps to existing
   `LBF_VECTOR`); `getBuiltinInfo` arities (`origin` 0->1, scale/lerp 3->1,
   all `Flag_NoneSafe`); type-map visitor results (`Vector.cross` is
   scalar 2D perp-dot). One atomic group with the new fastcall functions
   (R16-R24). Numeric fidelity notes are binding: `fround` must round-trip
   number->f32->f64 bit-for-bit in BOTH the fastcall and the `math_fround`
   library fallback (R27/R28, registered after `frexp`);
   `luauF_rivevectornormalize` keeps zero-vectors zero via inverse length
   1 (do NOT reuse upstream normalize, which divides by zero);
   scale-and-add/sub preserve per-component operation order (no fused
   contraction — use explicit `a + b * s` per component as written).
4. **`lua_pushvector2` (R10) preserves the stale-z quirk.** C writes only
   `v[0]`, `v[1]`, and the tag — the z bytes of the stack slot keep their
   previous contents, and three-component fast functions later read that
   stale z. Mirror exactly: write x, y, tag, increment top; NO z write, NO
   ensure_stack. Add a comment citing the C behavior (this is a faithful
   quirk, not a bug to fix).
5. **`LBC_VERSION_TARGET` 9 -> 7 (R05):** unconditional, leaving MAX at 13.
   This is the pinned-runtime compatibility override; verify the
   version-selection ladder still returns 12/11/10 for the dark gates and
   7 otherwise.
6. **Lexeme capture (R01-R04):** unconditional; both parse-result
   construction paths updated; captures NOT gated on `captureComments`.
7. R29 is comment-only (the unconditional `udatadirectfields` init landed
   at rung 1) — verify and record as no-op.

Deferred rows -> `.luau-fork-work/rung9-blocked.md`; no-ops ->
`.luau-fork-work/rung9-noop.md`. End: NUXIE_PATCH.md rung entries ("Ported
rive_0_732 fork patch set (decb2d05..86eb0096)"), then one full
`cargo test -p nuxie --features scripting`; fix forward only your own rows.
Final message: dispositions, commits, gates, surprises.

Do not touch: workspace `Cargo.toml`, `Cargo.lock`, `docs/`, `corpus.toml`,
crates outside `vendor/luaur-*`, `NUXIE_PROVENANCE.md`, or
`.luau-fork-work/` beyond the two report files.
