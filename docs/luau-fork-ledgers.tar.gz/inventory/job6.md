# Rung inventory: official 0.729 → 0.730

- Diff range: `6e9b580e..e8ae48c4`
- Scoped files changed: 23
- Total hunks: **78** (counted with the command’s default three context lines)
- Exact inventory command:

```sh
git -C /Users/levi/dev/oss/luigi-rosso-luau diff 6e9b580e..e8ae48c4 -- VM Compiler Ast Common Config Require Bytecode Inliner
```

Hunk references below are file-local, top-to-bottom, such as `DenseHash2#4`. A shared reference means one hunk changes several related symbols; it is counted once in completeness accounting.

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Ast/include/Luau/Ast.h` | `AstStatLocalFunction` constructor declaration | `Ast.h#1`: declaration is reformatted from multiline to one line. Signature and five parameters are unchanged. | None. | `vendor/luaur-ast-0.1.8/src/records/ast_stat_local_function.rs`; `vendor/luaur-ast-0.1.8/src/methods/ast_stat_local_function_ast_stat_local_function.rs` | ENGINE | Formatting-only in this rung. Rust still lacks the earlier-rung `constKeywordBegin` field/parameter; see dependencies. |
| `Ast/src/Ast.cpp` | `AstStatLocalFunction::AstStatLocalFunction` | `Ast.cpp#1`: definition signature is collapsed to one line; initializer/body unchanged. | None. | `vendor/luaur-ast-0.1.8/src/methods/ast_stat_local_function_ast_stat_local_function.rs` | ENGINE | Formatting-only here, but the Rust twin still needs the earlier five-argument constructor context. |
| `Ast/src/Parser.cpp` | `LuauNoDuplicateBinaryPrefix`, `LuauTrackPrefixLocal` declarations | `Parser#1`: swaps declaration order only. Neither flag is added, removed, or default-flipped. | Both `LUAU_FASTFLAGVARIABLE`, hence default OFF; no guarded behavior changes in this hunk. | NONE-untranslated | ENGINE | No semantic port required for the reorder. The declarations are absent from the current 0.724 Rust flag registry. |
| `Ast/src/Parser.cpp` | `Parser::parseLocal` | `Parser#2`: formats the `CstStatLocal` allocation/assignment onto one line. Arguments and CST behavior are unchanged. | Executed only when `options.storeCstData`; not an FFlag. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_local.rs` | ENGINE | Formatting-only. Depends on earlier CST/const-position changes. |
| `Bytecode/include/Luau/BytecodeValidation.h` | file prologue / include ordering | `BytecodeValidation#1`: moves `#pragma once` before includes and adds another `<algorithm>` include, leaving two identical `<algorithm>` includes. | None. | NONE-untranslated | OUT-OF-SCOPE | C++ header/build hygiene only; no Rust behavior. File itself arrived in 0.728. |
| `Bytecode/include/Luau/Sccp.h` | SCCP header dependency set | `Sccp.h#1`: replaces `unordered_map`/`unordered_set` includes with `Luau/DenseHash2.h`. | None. | NONE-untranslated | ENGINE | Makes SCCP depend on the 0.729 `DenseHash2` facility, which has no current Rust translation. |
| `Bytecode/include/Luau/Sccp.h` | `VmConstOps::asNumber` | `Sccp.h#2`: adds a pure virtual numeric extractor for arithmetic VM constants. | None. | NONE-new | ENGINE | Every `VmConstOps` implementation must now supply the method. |
| `Bytecode/include/Luau/Sccp.h`; `Bytecode/src/Sccp.cpp` | `BcVmConstImpl::asNumber` | `Sccp.h#3`, shared `Sccp.cpp#1`: adds the override; asserts `BcVmConstKind::Number` and returns `valueNumber`. | None. | NONE-new | ENGINE | The assertion is part of the contract and should be preserved. |
| `Bytecode/include/Luau/Sccp.h` | `OpConstness` | `Sccp.h#4`: changes the alias from `std::unordered_map<BcOp,…>` to `DenseHashMap2<BcOp,…>`. | None. | NONE-untranslated | ENGINE | Iteration/order and missing-key insertion behavior must match DenseHash2, not Rust’s standard `HashMap`. |
| `Bytecode/include/Luau/Sccp.h`; `Bytecode/src/Sccp.cpp` | `SccpInterpreter` and its constructor/evaluation methods | `Sccp.h#5`, shared `Sccp.cpp#1`: introduces the interpreter and `evaluateCondition`, `evaluateComparisonCondition`, `evaluateXeqkCondition`, `evaluateArith`, and `evaluate`. It folds loads, moves, integer/VM arithmetic, comparisons, and conditional jumps into the SCCP lattice. | None. | NONE-new | ENGINE | High-risk optimizer logic. Preserve Lua modulo/floor-division semantics, 16-bit `LOADN` range restriction, negated-branch handling, and `Undetermined` vs `NotAConstant`. The `JUMPXEQKB` immediate-boolean branch calls `valConst.vmConst.value()` even though the lattice is immediate; port faithfully and flag for later upstream comparison. |
| `Bytecode/include/Luau/Sccp.h` | `Sccp<VmConst>` and inline methods | `Sccp.h#5`: introduces the SCCP driver, worklists, reachability map, propagation, constant rewriting, dead-edge/producer removal, phi simplification, block-use repair, and arithmetic-to-K conversion. Inline methods are `makeBoolImm`, `getFallthrough`, `conditionalTargets`, `jumpTargets`, `visitPhi`, `visitInst`, `propagate`, `makeConstantOp`, `replaceOperand`, `replacePhiOperand`, `isLoadInst`, `rewriteToLoad`, `eraseOp`, `eraseUse`, `removeDeadEdges`, `replaceUses`, `simplifyPhis`, `updateBlockUses`, `arithToKOpcode`, `isPureProducer`, `registerOf`, `eraseDeadProducer`, `arithToK`, and `rewrite`. | None. | NONE-new | ENGINE | Very high-risk graph mutation. Preserve use-list maintenance, entry/exit liveness, fallthrough conversion, REF-capture invalidation, and operand ordering for `SUBRK`/`DIVRK`. |
| `Bytecode/include/Luau/Sccp.h` | `foldConstants(BcFunction<VmConst>&, VmConstOps&)` | `Sccp.h#5`: adds the template entry point; constructs `Sccp`, then calls `propagate()` and `rewrite()`. | None. | NONE-new | ENGINE | Depends on the entire 0.729 bytecode graph/SCCP substrate and the new driver above. |
| `Bytecode/src/BytecodeBuilder.cpp` | `LuauCompileUdataDirect` | `BytecodeBuilder#1`: removes the flag definition. | Removed flag was default OFF. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Remove the Rust registry/setter only after all consumers are ungated. |
| `Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::getVersion` | `BytecodeBuilder#2`: removes flag-dependent returns for userdata-direct version 9 and integer-constant version 8. The unguarded target is now version 9. | Removed `LuauCompileUdataDirect` default OFF and `LuauIntegerType2` version gate; with remaining default-OFF flags, new default returns 9. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_get_version.rs` | ENGINE | Wire-format behavior changes for every default compilation. Must land with `LBC_VERSION_TARGET=9` and earlier version-7/max-12 work. |
| `Bytecode/src/BytecodeBuilder.cpp` | `VCONST` macro in `BytecodeBuilder::validateInstructions` | `BytecodeBuilder#3`: reformats the ternary macro over multiple lines; expression unchanged. | `LuauVirtualBcBuilder=false` by default, so the normal constants-vector assertion executes. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_validate_instructions.rs` | ENGINE | Formatting-only. |
| `Common/include/Luau/Bytecode.h` | `LuauBytecodeTag::LBC_VERSION_TARGET` | `Bytecode.h#1`: changes default emitted bytecode version from 7 to 9. Min remains 3, max remains 12. | None; unconditional constant change. | `vendor/luaur-common-0.1.8/src/enums/luau_bytecode_tag.rs` | ENGINE | Serialization compatibility boundary. Current Rust value is 6, so intermediate rung changes must land first. |
| `Common/include/Luau/DenseHash2.h` | `detail::countTrailingZeroes` | `DenseHash2#1`: restricts the MSVC intrinsic path to `_M_X64`; fixes fallback references from nonexistent `x` to `word`. | None. | NONE-untranslated | ENGINE | Fixes compilation/correctness on non-x64 MSVC and generic fallback targets. |
| `Common/include/Luau/DenseHash2.h` | `BitSet::iterator`, `BitSet::begin`, `BitSet::end` | `DenseHash2#2`: adds occupied-bit iteration that skips zero words and yields set-bit bucket indices. | None. | NONE-new | ENGINE | Iterator snapshots the current word; any set mutation invalidates it. Correct end-state comparison matters. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashTable2::DenseHashTable2(size_t)` | `DenseHash2#3`: stops value-constructing every bucket with `ItemInterface::fill`; only raw storage and metadata are initialized. Casts trailing-zero count to `uint8_t`. | None. | NONE-untranslated | ENGINE | Fundamental lifetime change: only occupied buckets may contain live `Item`s after this rung. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashTable2` copy constructor | `DenseHash2#4-#5`: starts with an empty occupancy bitset, copy-constructs only occupied buckets, marks them as initialized for exception cleanup, then installs full capacity. | None. | NONE-untranslated | ENGINE | Exception safety and partial-construction cleanup are essential; do not copy uninitialized buckets. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashTable2::clear` | `DenseHash2#6`: explicitly destroys occupied items and clears the bitset instead of destroying/refilling every capacity slot. | None. | NONE-untranslated | ENGINE | Must drop each live item exactly once. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashTable2::destroy` | `DenseHash2#7`: destroys occupied items only before freeing raw storage. | None. | NONE-untranslated | ENGINE | Same lifetime invariant as `clear`; scanning capacity would touch uninitialized memory. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashTable2::hash` | `DenseHash2#8`: asserts `hashShift > 32` and explicitly casts the shifted 64-bit product to `size_t`. | None. | NONE-untranslated | ENGINE | Preserve the multiplicative hash and power-of-two capacity invariant. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashTable2::grow` | `DenseHash2#9-#10`: removes stray whitespace, iterates occupied buckets through `BitSet`, and placement-move-constructs directly into destination buckets without default-constructing through `insert_unsafe`. | None. | NONE-untranslated | ENGINE | Must update destination occupancy/count before construction consistently with exception/lifetime rules. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashTable2::getBucket` | `DenseHash2#11`: adds braces around the empty-bucket return; behavior unchanged. | None. | NONE-untranslated | ENGINE | Formatting-only. |
| `Common/include/Luau/DenseHash2.h` | `DenseHashTable2::erase` | `DenseHash2#12`: back-shift deletion now placement-move-constructs into empty slots and explicitly destroys the final removed item. | None. | NONE-untranslated | ENGINE | Overlapping move/lifetime handling is delicate; occupancy bits must describe live objects at every step. |
| `Common/include/Luau/DenseHash2.h` | `ItemInterfaceSet2` lifetime hooks | `DenseHash2#13`: `setKey` now placement-constructs the key; obsolete whole-array `fill` and `destroy` hooks are removed. | None. | NONE-untranslated | ENGINE | Required by the raw/uninitialized bucket model. |
| `Common/include/Luau/DenseHash2.h` | `ItemInterfaceMap2` lifetime hooks | `DenseHash2#14`: `setKey` placement-constructs both key and default value; whole-array `fill`/`destroy` hooks are removed. | None. | NONE-untranslated | ENGINE | Value construction must occur exactly once on insertion. |
| `Compiler/src/Compiler.cpp` | `LuauCompileInlineTableFunctions` | `Compiler#1`: removes the flag definition. | Removed flag was default OFF. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Rust registry/setter becomes obsolete once all guarded branches below are removed. |
| `Compiler/src/Compiler.cpp` | `Compiler::getFunctionExpr` | `Compiler#2-#3`: table-property function lookup and `AstExprInstantiate` unwrapping become unconditional instead of requiring `LuauCompileInlineTableFunctions`. | Removed flag default was OFF; new code always executes its former ON behavior. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_get_function_expr.rs` | ENGINE | Changes which calls are eligible for compile-time inlining. Preserve recursive expression unwrapping. |
| `Compiler/src/Compiler.cpp` | `Compiler::getExprLocal` | `Compiler#4`: deletes the old manual group/type-assertion unwrapping branch and always calls `unwrapExprOfType<AstExprLocal>`. | Removed flag default was OFF; former ON implementation is now unconditional. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_get_expr_local.rs` | ENGINE | Should be behaviorally equivalent for prior wrappers while also handling the full generic unwrap set. |
| `Compiler/src/ConstantFolding.cpp` | `LuauCompileNewTableMutationTracker` | `ConstantFolding#1`: removes the flag definition. | Removed flag was default OFF. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Remove only after deleting the deprecated tracker and making the new tracker unconditional. |
| `Compiler/src/ConstantFolding.cpp` | `TableMutationTracker_DEPRECATED` and member visitors | `ConstantFolding#2`: deletes the complete old constant-table/mutation analysis, including `isNonTableConstant`, `isConstantTableLiteral`, `couldBeTableReference`, `observeMutations`, and all `visit` overloads. | This was the OFF path of `LuauCompileNewTableMutationTracker`; the flag default was OFF, but the entire path is now removed. | `vendor/luaur-compiler-0.1.8/src/records/table_mutation_tracker_deprecated.rs` | ENGINE | Large deletion. Remove its separate method modules/imports/exports too; ensure no downstream fork-only caller still selects it. |
| `Compiler/src/ConstantFolding.cpp` | `ConstantVisitor::visit(AstStatLocal*)` | `ConstantFolding#3`: wraps the string-key/value eligibility condition differently; expression unchanged. | None. | `vendor/luaur-compiler-0.1.8/src/records/constant_visitor.rs` | ENGINE | Formatting-only. |
| `Compiler/src/ConstantFolding.cpp` | `buildTableConstantMap` | `ConstantFolding#4`: always runs the new `TableMutationTracker`, then records unwritten table-literal locals that did not escape. Deletes the deprecated fallback. | Removed flag default was OFF; former ON path becomes unconditional. | `vendor/luaur-compiler-0.1.8/src/functions/build_table_constant_map.rs` | ENGINE | Material default behavior change. Escaped-table detection must be complete before constant-table folding is trusted. |
| `Compiler/src/ConstantFolding.cpp` | `foldConstants` | `ConstantFolding#5`: formats `ConstantVisitor` aggregate initialization onto one line; arguments/order unchanged. | None. | `vendor/luaur-compiler-0.1.8/src/functions/fold_constants.rs` | ENGINE | Formatting-only in this hunk. |
| `Compiler/src/ConstantFolding.h` | `TableConstantKind::ConstantOther` | `ConstantFolding.h#1`: deletes the enum member used only by the deprecated mutation tracker. | Removal follows retirement of `LuauCompileNewTableMutationTracker`. | `vendor/luaur-compiler-0.1.8/src/enums/table_constant_kind.rs` | ENGINE | Remove all stale Rust matches/references, especially deprecated tracker modules. |
| `Inliner/src/JitInliner.cpp` | `createInlinedProto` | `JitInliner#1`: removes trailing whitespace only. | None. | NONE-untranslated | OUT-OF-SCOPE | Explicitly JIT/Inliner-only and semantically empty. |
| `VM/src/lapi.cpp` | `lua_getuserdataname` | `lapi#1`: converts CRLF-tainted lines to normal line endings; statements unchanged. | None. | NONE-untranslated | RT-API | Public API symbol, but this rung requires no semantic Rust change. Current Rust does not translate the function. |
| `VM/src/laux.cpp` | `luaL_checkudatatagged` | `laux#1`: line-ending-only change on the `lua_getuserdataname` call. | None. | NONE-untranslated | RT-API | Public auxiliary API; no semantic port for this hunk. Current Rust lacks the function. |
| `VM/src/lbuiltins.cpp` | `LuauMathRoundNegZero` | `lbuiltins#1`: adds a new static fast flag. | `LUAU_FASTFLAGVARIABLE`, default OFF. | NONE-new | ENGINE | New correction is shipped dark by default. |
| `VM/src/lbuiltins.cpp` | `luauF_round_sse41` | `lbuiltins#2`: ON path derives the offset sign with SSE masks, preserving negative zero; OFF path retains scalar `a1 < 0` selection. Argument/result checks are duplicated in both branches. | `LuauMathRoundNegZero=false` by default, so release-default execution uses the old scalar path. Also compile-time `LUAU_TARGET_SSE41`. | `vendor/luaur-vm-0.1.8/src/functions/luau_f_round_sse_41.rs` | ENGINE | Preserve exact `prevfloat(0.5)` constant, sign-bit behavior, `_MM_FROUND_NO_EXC`, and fallback return `-1`. |
| `VM/src/lclass.cpp`; `VM/src/lclass.h` | `luaR_newclass` | `lclass.cpp#1-#2`, `lclass.h#1`: instance/static member counts and initialization loop index change from `int` to `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/functions/lua_r_newclass.rs` | ENGINE | Rust signature currently uses `i32`; update together with `LuauClass` fields and callers. ABI width stays 32 bits, signed semantics do not. |
| `VM/src/lclass.cpp` | `luaR_addclassmember` | `lclass.cpp#3`: converts numeric member offset directly to `uint32_t` and removes `ttisnumber` assertion. | None. | `vendor/luaur-vm-0.1.8/src/functions/lua_r_addclassmember.rs` | ENGINE | Deliberately trusts table contents more; a negative/invalid number now becomes an unsigned value caught only by bounds checking. |
| `VM/src/lclass.cpp` | `luaR_createobject` | `lclass.cpp#4-#5`: both instance-member initialization loops use `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/functions/lua_r_createobject.rs` | ENGINE | Coordinate with unsigned class/object counts. |
| `VM/src/lclass.h` | `luaR_checkoffsetinbounds` | `lclass.h#2`: removes signed nonnegative check; bounds test becomes only `offset < numberofallmembers`. | None. | `vendor/luaur-vm-0.1.8/src/macros/lua_r_checkoffsetinbounds.rs` | ENGINE | Safe only once callers and stored counts use unsigned offsets consistently. |
| `VM/src/lgc.cpp` | `LuauGcMarkUdataAccess` | `lgc#1`: adds dynamic fast flag with explicit default `false`. | DFFlag default OFF. | NONE-new | ENGINE | Controls a GC root-marking fix and can be changed dynamically. |
| `VM/src/lgc.cpp` | `traverseclass` | `lgc#2`: both class-member loops use `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/functions/traverseclass.rs` | ENGINE | Avoid signed subtraction/comparison after class fields become unsigned. |
| `VM/src/lgc.cpp` | `traverseobject` | `lgc#3`: object-member traversal index changes to `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/functions/traverseobject.rs` | ENGINE | Must match `LuauObject::numberofmembers`. |
| `VM/src/lgc.cpp` | `markudatadirectaccess` | `lgc#4`: new helper marks `indextm`, `newindextm`, and `namecalltm` for every internal userdata tag. | Asserts `LuauGcMarkUdataAccess` is ON; the new flag defaults OFF. | NONE-new | ENGINE | GC correctness fix. Must not be called with the flag OFF and must cover all `UTAG_INTERNAL_LIMIT` entries. |
| `VM/src/lgc.cpp` | `markroot` | `lgc#5`: when userdata-direct access is enabled, delegates to the new helper if the GC fix flag is ON; otherwise retains the inline old loop. | `LuauUdataDirectAccess6=false` and `LuauGcMarkUdataAccess=false` by default. Thus default execution skips the outer block; with userdata-direct enabled but fix OFF, it uses the old loop. | `vendor/luaur-vm-0.1.8/src/functions/markroot.rs` | ENGINE | Preserve the two-flag nesting; collapsing it could change staged rollout behavior. |
| `VM/src/lgc.cpp` | `atomic` | `lgc#6`: re-marks userdata direct-access callbacks during atomic GC when the new fix is ON. | `LuauGcMarkUdataAccess=false` by default, so release-default skips this new call. | `vendor/luaur-vm-0.1.8/src/functions/atomic.rs` | ENGINE | This second marking pass is the core protection against mutations between root marking and atomic. |
| `VM/src/lgcdebug.cpp` | `validateclass` | `lgcdebug#1`: class-member validation loop uses `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/functions/validateclass.rs` | ENGINE | Debug validation must use the same unsigned model as runtime traversal. |
| `VM/src/lgcdebug.cpp` | `validateobject` | `lgcdebug#2`: object-member validation loop uses `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/functions/validateobject.rs` | ENGINE | Same unsigned-width coordination requirement. |
| `VM/src/lgcdebug.cpp` | `luaC_validate` | `lgcdebug#3`: validates liveness of all three userdata-direct callbacks and any direct-field table for every internal tag. | No new flag guard: debug validation performs these checks unconditionally. | `vendor/luaur-vm-0.1.8/src/functions/lua_c_validate.rs` | ENGINE | Unlike marking, validation is not gated by `LuauGcMarkUdataAccess`; preserve this distinction. |
| `VM/src/lgcdebug.cpp` | `dumpclass` | `lgcdebug#4`: class member-name loop uses `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/functions/dumpclass.rs` | ENGINE | Diagnostic-only execution, but tied to the record type change. |
| `VM/src/lgcdebug.cpp` | `enumclass` | `lgcdebug#5-#6`: static-member count and both static/member-name loops change from `int` to `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/functions/enumclass.rs` | ENGINE | Keep unsigned subtraction and array indexing consistent. |
| `VM/src/lgcdebug.cpp` | `enumobject` | `lgcdebug#7`: instance-member enumeration loop uses `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/functions/enumobject.rs` | ENGINE | Mechanical dependency on unsigned class counts. |
| `VM/src/lobject.h` | `LuauClass` | `lobject#1-#2`: `numberofinstancemembers` and `numberofallmembers` change from `int` to `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/records/luau_class.rs` | ENGINE | Central record-layout/type change; every comparison, subtraction, loop, constructor, and lookup must move together. |
| `VM/src/lobject.h` | `LuauObject` | `lobject#3`: `numberofmembers` changes from `int` to `uint32_t`. | None. | `vendor/luaur-vm-0.1.8/src/records/luau_object.rs` | ENGINE | Coordinate allocation/free and GC traversal. |
| `VM/src/lobject.h` | `lmod` | `lobject#4`: inserts whitespace around `(size) - 1`; macro behavior unchanged. | None. | `vendor/luaur-vm-0.1.8/src/macros/lmod.rs` | ENGINE | Formatting-only. |
| `VM/src/lobject.h` | `ceillog2` | `lobject#5`: inserts whitespace around `(x) - 1`; macro behavior unchanged. | None. | `vendor/luaur-vm-0.1.8/src/macros/ceillog_2.rs` | ENGINE | Formatting-only. |
| `VM/src/lvmexecute.cpp` | `VM_ASSERT_PC` | `lvmexecute#1`: reformats the assertion macro over two lines. | Expression uses `LuauCIProto=false` by default, selecting `cl->l.p`; behavior unchanged. | NONE-untranslated | ENGINE | Formatting-only; current Rust interpreter does not translate this debug macro. |
| `VM/src/lvmexecute.cpp` | `luau_callhook` | `lvmexecute#2`: reformats `ar.currentline` assignment over two lines. | `LuauCIProto=false` by default, selecting the closure proto. | `vendor/luaur-vm-0.1.8/src/functions/luau_callhook.rs` | ENGINE | Formatting-only. |
| `VM/src/lvmexecute.cpp` | `LOP_GETTABLEKS` interpreter case | `lvmexecute#3`: class-member slow path converts offset to `uint32_t` and removes the number assertion before lookup/cache patching. | `DebugLuauUserDefinedClassesRuntime=false` by default, so the changed class path is dormant. | `vendor/luaur-vm-0.1.8/src/functions/luau_execute.rs` | ENGINE | Rust currently uses `i32` and asserts numeric type. Coordinate with unsigned records/macros; cache field is byte-sized. |
| `VM/src/lvmexecute.cpp` | `LOP_NAMECALL` interpreter case | `lvmexecute#4-#5`: cached slot becomes `uint8_t`; slow member offset becomes `uint32_t` and loses the number assertion. | `DebugLuauUserDefinedClassesRuntime=false` by default, so default execution does not enter this path. | `vendor/luaur-vm-0.1.8/src/functions/luau_execute.rs` | ENGINE | Preserve slot-vs-full-offset distinction and patch truncation behavior. Rust currently represents both as signed values in this arm. |
| `VM/src/lvmexecute.cpp` | `LOP_DUPCLOSURE` interpreter case | `lvmexecute#6`: formats the conditional closure allocation over two lines; behavior unchanged. | `LuauCIProto=false` by default, selecting `kcl->l.p`. | `vendor/luaur-vm-0.1.8/src/functions/luau_execute.rs` | ENGINE | Formatting-only. |
| `VM/src/lvmutils.cpp` | `luaV_gettable` | `lvmutils#1-#2`: object/class lookup offsets become `uint32_t`; number and nonnegative assertions are removed, retaining only upper-bound validation for class-object access. | Class-object behavior is reached through the user-defined-class runtime feature, whose controlling flag defaults OFF; no guard is local to this function. | `vendor/luaur-vm-0.1.8/src/functions/lua_v_gettable.rs` | ENGINE | Match the intended trust boundary exactly; do not retain signed checks while other paths become unsigned. |
| `VM/src/lvmutils.cpp` | `luaV_settable` | `lvmutils#3`: object member offset becomes `uint32_t`; nonnegative assertion is removed while upper-bound and instance/static checks remain. | No local FFlag guard. | `vendor/luaur-vm-0.1.8/src/functions/lua_v_settable.rs` | ENGINE | Coordinate with `luaR_checkoffsetinbounds`, class fields, and interpreter paths. |

## FFlag / DFFlag / DFInt inventory

Defaults below are the compiled defaults from `LUAU_FASTFLAGVARIABLE` (`false`) and `LUAU_DYNAMIC_FASTFLAGVARIABLE(..., false)`, before any host-side override.

| flag | rung action | gated behavior | release-default path after this rung |
|---|---|---|---|
| `FFlag::LuauCompileUdataDirect` | Removed | Previously raised compiler bytecode version to 9 when ON. | No flag remains; target version 9 is unconditional. This adopts the former ON version result. |
| `FFlag::LuauCompileInlineTableFunctions` | Removed | Enabled table-property/instantiated function discovery and generic local-expression unwrapping for inlining. | No flag remains; former ON behavior is unconditional. |
| `FFlag::LuauCompileNewTableMutationTracker` | Removed | Selected the escape-based `TableMutationTracker` instead of `TableMutationTracker_DEPRECATED`. | No flag remains; former ON tracker is unconditional, and the OFF implementation is deleted. |
| `FFlag::LuauMathRoundNegZero` | Added, default `false` | ON uses sign-bit SSE arithmetic so rounding negative values near zero preserves `-0.0`; OFF retains scalar sign comparison. | **OFF path** executes. |
| `DFFlag::LuauGcMarkUdataAccess` | Added, default `false` | ON factors userdata-direct callback marking into a helper and repeats it during atomic GC. | **OFF path** executes; no atomic re-mark. If `LuauUdataDirectAccess6` is enabled separately, root marking uses the old inline loop. |

Additional gate changes that are not additions/removals/flips:

- `FFlag::LuauIntegerType2` still exists and defaults OFF, but `BytecodeBuilder::getVersion` no longer consults it. Version 8 is subsumed by unconditional target 9.
- `LuauTrackPrefixLocal` and `LuauNoDuplicateBinaryPrefix` are only reordered; neither definition nor default changes.
- No FFlag/DFFlag value is flipped in place.
- No DFInt is added, removed, or changed in this scoped diff.

## Completeness accounting

Unique default-context hunks by file:

| file | hunks |
|---|---:|
| `Ast/include/Luau/Ast.h` | 1 |
| `Ast/src/Ast.cpp` | 1 |
| `Ast/src/Parser.cpp` | 2 |
| `Bytecode/include/Luau/BytecodeValidation.h` | 1 |
| `Bytecode/include/Luau/Sccp.h` | 5 |
| `Bytecode/src/BytecodeBuilder.cpp` | 3 |
| `Bytecode/src/Sccp.cpp` | 1 |
| `Common/include/Luau/Bytecode.h` | 1 |
| `Common/include/Luau/DenseHash2.h` | 14 |
| `Compiler/src/Compiler.cpp` | 4 |
| `Compiler/src/ConstantFolding.cpp` | 5 |
| `Compiler/src/ConstantFolding.h` | 1 |
| `Inliner/src/JitInliner.cpp` | 1 |
| `VM/src/lapi.cpp` | 1 |
| `VM/src/laux.cpp` | 1 |
| `VM/src/lbuiltins.cpp` | 2 |
| `VM/src/lclass.cpp` | 5 |
| `VM/src/lclass.h` | 2 |
| `VM/src/lgc.cpp` | 6 |
| `VM/src/lgcdebug.cpp` | 7 |
| `VM/src/lobject.h` | 5 |
| `VM/src/lvmexecute.cpp` | 6 |
| `VM/src/lvmutils.cpp` | 3 |
| **Total** | **78** |

All 78 identifiers are represented in the ledger. Shared SCCP and declaration/definition rows intentionally reuse a hunk identifier but count it only once.

- Hunks total: **78**
- Attributed: **78**
- Unresolved: **0**
- Ledger rows: **69**
- Rows by class: **ENGINE 65 / RT-API 2 / OUT-OF-SCOPE 2**

## Dependency notes

1. **0.727 AST const-position work must land first.** `AstStatLocalFunction` at the 0.729 side already has the fifth `Position constKeywordBegin` constructor argument and field. Current Rust has the correct twin paths but still has the older four-argument shape.

2. **0.726 and 0.729 bytecode-version work must precede the target-9 change.** Current Rust declares `LBC_VERSION_TARGET=6` and `LBC_VERSION_MAX=11`; the C diff base already has target 7 and max 12. Target 7 arrived in the 0.726 rung, and max 12 in 0.729.

3. **SCCP depends directly on the 0.729 rung.** `Bytecode/include/Luau/Sccp.h`, `Bytecode/src/Sccp.cpp`, and `Common/include/Luau/DenseHash2.h` were added in 0.729. The existing 0.729 symbols are marked `NONE-untranslated`; the interpreter/driver additions in this rung are `NONE-new`. The 0.729 graph/lattice/DenseHash2 foundation must be ported before this work compiles.

4. **`BytecodeValidation.h` arrived in 0.728.** Its 0.730 hunk is C++ include hygiene only, but any C++-header parity lane would need the earlier file first.

5. **Unsigned class changes form one atomic dependency cluster.** `LuauClass`, `LuauObject`, `luaR_newclass`, lookup macros, GC/debug loops, `luaV_gettable`/`luaV_settable`, and the `GETTABLEKS`/`NAMECALL` interpreter arms must change together. They do not depend on an unlanded enum value, but a partial port would create signed/unsigned mismatches and inconsistent bounds behavior.

6. **No new opcode or enum prerequisite is introduced by this rung’s SCCP evaluator.** It consumes existing `BcOpKind`, `BcBlockEdgeKind`, `LuauOpcode`, and `LOP_CMPPROTO` definitions; the missing prerequisite is the earlier SCCP/DenseHash2 implementation, not an opcode addition.