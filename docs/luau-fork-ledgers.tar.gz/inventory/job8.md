# Rung inventory: official Luau 0.731 → 0.732

**Diff range:** `f8ca77ac..decb2d05`  
**Sync commit:** `decb2d05 Sync to upstream/release/732 (#2605)`  
**Total hunks:** **266**

Exact scoped command:

```sh
git -C /Users/levi/dev/oss/luigi-rosso-luau diff f8ca77ac..decb2d05 -- VM Compiler Ast Common Config Require Bytecode Inliner
```

Hunks were counted from the same command with `--unified=0` by counting `^@@`. All paths shown as existing twins were checked on disk; 83 distinct paths were verified.

Conventions below:

- “default OFF” means `LUAU_FASTFLAGVARIABLE` constructs a static Boolean flag with `false`.
- “retired → ON” means the flag is deleted and its former flag-ON branch becomes unconditional, despite the old release default having selected OFF.
- `NONE-new` means the C/C++ symbol is introduced by this rung.
- `NONE-untranslated` means it existed at `f8ca77ac`, but no current vendored Rust twin exists.

## AST and parser

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Ast/include/Luau/Ast.h` | `AstStatClass` | Adds nullable `super: AstExpr*` before members and changes constructor signature. | Effective `DebugLuauUserDefinedClasses`; default OFF. | `vendor/luaur-ast-0.1.8/src/records/ast_stat_class.rs` | ENGINE | ABI/layout change; compiler and visitor must agree on field position. |
| `Ast/src/Ast.cpp` | `AstStatClass::AstStatClass` | Accepts and stores the superclass expression. | Effective user-classes ON; default OFF. | `vendor/luaur-ast-0.1.8/src/methods/ast_stat_class_ast_stat_class.rs` | ENGINE | Depends on the record-field addition. |
| `Ast/src/Ast.cpp` | `AstStatClass::visit` | Visits `super` before class members when present. | Asserts user-classes ON; default OFF. | `vendor/luaur-ast-0.1.8/src/methods/ast_stat_class_visit.rs` | ENGINE | Missing traversal would break value/type passes over superclass expressions. |
| `Ast/include/Luau/Parser.h`, `Ast/src/Parser.cpp` | `Parser::parseAttribute_DEPRECATED` | Deletes the legacy combined `@name`/`@[...]` parser. | `LuauCstAttr` retired → former ON path unconditional; old default OFF. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_attribute.rs` | ENGINE | Current Rust file contains the pre-split parser; the 0.726 CST-attribute split must precede this deletion. |
| `Ast/include/Luau/Parser.h`, `Ast/src/Parser.cpp` | `Parser::parseClassRefExpr` | New restricted superclass grammar: name, one `.name`, or one `[expr]` suffix. | Effective user-classes ON; default OFF. | NONE-new | ENGINE | Not a general prefix-expression parser; faithfully preserve the one-suffix restriction. |
| `Ast/src/Cst.cpp` | `CstAttr::CstAttr` | Removes the `LuauCstAttr` assertion. | Retired → former ON assumption; old default OFF. | NONE-untranslated | ENGINE | CST attribute records are absent from the current Rust baseline. |
| `Ast/src/Cst.cpp` | `CstParametrizedAttr::CstParametrizedAttr` | Removes the flag assertion. | Same. | NONE-untranslated | ENGINE | Depends on 0.726 CST-attribute records. |
| `Ast/src/Cst.cpp` | `CstAttrList::CstAttrList` | Removes the flag assertion. | Same. | NONE-untranslated | ENGINE | Depends on 0.726 CST-attribute records. |
| `Ast/src/Cst.cpp` | `CstStatFunction::CstStatFunction` | Removes the flag assertion from the attr-list-aware overload. | Same. | `vendor/luaur-ast-0.1.8/src/methods/cst_stat_function_cst_stat_function.rs` | ENGINE | Existing Rust twin is the older non-attr-list overload. |
| `Ast/src/Cst.cpp` | `CstStatLocalFunction::CstStatLocalFunction` | Removes the flag assertion from the attr-list-aware overload. | Same. | `vendor/luaur-ast-0.1.8/src/methods/cst_stat_local_function_cst_stat_local_function.rs` | ENGINE | Existing Rust twin lacks the earlier attr-list context. |
| `Ast/src/Cst.cpp`, `Ast/src/Parser.cpp`, `Ast/src/PrettyPrinter.cpp` | `LuauCstAttr` | Deletes declarations and all parser/printer branching; CST-aware behavior becomes unconditional. | Retired → ON; old release default executed OFF. | NONE-untranslated | ENGINE | This is a real default behavior flip, not dead-code cleanup relative to macro defaults. |
| `Ast/src/Parser.cpp` | `LuauExportValueSyntax` flag version | Changes metadata version 3 → 4. | Flag remains default OFF; version metadata does not enable it. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Rust intentionally keeps export syntax false; version metadata has no current twin mechanism. |
| `Ast/src/Parser.cpp` | `LuauTableEntriesDontNeedToMatchIndent` | Removes flag declaration and legacy indentation-matching recovery. | Retired → ON; old release default executed OFF. | `vendor/luaur-common-0.1.8/src/lib.rs` | ENGINE | Parser recovery now reports a missing comma regardless of next-entry column. |
| `Ast/src/Parser.cpp` | `Parser::parseFunctionStat` | Always computes start from CST-aware attributes and stores attr lists when supplied. | `LuauCstAttr` retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_function_stat.rs` | ENGINE | Depends on CST attr-list nodes from the earlier rung. |
| `Ast/src/Parser.cpp` | `Parser::parseAttrList` | Removes flag assertion; becomes the only `@[...]` parser. | Retired → ON. | NONE-untranslated | ENGINE | Must land with CST attribute records. |
| `Ast/src/Parser.cpp` | `Parser::parseAttribute` | Removes flag assertion; handles the single `@NAME` form. | Retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_attribute.rs` | ENGINE | Same current path also holds the old combined parser; sequencing matters. |
| `Ast/src/Parser.cpp` | `Parser::parseAttributes` | Removes nullable-CST assertion and flag branch; dispatches directly by lexeme type. | Retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_attributes.rs` | ENGINE | Callers now must supply CST collection where required. |
| `Ast/src/Parser.cpp` | `Parser::getAttributeStartLocation` | Removes flag assertion; CST-aware location selection is unconditional. | Retired → ON. | NONE-untranslated | ENGINE | Affects statement source spans and diagnostics. |
| `Ast/src/Parser.cpp` | `Parser::parseAttributeStat` | Always collects/passes CST attr lists and uses CST-aware start locations. | Retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_attribute_stat.rs` | ENGINE | Covers function, local, export, and const attributed statements. |
| `Ast/src/Parser.cpp` | `Parser::parseLocal` | Removes flag assertion and records attr-list CST whenever the pointer is present. | Retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_local.rs` | ENGINE | Earlier CST local-function record shape is prerequisite. |
| `Ast/src/Parser.cpp` | `Parser::parseClassStat` | Parses optional `extends <classref>` and supplies `super` to `AstStatClass`. | Effective user-classes ON; default OFF. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_class_stat.rs` | ENGINE | Couples directly to new AST field and `NEWCLASS` compilation. |
| `Ast/src/Parser.cpp` | `Parser::parseFunctionBody` | Removes CST flag assertion and always copies supplied attr lists into function CST. | `LuauCstAttr` retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_function_body.rs` | ENGINE | Source-preserving printer depends on this metadata. |
| `Ast/src/Parser.cpp` | `Parser::parseSimpleType` | Formatting-only reflow of `AstTypeReference` allocation. | None. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_simple_type.rs` | ENGINE | No semantic delta; hunk retained for completeness. |
| `Ast/src/Parser.cpp` | `Parser::parseAttributedFunction` | Always creates and passes CST attr-list storage. | `LuauCstAttr` retired → ON. | NONE-untranslated | ENGINE | Symbol was added after the Rust baseline. |
| `Ast/src/Parser.cpp` | `Parser::parseCallList` | Removes flag assertion; records close-paren position whenever output storage exists. | `LuauCstAttr` retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_call_list.rs` | ENGINE | Changes CST fidelity, not expression semantics. |
| `Ast/src/Parser.cpp` | `Parser::parseTableConstructor` | Deletes remembered indentation and accepts missing-comma recovery before any name/`[` entry. | Table-indent flag retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/parser_parse_table_constructor.rs` | ENGINE | Old default required matching columns; new behavior does not. |
| `Ast/src/PrettyPrinter.cpp` | `Printer::visualize(AstExpr&)` | Function expressions use CST attr lists directly when present; removes flag split and duplicate keyword-position fallback. | `LuauCstAttr` retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/printer_visualize_pretty_printer_alt_b.rs` | ENGINE | Structure-preserving output can shift around attributed functions. |
| `Ast/src/PrettyPrinter.cpp` | `Printer::visualize(AstStat&)` | Simplifies function/local-function CST handling and prints `class … extends <super>`. | CST retired → ON; class portion effective user-classes ON. | `vendor/luaur-ast-0.1.8/src/methods/printer_visualize_pretty_printer_alt_c.rs` | ENGINE | Must match parser’s restricted superclass expression shape. |
| `Ast/src/PrettyPrinter.cpp` | `Printer::visualizeAttribute` | Makes CST node handling unconditional and preserves parametrized-attribute punctuation. | `LuauCstAttr` retired → ON. | `vendor/luaur-ast-0.1.8/src/methods/printer_visualize_attribute.rs` | ENGINE | Fallback still emits plain `@name`. |
| `Ast/src/PrettyPrinter.cpp` | `Printer::visualizeAttributes` | Removes the flag assertion. | `LuauCstAttr` retired → ON. | NONE-untranslated | ENGINE | Requires the earlier CST attr-list implementation. |

## Bytecode and Common

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Bytecode/include/Luau/BytecodeBuilder.h` | `BytecodeBuilder::clearStringTable` | New public helper clearing builder string interning state. | None. | NONE-new | ENGINE | Reusing a builder after clearing can change constant/string IDs. |
| `Bytecode/include/Luau/BytecodeCallInliner.h` | `CallInliner::migrateInstructions` | Does not offset sealed `CALLFB` slots (`FbSlot == -1`). | Effective call-feedback/inliner use; static flags default OFF. | `vendor/luaur-bytecode-0.1.8/src/methods/call_inliner_migrate_instructions.rs` | ENGINE | Prevents `-1 + callerSlots` from reopening a sealed site. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcVmConstKind::ClassShape` | Adds graph constant kind for class shapes. | Effective user-classes ON; default OFF. | NONE-new | ENGINE | Must stay synchronized with union, equality, graph conversion, and class-shape vector. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcVmConst` | Adds `valueClassShape: uint32_t` union member. | Effective user-classes ON. | `vendor/luaur-bytecode-0.1.8/src/records/bc_vm_const.rs` | ENGINE | Rust union currently lacks the member. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcVmConst::operator==` | Compares class-shape indices for the new kind. | Effective user-classes ON. | NONE-untranslated | ENGINE | Rust type has no equivalent full `PartialEq` implementation. |
| `Bytecode/include/Luau/BytecodeGraph.h` | `BcFunction` | Adds `classShapes` beside `tableShapes`. | Effective user-classes ON. | `vendor/luaur-bytecode-0.1.8/src/records/bc_function.rs` | ENGINE | Default construction and graph round-trip must initialize/copy it. |
| `Bytecode/src/BytecodeBuilder.cpp` | `LuauBytecodeCostModel` flag version | Adds version metadata `2`. | Existing flag remains default OFF. | NONE-untranslated | ENGINE | Depends on 0.729 cost-model serialization. |
| `Bytecode/src/BytecodeBuilder.cpp` | `LuauCompileEmitVectorDouble` | New static flag, version 2, enabling bytecode v13 and 64-bit vector constants. | New default OFF; OFF retains float encoding. | NONE-new | ENGINE | ON changes serialized format and minimum reader capability. |
| `Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::finalize` | Accepts WIP class bytecode v100; writes per-function sizes for cost, double-vector, or class formats. | Cost/vector/class flags default OFF. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_finalize.rs` | ENGINE | Framing must match loader expectations for every selected version. |
| `Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::writeFunction` | Emits `VECTORD` only with vector-double ON; otherwise downcasts to float. Ensures empty feedback-vector framing and writes cost for all framed experimental versions. | Vector-double, cost, user-classes; all default OFF. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_write_function.rs` | ENGINE | High-risk wire-format change; removes the old `LuauEmitCallFeedback` special-case zero. |
| `Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::getVersion` | Precedence becomes classes→100, vector-double→13, cost→12, call-feedback→11, target→9. | All relevant flags default OFF, so default remains v9. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_get_version.rs` | ENGINE | Ordering matters when multiple experimental flags are enabled. |
| `Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::validateInstructions` | Validates `LOP_NEWCLASS`: target, optional superclass register, reserved C=0, and class-shape AUX. | Asserts user-classes ON; default OFF. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_validate_instructions.rs` | ENGINE | Opcode length is two words. |
| `Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::dumpConstant` | Double-vector constants print at double precision only when emitted as doubles; otherwise print float-rounded values. | Vector-double default OFF. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_dump_constant.rs` | ENGINE | Dump output intentionally mirrors wire precision. |
| `Bytecode/src/BytecodeBuilder.cpp` | `BytecodeBuilder::dumpInstruction` | Adds `NEWCLASS Rdst Rsuper Kshape` disassembly. | Effective user-classes ON. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_builder_dump_instruction.rs` | ENGINE | Must consume AUX to keep subsequent PCs aligned. |
| `Bytecode/src/BytecodeGraph.cpp` | `fromFunctionBytecode` | Parses class-shape constants into `BcVmConst::ClassShape` and `fn.classShapes`; also removes now-unused includes. | Asserts user-classes ON; default OFF. | `vendor/luaur-bytecode-0.1.8/src/functions/from_function_bytecode.rs` | ENGINE | Current Rust function has no class-shape graph round-trip. |
| `Bytecode/src/BytecodeGraph.cpp` | `toFunctionBytecode` | Re-emits graph class-shape constants through `addClassShape`. | Asserts user-classes ON. | `vendor/luaur-bytecode-0.1.8/src/functions/to_function_bytecode_bytecode_graph.rs` | ENGINE | Bounds-checks the class-shape index. |
| `Bytecode/src/BytecodeGraphParser.h` | `BytecodeGraphParser::rebuildGraph` | Adds `NEWCLASSMEMBER` value input C and parses `NEWCLASS` superclass/shape inputs plus target producer. | User-classes default OFF. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_graph_parser_rebuild_graph.rs` | ENGINE | Existing Rust graph currently omits the member value input too. |
| `Bytecode/src/BytecodeGraphSerializer.h` | `BytecodeGraphSerializer::emitInstruction` | Serializes graph `LOP_NEWCLASS` with target, superclass input, and class-shape AUX. | User-classes default OFF. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_graph_serializer_emit_instruction.rs` | ENGINE | Input ordering must match parser. |
| `Bytecode/src/BytecodeGraphSerializer.h` | `BytecodeGraphSerializer::emitBytecode` | Initializes every instruction PC to `~0u`, leaving unscheduled/dead instructions explicitly unassigned. | None. | `vendor/luaur-bytecode-0.1.8/src/methods/bytecode_graph_serializer_emit_bytecode.rs` | ENGINE | Used by inliner feedback-PC reconstruction. |
| `Common/include/Luau/Bytecode.h` | `LOP_NEWCLASS` | New two-word opcode: target A, superclass B or `0xff`, reserved C, class-shape AUX. | Effective user-classes ON. | NONE-new | ENGINE | Requires enum, length, compiler, loader, graph, dump, dispatch, and VM case to land atomically. |
| `Common/include/Luau/Bytecode.h` | `LBC_VERSION_MAX` | Raises supported normal bytecode maximum 12→13. | Vector-double default OFF, but loader accepts v13 unconditionally. | `vendor/luaur-common-0.1.8/src/enums/luau_bytecode_tag.rs` | ENGINE | Loader must understand `LBC_CONSTANT_VECTORD`. |
| `Common/include/Luau/Bytecode.h` | `LBC_VERSION_CLASSES` | Adds WIP class bytecode version 100. | Generated with user-classes ON; accepted by loader regardless of flag. | NONE-new | ENGINE | Deliberately outside `[MIN, MAX]`; all range checks need the special case. |
| `Common/include/Luau/Bytecode.h` | `LPF_USES_EXPORT` | Adds proto flag bit `1 << 4`. | Set only with export syntax ON; default OFF. | NONE-new | ENGINE | Consumed by new `lua_usesexport` API and require placeholder workflow. |
| `Common/include/Luau/BytecodeUtils.h` | `getOpLength` | Marks `LOP_NEWCLASS` as two words. | None. | `vendor/luaur-common-0.1.8/src/functions/get_op_length.rs` | ENGINE | Missing this desynchronizes every bytecode scanner. |
| `Common/include/Luau/VecDeque.h` | `VecDeque::emplace_back` | Adds in-place back construction, growing first and returning the new element. | None. | NONE-new | ENGINE | Forwarding/lifetime behavior should mirror placement construction. |
| `Common/include/Luau/VecDeque.h` | `VecDeque::emplace_front` | Adds in-place front construction and returns the new element. | None. | NONE-new | ENGINE | Head wraparound and growth order are observable. |

## Compiler

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Compiler/include/Luau/Compiler.h` | `CompileOptions::vectorPrecision` | Adds in-class default `0`. | None. | `vendor/luaur-compiler-0.1.8/src/records/compile_options.rs` | ENGINE | Field itself is from 0.731 and is not yet present in Rust. |
| `Compiler/include/luacode.h` | `lua_CompileOptions::vectorPrecision` | Documents C ABI default as 0. | None. | `vendor/luaur-compiler-0.1.8/src/records/lua_compile_options.rs` | ENGINE | Earlier-rung ABI field must land before this rung. |
| `Compiler/src/Compiler.cpp`, `Compiler/src/ValueTracking.cpp` | `LuauOptimizeExportTable` | New static flag gating precomputed export table shapes and delayed function insertion. | New default OFF; legacy export writes execute by default. | NONE-new | ENGINE | Dark path spans value tracking, local elimination, closure codegen, and proto flags. |
| `Compiler/src/Compiler.cpp` | `Compiler` record | Replaces separate export table/local/class fields with nested `Exports exports`. | Refactor is unconditional; optimization members are used mainly with flag ON. | `vendor/luaur-compiler-0.1.8/src/records/compiler.rs` | ENGINE | Large structure-preserving field migration. |
| `Compiler/src/Compiler.cpp` | `Compiler::Compiler` | Initializes `exports` with the synthetic `__EXP` local. | None. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compiler.rs` | ENGINE | Constructor and record must land together. |
| `Compiler/src/Compiler.cpp` | `Compiler::checkExportedLocal` | Stops pushing every checked export into the old `exportedLocals` vector. | Export syntax default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_check_exported_local.rs` | ENGINE | Collection moves to `ValueVisitor` when optimization is ON. |
| `Compiler/src/Compiler.cpp` | `Compiler::ensureExportTable` | Marks `hasExports`; uses `DUPTABLE` for a valid prebuilt shape, otherwise `NEWTABLE`. | Optimize-export default OFF selects `NEWTABLE`. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_ensure_export_table.rs` | ENGINE | Constant ID must fit signed-16 DUPTABLE encoding. |
| `Compiler/src/Compiler.cpp` | `Compiler::getExportTableReg` | Switches references to `exports.exportTableLocal`. | None. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_get_export_table_reg.rs` | ENGINE | Mechanical but touches local/upvalue lookup. |
| `Compiler/src/Compiler.cpp` | `Compiler::buildExportTableShape` | New pass builds a table shape for exported variables and embeds immutable constant values when possible. | Optimize-export ON only; default OFF. | NONE-new | ENGINE | Bails out on table length or constant-pool limits; fallback must remain correct. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileExportTable` | Uses `exports`, always ensures a table, writes exported classes and—when optimized—functions before freezing. | Export syntax OFF by default; optimization OFF by default. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_export_table.rs` | ENGINE | Function exports are delayed only in optimized mode. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileFunction` | Builds the export shape before body codegen, tests `exports.isEmpty`, and sets `LPF_USES_EXPORT` on the top proto. | Export syntax and optimize-export default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_function.rs` | ENGINE | Proto bit feeds embedder require behavior. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileClassDeclaration` | Tracks exported class in `exports` and emits `NEWCLASS` with direct or compiled superclass; uses `0xff` for no parent. | User-classes/export flags default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_class_declaration.rs` | ENGINE | Replaces placeholder `LOADKX`; same-rung VM opcode is mandatory. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileExpr` | Exported local reads bypass export-table lookup for optimized exported functions; switches synthetic-local references to `exports`. | Export syntax/optimization default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_expr.rs` | ENGINE | Prevents reading a function before it is installed into the frozen export table. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileLValue` | Exported function assignment bypasses export-table lvalue generation in optimized mode. | Export syntax/optimization default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_l_value.rs` | ENGINE | Must match `compileExpr`’s function classification. |
| `Compiler/src/Compiler.cpp` | `Compiler::areLocalsRedundant` | Tests constantness before export handling and allows optimized, shaped exported constants to be eliminated. | Optimize-export default OFF preserves old “exports are not redundant.” | `vendor/luaur-compiler-0.1.8/src/methods/compiler_are_locals_redundant.rs` | ENGINE | Wrong ordering can remove required initialization. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileStatLocal` | Avoids runtime export-table writes for constants already embedded in a prebuilt shape. | Optimize-export default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_stat_local.rs` | ENGINE | Requires non-null `Variable` from value tracking. |
| `Compiler/src/Compiler.cpp` | `Compiler::compileStat` | Legacy exported local-function path runs only with optimization OFF; removes duplicate export check from ordinary local-function compilation. | Optimize-export default OFF executes legacy branch. | `vendor/luaur-compiler-0.1.8/src/methods/compiler_compile_stat.rs` | ENGINE | ON path relies on delayed insertion in `compileExportTable`. |
| `Compiler/src/Compiler.cpp` | `Compiler::Exports` | New nested record holding synthetic local, exported classes/functions/variables, table constant ID, and `hasExports`. | None structurally. | NONE-new | ENGINE | All export state is centralized here. |
| `Compiler/src/Compiler.cpp` | `Compiler::Exports::Exports` | New constructor stores the synthetic export-table local. | None. | NONE-new | ENGINE | Must initialize hash containers with null sentinels as shown. |
| `Compiler/src/Compiler.cpp` | `Compiler::Exports::isEmpty` | New helper considers explicit export demand plus class/function/variable collections. | None. | NONE-new | ENGINE | `hasExports` matters even when collections are empty. |
| `Compiler/src/Compiler.cpp` | `compileOrThrow` | Selects new export-aware `trackValues` with optimization ON, otherwise renamed legacy tracker. | Optimize-export default OFF uses deprecated tracker. | `vendor/luaur-compiler-0.1.8/src/functions/compile_or_throw_compiler.rs` | ENGINE | Earlier class-local tracking context also needs to be preserved. |
| `Compiler/src/ValueTracking.cpp` | `ValueVisitor` record | Adds optional output pointers for exported functions and variables. | Used with optimize-export ON; default OFF constructor leaves them null. | `vendor/luaur-compiler-0.1.8/src/records/value_visitor.rs` | ENGINE | Visitor lifetime must not outlive output collections. |
| `Compiler/src/ValueTracking.cpp` | `ValueVisitor::ValueVisitor` | Retains legacy constructor and adds an overload accepting export collections. | Optimize-export default OFF uses legacy constructor. | `vendor/luaur-compiler-0.1.8/src/methods/value_visitor_value_visitor.rs` | ENGINE | Legacy constructor is marked for later removal, not removed here. |
| `Compiler/src/ValueTracking.cpp` | `ValueVisitor::visit(AstStatLocal*)` | Collects exported locals into `exportedVariables`. | Optimize-export ON; default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/value_visitor_visit_value_tracking.rs` | ENGINE | Preserves source order for shape construction. |
| `Compiler/src/ValueTracking.cpp` | `ValueVisitor::visit(AstStatLocalFunction*)` | Adds exported functions to both function set and variable list. | Optimize-export ON; default OFF. | `vendor/luaur-compiler-0.1.8/src/methods/value_visitor_visit_value_tracking_alt_d.rs` | ENGINE | Set prevents function-specific export-table reads/writes. |
| `Compiler/src/ValueTracking.{h,cpp}` | `trackValues` | Adds export-aware overload taking class locals, exported function set, and exported variable vector. | Called only with optimize-export ON. | `vendor/luaur-compiler-0.1.8/src/functions/track_values.rs` | ENGINE | Current Rust signature lacks earlier class-local arguments. |
| `Compiler/src/ValueTracking.{h,cpp}` | `trackValues_DEPRECATED` | Renames the legacy tracker. | Default OFF path uses this symbol. | NONE-new | ENGINE | Temporary compatibility symbol; do not accidentally delete the legacy path in this rung. |

## Config

All Config rows are type-checker/configuration infrastructure and therefore OUT-OF-SCOPE for the vendored runtime crates.

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Config/src/LuauConfig.cpp` | `LuauRbsConfigAliasResolution` | New static flag selecting shared execution/table-parsing helpers. | New default OFF. | NONE-new | OUT-OF-SCOPE | No `luaur-config` crate is vendored. |
| `Config/src/LuauConfig.cpp` | `load` | Old source compiler/loader helper is removed by rename. | None. | NONE-untranslated | OUT-OF-SCOPE | Existing at base; Config is not translated in the vendored set. |
| `Config/src/LuauConfig.cpp` | `loadFromSource` | Renamed source compile/load helper. | None. | NONE-new | OUT-OF-SCOPE | Behavior matches removed `load`. |
| `Config/src/LuauConfig.cpp` | `loadFromBytecode` | New helper loads already-compiled config bytecode. | None. | NONE-new | OUT-OF-SCOPE | Does not compile source. |
| `Config/src/LuauConfig.cpp` | `executeAndExtractConfig` | New shared sandbox execution, yield/error handling, result validation, and table serialization. | Source path uses it only with RBS flag ON; bytecode API always uses it. | NONE-new | OUT-OF-SCOPE | Callback/interrupt ordering is part of the contract. |
| `Config/src/LuauConfig.cpp` | `extractConfig` | Renames source loader call and delegates execution to helper under the new flag. | RBS default OFF retains old inline execution. | NONE-untranslated | OUT-OF-SCOPE | OFF and ON paths are intended to be equivalent. |
| `Config/src/LuauConfig.cpp` | `parseLuauConfigTable` | New helper validates the top-level `luau` table and populates `Config`. | Source path uses it with RBS ON; bytecode API always. | NONE-new | OUT-OF-SCOPE | Moves alias options into the parser. |
| `Config/src/LuauConfig.cpp` | `extractLuauConfig` | Delegates table parsing to the helper with RBS ON. | Default OFF retains old inline parser. | NONE-untranslated | OUT-OF-SCOPE | No runtime crate twin. |
| `Config/include/Luau/LuauConfig.h`, `Config/src/LuauConfig.cpp` | `extractLuauConfigFromBytecode` | New public API creates sandbox VM, loads bytecode, executes it, and extracts Luau config. | Unguarded. | NONE-new | OUT-OF-SCOPE | Public Config API, but the corresponding crate is not vendored. |

## Require

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Require/include/Luau/Require.h` | `luarequire_Configuration::load` | Contract changes: callback should call `luarequire_createplaceholder` after compiling modules whose proto uses export. | Relevant with cyclic-require flag ON; default OFF. | NONE-untranslated | RT-API | Replaces the old requirement to pass stack slot 6 to the module chunk. |
| `Require/include/Luau/RequireNavigator.h` | `ConfigStatus::PresentLuauBytecode` | New status for precompiled Luau configuration. | None. | NONE-new | ENGINE | Navigator consumers need a corresponding handling branch outside this scoped diff. |
| `Require/include/Luau/RequireNavigator.h`, `Require/src/Navigation.{h,cpp}` | `NavigationContext::getAlias` / `RuntimeNavigationContext::getAlias` | Removes `const` from virtual API and override. | None. | NONE-untranslated | RT-API | Source/API signature change; no `luaur-require` crate is vendored. |
| `Require/include/Luau/Require.h`, `Require/src/Require.cpp` | `luarequire_lockplaceholder` | New public wrapper locking a placeholder with cyclic-access error metatable. | API unguarded; useful with cyclic flag ON. | NONE-new | RT-API | Also freezes the table readonly. |
| `Require/include/Luau/Require.h`, `Require/src/Require.cpp` | `luarequire_populateplaceholder` | New public wrapper copying result contents/metatable into a placeholder. | API unguarded; useful with cyclic flag ON. | NONE-new | RT-API | Result must be a table in cyclic-provided flow. |
| `Require/include/Luau/Require.h`, `Require/src/Require.cpp` | `luarequire_createplaceholder` | New public wrapper creating, locking, and caching the current module placeholder. | API unguarded; require continuation consumes it with cyclic flag ON. | NONE-new | RT-API | Load callback must call it only for export-using modules. |
| `Require/src/RequireImpl.cpp` | `modulePlaceholdersKey` | Deletes per-chunk `_MODULEPLACEHOLDERS` registry table key. | Old implementation was used with cyclic flag ON. | NONE-untranslated | ENGINE | Replaced by shared metatable identity plus provided-state map. |
| `Require/src/RequireImpl.cpp` | `cyclicPlaceholderMetatableSentinel` | New address-identity registry key for the shared lock metatable. | Used by cyclic flag ON flow. | NONE-new | ENGINE | Address uniqueness is semantically significant. |
| `Require/src/RequireImpl.cpp` | `cyclicPlaceholderProvidedKey` | New registry table records placeholders actually returned to cyclic importers. | Used with cyclic flag ON. | NONE-new | ENGINE | State must be cleared after continuation. |
| `Require/src/RequireImpl.cpp` | `isCached` | Detects cached locked placeholders and marks them “provided” when a cyclic require returns one. | New logic only with cyclic flag ON; default OFF. | NONE-untranslated | ENGINE | Metatable comparison must use raw identity and preserve stack balance. |
| `Require/src/RequireImpl.cpp` | `invalidateModulePlaceholder` | Removes old per-placeholder invalidation/metatable-preservation helper. | Old cyclic ON implementation. | NONE-untranslated | ENGINE | Superseded by shared locking/population helpers. |
| `Require/src/RequireImpl.cpp` | `pushCyclicPlaceholderMetatable` | New lazy shared metatable creator with throwing index/newindex and locked metatable. | Used with cyclic flow. | NONE-new | ENGINE | Leaves the metatable on stack in both cached and newly-created cases. |
| `Require/src/RequireImpl.{h,cpp}` | `lockPlaceholder` | Applies shared lock metatable and sets readonly. | Unguarded helper. | NONE-new | ENGINE | Public wrapper delegates here. |
| `Require/src/RequireImpl.{h,cpp}` | `createPlaceholder` | Creates a locked table and caches it under stack slot 2’s cache key. | Unguarded helper; meaningful with cyclic flag ON. | NONE-new | ENGINE | Fixed stack-slot contract is embedder-visible. |
| `Require/src/RequireImpl.{h,cpp}` | `populatePlaceholder` | Unfreezes placeholder, raw-copies fields, copies metatable, then freezes it. | Unguarded helper. | NONE-new | ENGINE | Does not clear fields that were already present. |
| `Require/src/RequireImpl.cpp` | `kRequireStackValues` | Changes fixed require stack count from six to four. | Unconditional; old six-slot layout was cyclic ON. | NONE-untranslated | ENGINE | Load callbacks must no longer expect slots 5–6. |
| `Require/src/RequireImpl.cpp` | `kRequireStackValues_DEPRECATED` | Deletes the old four-slot compatibility constant because four is now canonical. | Cyclic flag no longer selects stack layout. | NONE-untranslated | ENGINE | Default-OFF layout becomes the sole layout. |
| `Require/src/RequireImpl.cpp` | `lua_requirecont` | Reworks cyclic completion: consults “provided” state, populates placeholder only when exposed, otherwise caches result normally. | Cyclic ON takes new flow; default OFF executes ordinary cache path. | NONE-untranslated | ENGINE | Complex stack manipulation; result replacement and registry pops are high risk. |
| `Require/src/RequireImpl.cpp` | `lua_requireinternal` | Deletes automatic placeholder creation/invalidation and always calls loader with four fixed slots. | Unconditional four-slot contract; cyclic placeholder now load-callback-owned. | NONE-untranslated | ENGINE | Major responsibility shift to the embedder callback. |

## Inliner/JIT

These rows are OUT-OF-SCOPE because `Inliner/` is JIT/runtime-inliner-only and has no vendored Rust translation.

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `Inliner/src/JitInliner.cpp` | `buildGraphFromProto` | Asserts mapped call PC resolves to `LOP_CALLFB`; removes unused `VecDeque` include. | Effective call-feedback/inliner use. | NONE-untranslated | OUT-OF-SCOPE | Assertion detects stale PC mapping. |
| `Inliner/src/JitInliner.cpp` | `emitCode` | Records feedback PCs only for live `CALLFB` instructions; formatting-only blank line is included here. | Effective call-feedback/inliner use. | NONE-untranslated | OUT-OF-SCOPE | Dead instructions retain unassigned PC. |
| `Inliner/src/JitInliner.cpp` | `onInlineFunction` | Creates optimized proto only when emission succeeds, but seals caller feedback slots in both success and failure cases. | Effective inliner use. | NONE-untranslated | OUT-OF-SCOPE | Prevents reoptimizing the original proto after successful inline. |
| `Inliner/src/RuntimeBytecodeBuilder.h` | `RuntimeBytecodeBuilder::dumpConstant` | Reads C-closure debug name from managed `TString` when flag ON, deprecated pointer otherwise. | Managed-debug default OFF uses deprecated pointer. | NONE-untranslated | OUT-OF-SCOPE | Declaration of the new flag is accounted with the VM flag row below. |
| `Inliner/src/TValueVmConstImpl.cpp` | `TValueVmConstImpl::evaluate` | Uses `LUA_VECTOR_TYPE` for vector arithmetic and passes `backing.L` into `setvvalue`; adds GC/vector headers. | No runtime flag; compile-time vector type applies. | NONE-untranslated | OUT-OF-SCOPE | Passing the state is needed for double-vector/GC-aware representation. |

## VM

| c file | symbol | change summary (1-3 lines, concrete) | FFlag guard(s) + which default the hunk assumes | rust twin path, or NONE-new, or NONE-untranslated | class | risk notes |
|---|---|---|---|---|---|---|
| `VM/include/lua.h`, `VM/src/lapi.cpp` | `lua_usesexport` | New public API returns whether a Lua closure’s proto has `LPF_USES_EXPORT`; non-Lua functions return false. | Proto bit is set with export syntax ON; default OFF. | NONE-new | RT-API | Require loaders use this to decide whether to create a placeholder. |
| `VM/src/lapi.cpp`, `laux.cpp`, `lclass.cpp`, `ldebug.cpp`, `lfunc.cpp`, `lgc.cpp`, `lgcdebug.cpp`; `Inliner/src/RuntimeBytecodeBuilder.h` | `LuauManagedDebugNames` | New static flag selecting GC-managed `TString*` C-closure debug names over borrowed `const char*`. | New default OFF executes deprecated pointer path. | NONE-new | ENGINE | Touches object layout, initialization, GC marking, diagnostics, and JIT dumping. |
| `VM/src/lapi.cpp` | `lua_pushcclosurek` | Interns `debugname` as `TString` when managed-debug ON; otherwise stores borrowed pointer in deprecated field. | Managed-debug default OFF. | `vendor/luaur-vm-0.1.8/src/functions/lua_pushcclosurek.rs` | RT-API | ON fixes pointer lifetime but requires GC marking and layout changes. |
| `VM/src/lapi.cpp` | `lua_getuserdataname` | Whitespace-only cleanup. | None. | NONE-untranslated | RT-API | No semantic delta; included for hunk completeness. |
| `VM/src/laux.cpp` | `currfuncname` | Reads either managed or deprecated C-closure debug name and preserves `__namecall` handling. | Managed-debug default OFF. | `vendor/luaur-vm-0.1.8/src/functions/currfuncname.rs` | ENGINE | Null handling differs by representation. |
| `VM/src/laux.cpp`, `lbaselib.cpp`, `ldo.cpp` | `LuauCustomYieldablePcalls` | Deletes flag definition/declarations and all branches; custom yieldable pcall implementation becomes unconditional. | Retired → ON; old release default executed OFF. | NONE-untranslated | ENGINE | Significant default behavior flip across pcall/xpcall/resume machinery. |
| `VM/src/laux.cpp` | `luaL_pcallyieldable` | Removes the flag assertion; function is now always valid. | Custom-yieldable retired → ON. | NONE-untranslated | ENGINE | Symbol was introduced after the Rust baseline. |
| `VM/src/lbaselib.cpp` | `luaB_pcallrun` | Deletes legacy protected-call trampoline. | Custom-yieldable retired → ON. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_pcallrun.rs` | ENGINE | Rust legacy function must be removed only after new path exists. |
| `VM/src/lbaselib.cpp` | `luaB_pcally` | Always delegates to `luaL_pcallyieldable`; deletes legacy `luaD_pcall` branch. | Retired → ON. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_pcally.rs` | ENGINE | Changes yielding/protected continuation behavior under old defaults. |
| `VM/src/lbaselib.cpp` | `luaB_xpcally` | Always delegates to yieldable pcall with error function index 1. | Retired → ON. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_xpcally.rs` | ENGINE | Must preserve stack transformation `err, f, args`. |
| `VM/src/lbaselib.cpp` | `luaB_xpcallerr` | Deletes legacy error-handler trampoline. | Retired → ON. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_xpcallerr.rs` | ENGINE | Error handler now runs through resume machinery. |
| `VM/src/lbaselib.cpp` | `luaB_xpcallcont` | Deletes legacy nested protected-call error path; non-OK continuation directly returns `false, error`. | Retired → ON. | `vendor/luaur-vm-0.1.8/src/functions/lua_b_xpcallcont.rs` | ENGINE | Error-of-error status construction moves to `resume_handle`. |
| `VM/src/lobject.h` | `Closure` | Replaces one C debug-name pointer with `debugname_DEPRECATED: const char*` plus managed `TString* debugname`. | Managed-debug default OFF uses deprecated field. | `vendor/luaur-vm-0.1.8/src/records/closure.rs` | ENGINE | C-layout/size change; every constructor and reader must migrate together. |
| `VM/src/lfunc.cpp` | `luaF_newCclosure` | Initializes both debug-name fields to null. | None. | `vendor/luaur-vm-0.1.8/src/functions/lua_f_new_cclosure.rs` | ENGINE | Prevents GC from seeing uninitialized managed pointer. |
| `VM/src/ldebug.cpp` | `getfuncname` | Reads managed `TString` when enabled, deprecated pointer otherwise. | Managed-debug default OFF. | `vendor/luaur-vm-0.1.8/src/functions/getfuncname.rs` | ENGINE | Used in runtime error/debug messages. |
| `VM/src/lgc.cpp` | `traverseclosure` | Marks managed C-closure debug-name string. | Managed-debug ON only; default OFF. | `vendor/luaur-vm-0.1.8/src/functions/traverseclosure.rs` | ENGINE | Missing mark would leave a dangling managed pointer. |
| `VM/src/lgcdebug.cpp` | `dumpclosure` | Dumps managed or deprecated C debug name according to flag. | Managed-debug default OFF. | `vendor/luaur-vm-0.1.8/src/functions/dumpclosure.rs` | ENGINE | Debug-only output, but reads object layout directly. |
| `VM/src/lgcdebug.cpp` | `dumpthread` | Uses selected representation for C frame names. | Managed-debug default OFF. | `vendor/luaur-vm-0.1.8/src/functions/dumpthread.rs` | ENGINE | Null fallback remains `[C]`. |
| `VM/src/lgcdebug.cpp` | `enumclosure` | Supplies selected debug-name representation to heap enumeration. | Managed-debug default OFF. | `vendor/luaur-vm-0.1.8/src/functions/enumclosure.rs` | ENGINE | Heap profiler reads must match closure layout. |
| `VM/src/lclass.cpp` | `luaR_newblankclass` | New helper allocates a zero/NULL-initialized class object. | Effective user-classes ON. | NONE-new | ENGINE | Enables temporary unreified/inherited classes with nullable arrays. |
| `VM/src/lclass.cpp` | `luaR_addclassmetatable` | New helper constructs class `__call` metatable and constructor closure; handles both debug-name representations. | User-classes effective; managed-debug default OFF. | NONE-new | ENGINE | Constructor closure must be rooted through class metatable barriers. |
| `VM/src/lclass.cpp` | `luaR_newclass` | Refactors through `newblankclass`/`addclassmetatable`; retains member arrays/count initialization. | Effective user-classes ON. | `vendor/luaur-vm-0.1.8/src/functions/lua_r_newclass.rs` | ENGINE | Helper extraction must not change GC-paused construction order. |
| `VM/src/lclass.cpp` | `luaR_registerstaticmember` | New helper copies a static value and installs name↔offset mappings with barriers. | Effective user-classes ON. | NONE-new | ENGINE | Uses separate overall and static-array offsets. |
| `VM/src/lclass.{h,cpp}` | `luaR_inheritclass` | New runtime inheritance: rejects instance-field overrides, merges parent/child instance and static members, adds class metatable, clones parent instance metatable. | Effective user-classes ON. | NONE-new | ENGINE | High-risk allocation/index/barrier logic; repeated closure calls must not mutate proto constants. |
| `VM/src/lclass.cpp` | `luaR_createobject` | Allocates member array directly from class instance-member count before copying count. | Effective user-classes ON. | `vendor/luaur-vm-0.1.8/src/functions/lua_r_createobject.rs` | ENGINE | Mechanical reorder; zero-member allocation semantics must match allocator. |
| `VM/src/lclass.cpp` | `luaR_freeclass` | Frees static/member-name arrays only when non-null. | Effective user-classes ON. | `vendor/luaur-vm-0.1.8/src/functions/lua_r_freeclass.rs` | ENGINE | Required for blank/intermediate class objects. |
| `VM/src/lobject.h` | `LuauClass` | Clarifies that instance offsets precede static offsets and static array index subtracts instance count. | None. | `vendor/luaur-vm-0.1.8/src/records/luau_class.rs` | ENGINE | Comment-only hunks document invariants used by inheritance. |
| `VM/src/ldo.cpp` | `resume_continue` | Unconditionally clears HANDLE before a continuation and honors `SCHEDULED_REENTRY`. | Custom-yieldable retired → ON. | `vendor/luaur-vm-0.1.8/src/functions/resume_continue.rs` | ENGINE | Old default did neither. |
| `VM/src/ldo.cpp` | `resume_handle` | Makes error-function and continuation-resume machinery unconditional; only `nCcalls` reset remains under `LuauXpcallFixMessageYieldPath`. | Custom-yieldable retired → ON; xpcall-fix remains default OFF. | `vendor/luaur-vm-0.1.8/src/functions/resume_handle.rs` | ENGINE | Largest VM control-flow delta; stack/frame restoration order is binding. |
| `VM/src/ldo.cpp` | `resume_finish` | Removes custom-pcall conjunction from xpcall message-yield restoration. | `LuauXpcallFixMessageYieldPath` default OFF. | `vendor/luaur-vm-0.1.8/src/functions/resume_finish.rs` | ENGINE | Depends on the 0.731 xpcall-fix flag. |
| `VM/src/lvmexecute.cpp` | `VM_DISPATCH_TABLE` | Adds `LOP_NEWCLASS` dispatch target. | Effective user-classes ON. | `vendor/luaur-vm-0.1.8/src/macros/vm_dispatch_table.rs` | ENGINE | Computed-goto table order must exactly match opcode enum. |
| `VM/src/lvmexecute.cpp` | `VM_CASE(LOP_NEWCLASS)` | Loads unreified class constant; if superclass register is present, type-checks it and replaces result with `luaR_inheritclass`. | Effective user-classes ON. | NONE-new | ENGINE | Two-word PC advance, GC protection, and class type error are critical. |
| `VM/src/lvmload.cpp` | `loadsafe` | Accepts class WIP bytecode version 100 in addition to normal `[MIN, MAX]`. | Unguarded acceptance; compiler emits v100 only with user-classes ON. | `vendor/luaur-vm-0.1.8/src/functions/loadsafe.rs` | ENGINE | Loader must also understand every v100 opcode/constant before accepting it. |

## FFlag ledger

Luau’s static flag macro initializes Boolean flags to `false`; `LUAU_FLAGVERSION` only records rollout metadata.

| flag | rung action | gated behavior | default release path after this rung |
|---|---|---|---|
| `LuauCstAttr` | Removed | CST-aware attribute parsing, CST storage, and structure-preserving printing. | Former **ON** behavior is now unconditional. Before removal, the macro default executed OFF. |
| `LuauTableEntriesDontNeedToMatchIndent` | Removed | Whether missing-comma table recovery accepts the next entry regardless of indentation. | Former **ON** behavior is now unconditional; old default OFF required matching indentation. |
| `LuauCustomYieldablePcalls` | Removed | Yieldable `pcall`/`xpcall`, HANDLE frames, scheduled reentry, and resume-continuation error handling. | Former **ON** behavior is now unconditional; old default OFF used legacy `luaD_pcall` paths. |
| `LuauExportValueSyntax` | Version 3→4 | Export-value parser/compiler behavior and `LPF_USES_EXPORT`. | Still default **OFF**. |
| `LuauBytecodeCostModel` | Adds version 2 metadata | Proto-size framing and serialized cost. | Still default **OFF**. |
| `LuauCompileEmitVectorDouble` | Added, version 2 | Double-precision vector constants and bytecode v13. | Default **OFF**: vectors are emitted as float constants and ordinary target version remains v9. |
| `LuauOptimizeExportTable` | Added | Prebuilt export-table shapes, embedded constants, delayed function insertion, and related elimination rules. | Default **OFF**: legacy export-table writes execute. |
| `LuauRbsConfigAliasResolution` | Added | Shared config execution/table-parsing helpers. | Default **OFF** for source config; new bytecode API uses the helpers unconditionally. |
| `LuauManagedDebugNames` | Added | Interned/GC-managed C-closure debug names. | Default **OFF**: deprecated borrowed `const char*` storage is used. |

No DFFlag or DFInt was added, removed, or default-flipped in the scoped diff.

Unchanged flags that guard changed code:

- `DebugLuauUserDefinedClasses` — default OFF; gates class parsing/compiler/bytecode graph work.
- `LuauEmitCallFeedback` — default OFF; remains a lower-priority bytecode version selector.
- `LuauCyclicRequireShortCircuit` — default OFF; selects the new placeholder completion logic, though the four-slot callback contract is now unconditional.
- `LuauXpcallFixMessageYieldPath` — default OFF; retains only the call-count restoration subpath after custom yieldable pcalls are made unconditional.

## Dependency notes

1. **0.726 CST attributes first.** `LuauCstAttr`, `CstAttr`, `CstParametrizedAttr`, `CstAttrList`, attr-list-aware CST function records, `parseAttrList`, and `getAttributeStartLocation` entered the C++ ladder before this rung. Several are absent from the 0.724 Rust baseline. Port the earlier CST attribute split before applying this rung’s flag retirement.

2. **0.731 class support first.** The inheritance chain depends on the previous rung’s `AstStatClass`, class parser/compiler path, `DebugLuauUserDefinedClasses` rollout, class-shape constants, `LOP_NEWCLASSMEMBER`, and VM class/object representation. `LOP_NEWCLASS`, bytecode v100, `super`, and `luaR_inheritclass` must then land together within this rung.

3. **0.731 vector-precision API first.** `CompileOptions::vectorPrecision`, `lua_CompileOptions::vectorPrecision`, `Type_Vectord`, and double-vector builder storage originated in 0.731. Current Rust records do not yet contain that field; v13 serialization cannot be ported independently.

4. **0.729 cost/call-feedback framing first.** `LuauBytecodeCostModel`, proto byte-size framing, call feedback, `LPF_INLINABLE`, and bytecode graph/inliner machinery precede the v2 metadata and generalized framing conditions here.

5. **0.725 export-value support first.** Export-table optimization and `LPF_USES_EXPORT` depend on the earlier export parser, `AstLocal::isExported`, export table codegen, and closure/upvalue fixes. Rust currently carries experimental export code but intentionally defaults it OFF because of a known closure-capture miscompile.

6. **0.725 cyclic-require/yieldable-pcall support first.** The placeholder redesign assumes `LuauCyclicRequireShortCircuit`; retirement of `LuauCustomYieldablePcalls` assumes `luaL_pcallyieldable` and HANDLE/resume machinery already landed. Those symbols are not fully present in the 0.724 Rust baseline.

7. **0.731 xpcall fix first.** `resume_handle`/`resume_finish` retain `LuauXpcallFixMessageYieldPath`, introduced in the prior rung.

8. **Require/Config crate scope.** No `luaur-require` or `luaur-config` crate is vendored. `luaur-rt` implements a separate minimal alias-only `require`; the upstream Require API is therefore not a direct existing translation. Any decision to expose these APIs requires an explicit runtime/embedder lane.

## Completeness accounting

Per-file hunk reconciliation:

```text
Ast (61)
  Ast/include/Luau/Ast.h 2
  Ast/include/Luau/Parser.h 2
  Ast/src/Ast.cpp 3
  Ast/src/Cst.cpp 6
  Ast/src/Parser.cpp 31
  Ast/src/PrettyPrinter.cpp 17

Bytecode (29)
  Bytecode/include/Luau/BytecodeBuilder.h 1
  Bytecode/include/Luau/BytecodeCallInliner.h 1
  Bytecode/include/Luau/BytecodeGraph.h 5
  Bytecode/src/BytecodeBuilder.cpp 14
  Bytecode/src/BytecodeGraph.cpp 4
  Bytecode/src/BytecodeGraphParser.h 2
  Bytecode/src/BytecodeGraphSerializer.h 2

Common (8)
  Common/include/Luau/Bytecode.h 5
  Common/include/Luau/BytecodeUtils.h 1
  Common/include/Luau/VecDeque.h 2

Compiler (42)
  Compiler/include/Luau/Compiler.h 1
  Compiler/include/luacode.h 1
  Compiler/src/Compiler.cpp 31
  Compiler/src/ValueTracking.cpp 7
  Compiler/src/ValueTracking.h 2

Config (10)
  Config/include/Luau/LuauConfig.h 1
  Config/src/LuauConfig.cpp 9

Inliner (22)
  Inliner/src/JitInliner.cpp 7
  Inliner/src/RuntimeBytecodeBuilder.h 3
  Inliner/src/TValueVmConstImpl.cpp 12

Require (37)
  Require/include/Luau/Require.h 2
  Require/include/Luau/RequireNavigator.h 2
  Require/src/Navigation.cpp 1
  Require/src/Navigation.h 1
  Require/src/Require.cpp 1
  Require/src/RequireImpl.cpp 29
  Require/src/RequireImpl.h 1

VM (57)
  VM/include/lua.h 1
  VM/src/lapi.cpp 5
  VM/src/laux.cpp 5
  VM/src/lbaselib.cpp 6
  VM/src/lclass.cpp 8
  VM/src/lclass.h 1
  VM/src/ldebug.cpp 3
  VM/src/ldo.cpp 14
  VM/src/lfunc.cpp 2
  VM/src/lgc.cpp 2
  VM/src/lgcdebug.cpp 4
  VM/src/lobject.h 3
  VM/src/lvmexecute.cpp 2
  VM/src/lvmload.cpp 1
```

Ancillary include removals/additions, comments, formatting-only changes, declarations, and inline definitions are attributed to the corresponding symbol rows above.

**UNRESOLVED:** none.

**Final:** **266 hunks total / 266 attributed / 0 unresolved**.

Rows per class:

- **ENGINE:** 127
- **RT-API:** 8
- **OUT-OF-SCOPE:** 14
- **Total ledger rows:** 149