# Writer lane: luau-fork rung 5 (official 0.728 -> 0.729)

Production writer porting one upstream Luau release delta into Nuxie's
vendored luaur fork. Read `docs/luau-fork.md`, then
`.luau-fork-work/prompts/preamble.md`, then the binding ledger
`.luau-fork-work/inventory/job5.md`. C-side diff:
`git -C /Users/levi/dev/oss/luigi-rosso-luau diff ddcea05e..6e9b580e -- VM Compiler Ast Common Config Require Bytecode Inliner`

Rungs 1-4 (0.725-0.728) are landed. IMPORTANT dependency correction to the
ledger (written against the 0.724 baseline): `Proto::{optimized,deoptimized}`
NOW EXIST in the Rust `Proto` (landed at rung 3), so `Proto::cost` inserts
after them exactly as C orders it — verify against
`git show 6e9b580e:VM/src/lobject.h` and do NOT re-add earlier-rung layout.
Rows whose prerequisites live in the untranslated `Inliner/` subsystem
(`createInlinedProto`, `onInlineFunction`, `kMaxFunctionBytecodeSize`
removal) DEFER with the standing rationale.

## Protocol (identical to rungs 1-4)

1. STRUCTURE-PRESERVING; ROW-BY-ROW COMMITS with prefix
   `luau-fork rung5: <symbol> (<c-file>) [ddcea05e..6e9b580e]`; plain
   commits, no trailers. Focused gate: `cargo check -p nuxie --features
   scripting` + `cargo test -p nuxie-scripting --lib`.
2. FFLAG POLICY: new flags (`LuauTrackPrefixLocal`,
   `LuauNoDuplicateBinaryPrefix`, `LuauBytecodeCostModel`, `LuauCostModel`,
   and any others marked Added) register + pin `.set(false)`. Removed flags
   `LuauCompileTypeAliases`, `LuauResumeRestoreCcalls` hardwire their former
   ON paths, grep-complete. New FInts (`LuauJitInlineThreshold` 25,
   `LuauJitInlineThresholdMaxBoost` 300, `LuauJitInlineSmallFunSize` 128,
   `LuauJitInlineTooLongFunSize` 0xFFFF) register with C defaults; the
   EXISTING FInt `LuauInlineHitsThreshold` default changes 3 -> 32 — port
   the new default. `LuauDirectFieldGet` version stamp 2 -> 3 via the
   flagversion machinery.
3. Atomic groups:
   a. Proto::cost field (position after optimized/deoptimized) + its
      initialization + every serializer/loader touch point.
   b. Bytecode v12 unit: `LuauBytecodeCostModel` compiler-side emission
      (version selection, proto byte-size prefixes, inlinable cost
      metadata) + the UNCONDITIONAL VM loader acceptance of v12 (loadsafe
      parses v12 by version regardless of flags — this part is not dark;
      mirror C exactly) + `LuauCostModel`-gated graph-parser consumption.
   c. SCCP pass: new files following luaur's structure conventions for the
      C++ entity layout (methods/records per symbol); it builds on existing
      BytecodeGraph entities only.
   d. Coroutine-resume `LuauResumeRestoreCcalls` hardwiring: every
      completion/error path restores from oldnCcalls unconditionally as C
      does now.
   e. Direct-field GC unit: helper extraction + atomic-phase remarking +
      flag-version bump, both flag sides preserved.
4. Deferred rows -> `.luau-fork-work/rung5-blocked.md` with rationale;
   verified no-ops -> `.luau-fork-work/rung5-noop.md`.
5. End: rung-level `NUXIE_PATCH.md` entries ("Ported official Luau 0.729
   delta (upstream ddcea05e..6e9b580e)"), committed as
   `luau-fork rung5: NUXIE_PATCH.md rung entries`; one full
   `cargo test -p nuxie --features scripting`; fix forward only your own
   rows. Final message: dispositions, commits, gates, surprises.

Do not touch: workspace `Cargo.toml`, `Cargo.lock`, `docs/`, `corpus.toml`,
crates outside `vendor/luaur-*`, `NUXIE_PROVENANCE.md`, or
`.luau-fork-work/` beyond the two report files.
